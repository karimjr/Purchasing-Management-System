<?php
// =========================================================
// Rekapitulasi Pembelian
// ---------------------------------------------------------
// Satu halaman untuk melihat ulang semua transaksi + meringkas
// per hari / bulan / daerah / PIC / supplier / status, lengkap
// dengan pencarian, filter, dan tombol ekspor ke Excel & PDF.
// Angka di layar, di Excel, dan di PDF berasal dari fungsi yang
// sama (includes/rekap_data.php) supaya tidak mungkin beda.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/rekap_data.php';
require_login();

$user  = current_user();
$data  = rekap_fetch($pdo, rekap_parse_filters($_GET, $user['role'], $user['id']));
$f     = $data['filters'];
$tabel = rekap_tabel($data);
$t     = $data['totals'];

$daerahList = $pdo->query("SELECT DISTINCT daerah FROM purchases WHERE daerah <> '' ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
if (!$daerahList) {
    $daerahList = $pdo->query("SELECT DISTINCT daerah FROM daily_prices ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
}
$picList    = $pdo->query("SELECT id, name FROM users WHERE role IN ('pic','admin') AND is_active = 1 ORDER BY name")->fetchAll();
$vendorList = $pdo->query("SELECT id, name FROM vendors ORDER BY name")->fetchAll();
// PIC hanya melihat datanya sendiri -> filter PIC tidak perlu ditampilkan
if ($user['role'] === 'pic') { $picList = []; }

$pageTitle = 'Rekapitulasi Pembelian';
include __DIR__ . '/../includes/header.php';

// Label badge untuk kolom status (agar tampilan layar tetap berwarna)
$badgeKelas = [
    'Menunggu Approval' => 'secondary', 'Menunggu' => 'secondary', 'Belum Diajukan' => 'secondary',
    'Disetujui' => 'success', 'Selesai / Done' => 'success',
    'Ditolak' => 'danger', 'Gagal' => 'danger', 'Dibatalkan' => 'dark',
    'Diminta Revisi Harga' => 'warning', 'Menunggu Pembayaran' => 'warning',
    'Sudah Diajukan ke HO' => 'primary', 'Sedang Diproses' => 'info',
];
$statusCols = ['Status Petugas', 'Status Finance', 'Status Dirops', 'Status Pembayaran'];

function rekap_sel($cell) {
    return is_array($cell) ? ($cell['v'] ?? '') : $cell;
}
function rekap_num($v, $dec = 0) {
    return is_numeric($v) ? number_format((float)$v, $dec, ',', '.') : (string)$v;
}
?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <h4 class="mb-0"><i class="bi bi-clipboard-data"></i> Rekapitulasi Pembelian</h4>
  <div class="d-flex gap-2 flex-wrap">
    <button type="submit" form="rekapForm" name="export" value="xlsx" formaction="<?= BASE_URL ?>/rekap/export.php" class="btn btn-success btn-sm">
      <i class="bi bi-file-earmark-excel"></i> Export Excel
    </button>
    <button type="submit" form="rekapForm" name="export" value="pdf" formaction="<?= BASE_URL ?>/rekap/export.php" class="btn btn-outline-danger btn-sm">
      <i class="bi bi-file-earmark-pdf"></i> Export PDF
    </button>
  </div>
</div>

<p class="text-muted small mt-n2">
  Periode <strong><?= e(rekap_label_periode($f)) ?></strong>
  <?php if ($user['role'] === 'pic'): ?>&middot; hanya menampilkan pembelian Anda sendiri<?php endif; ?>
  &middot; file ekspor memakai filter yang sedang aktif di halaman ini.
</p>

<!-- ==================== FILTER ==================== -->
<form method="get" action="<?= BASE_URL ?>/rekap/list.php" id="rekapForm" class="mb-4">
  <div class="card border-0 shadow-sm">
    <div class="card-body">
      <div class="row g-2 align-items-end">
        <div class="col-md-4 col-12">
          <label class="form-label small mb-1">Cari</label>
          <div class="input-group input-group-sm">
            <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
            <input type="text" name="q" value="<?= e($f['q']) ?>" class="form-control"
                   placeholder="No Ticket, No Nota, supplier, PIC, catatan...">
            <button type="button" class="btn btn-outline-secondary" onclick="const i=this.form.querySelector('[name=q]');i.value='';i.focus();this.form.submit();" title="Kosongkan pencarian"><i class="bi bi-x-lg"></i></button>
          </div>
          <div class="form-text">Tekan Enter untuk mencari.</div>
        </div>

        <div class="col-md-2 col-6">
          <label class="form-label small mb-1">Dari tanggal</label>
          <input type="date" name="dari" value="<?= e($f['dari']) ?>" class="form-control form-control-sm">
        </div>
        <div class="col-md-2 col-6">
          <label class="form-label small mb-1">Sampai tanggal</label>
          <input type="date" name="sampai" value="<?= e($f['sampai']) ?>" class="form-control form-control-sm">
        </div>

        <div class="col-md-4 col-12">
          <label class="form-label small mb-1">Periode pesat</label>
          <div class="d-flex flex-wrap gap-1">
            <?php foreach (REKAP_PERIODE_PESAT as $key => $label): ?>
              <a class="btn btn-sm btn-outline-success <?= ($f['dari'] || $f['sampai']) && $key === '' ? 'active' : '' ?>"
                 href="<?= BASE_URL ?>/rekap/list.php?<?= e(http_build_query(array_merge($_GET, ['quick' => $key, 'hal' => 1, 'dari' => '', 'sampai' => '']))) ?>">
                <?= e($label) ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Daerah</label>
          <select name="daerah" class="form-select form-select-sm">
            <option value="">Semua daerah</option>
            <?php foreach ($daerahList as $d): ?>
              <option value="<?= e($d) ?>" <?= $f['daerah'] === $d ? 'selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <?php if ($picList): ?>
        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">PIC</label>
          <select name="pic_id" class="form-select form-select-sm">
            <option value="">Semua PIC</option>
            <?php foreach ($picList as $p): ?>
              <option value="<?= (int)$p['id'] ?>" <?= (string)$f['pic_id'] === (string)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php endif; ?>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Supplier</label>
          <select name="vendor_id" class="form-select form-select-sm">
            <option value="">Semua supplier</option>
            <?php foreach ($vendorList as $v): ?>
              <option value="<?= (int)$v['id'] ?>" <?= (string)$f['vendor_id'] === (string)$v['id'] ? 'selected' : '' ?>><?= e($v['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Status Petugas</label>
          <select name="status_approval" class="form-select form-select-sm">
            <option value="">Semua</option>
            <?php foreach (REKAP_LABEL_PETUGAS as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['status_approval'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Status Finance</label>
          <select name="status_finance_approval" class="form-select form-select-sm">
            <option value="">Semua</option>
            <?php foreach (REKAP_LABEL_SINGKAT as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['status_finance_approval'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Status Dirops</label>
          <select name="status_dirops" class="form-select form-select-sm">
            <option value="">Semua</option>
            <?php foreach (REKAP_LABEL_SINGKAT as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['status_dirops'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Status Pembayaran</label>
          <select name="status_pembayaran" class="form-select form-select-sm">
            <option value="">Semua</option>
            <?php foreach (REKAP_LABEL_BAYAR as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['status_pembayaran'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6">
          <label class="form-label small mb-1">Lihat sebagai</label>
          <select name="grup" class="form-select form-select-sm">
            <?php foreach (REKAP_GRUPS as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['grup'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-2 col-6">
          <label class="form-label small mb-1">Urutkan</label>
          <select name="sort" class="form-select form-select-sm">
            <?php foreach (REKAP_SORTS as $k => $lab): ?>
              <option value="<?= e($k) ?>" <?= $f['sort'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-2 col-6">
          <label class="form-label small mb-1">Baris / halaman</label>
          <select name="per_page" class="form-select form-select-sm">
            <?php foreach ([25, 50, 100, 250] as $pp): ?>
              <option value="<?= $pp ?>" <?= (int)$f['per_page'] === $pp ? 'selected' : '' ?>><?= $pp ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="col-md-3 col-6 d-flex align-items-center gap-3">
          <div class="form-check mt-4">
            <input class="form-check-input" type="checkbox" name="hanya_selesai" value="1" id="hanyaSelesai" <?= $f['hanya_selesai'] ? 'checked' : '' ?>>
            <label class="form-check-label small" for="hanyaSelesai">Sudah dibayar saja</label>
          </div>
          <div class="form-check mt-4">
            <input class="form-check-input" type="checkbox" name="semua_baris" value="1" id="semuaBaris" <?= $f['semua_baris'] && $f['grup'] === 'tiket' ? 'checked' : '' ?>>
            <label class="form-check-label small" for="semuaBaris">Tampilkan semua</label>
          </div>
        </div>

        <div class="col-md-3 col-12 d-flex gap-2">
          <button type="submit" class="btn btn-brand btn-sm flex-fill"><i class="bi bi-funnel"></i> Terapkan Filter</button>
          <a href="<?= BASE_URL ?>/rekap/list.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-counterclockwise"></i> Reset</a>
        </div>
      </div>
      <input type="hidden" name="hal" value="1">
    </div>
  </div>
</form>

<!-- ==================== KARTU RINGKASAN ==================== -->
<div class="row g-3 mb-4">
  <?php
  $kpi = [
      ['Jumlah Tiket', (int)$t['n'] . ' tiket', 'bi-receipt', '#1e8449'],
      ['Total Berat Basah', rekap_num($t['kg'], 2) . ' KG', 'bi-box-seam', '#2c7fb8'],
      ['Total Sebelum Pajak', format_rupiah($t['bruto']), 'bi-cash-stack', '#6c757d'],
      ['Potongan Pajak', format_rupiah($t['pot']), 'bi-dash-circle', '#b8860b'],
      ['Total Setelah Pajak', format_rupiah($t['net']), 'bi-wallet2', '#1e8449'],
      ['Sudah Dibayar', (int)$data['per_status']['selesai'] . ' tiket', 'bi-check2-circle', '#2e8b57'],
  ];
  foreach ($kpi as $k): ?>
    <div class="col-6 col-md-4 col-xl-2">
      <div class="card stat-card h-100" style="background:<?= $k[3] ?>">
        <div class="card-body py-3">
          <div class="small text-white-50"><i class="bi <?= $k[2] ?>"></i> <?= e($k[0]) ?></div>
          <div class="fs-5 fw-bold text-white mt-1" style="font-size:1.05rem!important;"><?= e($k[1]) ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- ==================== TABEL UTAMA ==================== -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
    <span class="fw-bold"><i class="bi bi-table"></i> <?= e(REKAP_GRUPS[$f['grup']]) ?>
      <span class="text-muted small fw-normal">(<?= (int)$t['n'] ?> tiket sesuai filter)</span></span>
    <div class="d-flex gap-2 align-items-center">
      <label class="small text-muted mb-0" for="sortJump">Urutkan</label>
      <select id="sortJump" class="form-select form-select-sm" style="width:auto" onchange="location=this.value">
        <?php foreach (REKAP_SORTS as $k => $lab): ?>
          <option value="<?= e(rekap_url($f, BASE_URL . '/rekap/list.php', ['sort' => $k, 'hal' => 1])) ?>" <?= $f['sort'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0">
        <thead class="table-light">
          <tr>
            <?php foreach ($tabel['columns'] as $ci => $col): ?>
              <th><?= e($col['label']) ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php if (!$tabel['rows']): ?>
            <tr><td colspan="<?= count($tabel['columns']) ?>" class="text-center text-muted py-4">
              Tidak ada data untuk filter ini. Coba ubah periode atau reset filter.
            </td></tr>
          <?php endif; ?>
          <?php foreach ($tabel['rows'] as $ri => $row):
              $isTotal = $tabel['totals_row'] && $ri === count($tabel['rows']) - 1; ?>
            <tr class="<?= $isTotal ? 'table-success fw-bold' : '' ?>">
              <?php foreach ($row as $ci => $cell):
                  $label = $tabel['columns'][$ci]['label'] ?? '';
                  $type  = $tabel['columns'][$ci]['t'] ?? 'text';
                  $val   = rekap_sel($cell);
                  echo '<td>';
                  if ($label === 'No Ticket' && !$isTotal && $f['grup'] === 'tiket' && isset($data['rows'][$ri])) {
                      ?><a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= (int)$data['rows'][$ri]['id'] ?>" class="text-decoration-none fw-semibold"><?= e($val) ?></a><?php
                  } elseif (in_array($label, $statusCols, true) && !$isTotal) {
                      $cls = $badgeKelas[(string)$val] ?? 'secondary';
                      ?><span class="badge text-bg-<?= $cls ?>"><?= e($val) ?></span><?php
                  } elseif (in_array($type, ['money', 'num', 'int'], true)) {
                      ?><span class="text-nowrap"><?= $type === 'money' ? '' : '' ?><?= e(rekap_num($val, $type === 'num' ? 2 : ($type === 'money' ? 0 : 0))) ?></span><?php
                  } elseif ($type === 'date') {
                      echo e(format_tanggal($val));
                  } else {
                      ?><span class="rekap-cell" title="<?= e($val) ?>"><?= e($val === '' ? '-' : $val) ?></span><?php
                  }
                  echo '</td>';
              endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <?php if ($f['grup'] === 'tiket' && $data['total_hal'] > 1): ?>
    <div class="card-footer bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
      <span class="small text-muted">
        Halaman <?= (int)$f['hal'] ?> dari <?= (int)$data['total_hal'] ?>
        (<?= (int)$data['grand_total'] ?> baris) &middot; ekspor mengambil <strong>semua</strong> baris, bukan hanya halaman ini
      </span>
      <nav class="d-flex gap-1">
        <?php
        $hal = (int)$f['hal'];
        $links = [];
        if ($hal > 1) $links['&laquo;'] = 1;
        if ($hal > 1) $links['&lsaquo;'] = $hal - 1;
        for ($i = max(1, $hal - 2); $i <= min($data['total_hal'], $hal + 2); $i++) $links[(string)$i] = $i;
        if ($hal < $data['total_hal']) $links['&rsaquo;'] = $hal + 1;
        if ($hal < $data['total_hal']) $links['&raquo;'] = $data['total_hal'];
        foreach ($links as $lab => $pn): ?>
          <a class="btn btn-sm btn-outline-success <?= $lab == (string)$hal ? 'active' : '' ?>"
             href="<?= e(rekap_url($f, BASE_URL . '/rekap/list.php', ['hal' => $pn])) ?>"><?= $lab ?></a>
        <?php endforeach; ?>
      </nav>
    </div>
  <?php endif; ?>
</div>

<?php if ($f['grup'] === 'tiket'): ?>
<!-- ==================== RINGKASAN CEPAT ==================== -->
<div class="row g-3">
  <?php
  $mini = [
      'Bulan'  => 'bulanan',
      'Daerah' => 'daerah',
      'PIC'    => 'pic',
      'Supplier' => 'vendor',
      'Status' => 'status',
  ];
  foreach ($mini as $judul => $grupKey):
      $miniData = rekap_fetch($pdo, array_merge($f, ['grup' => $grupKey]));
      if (empty($miniData['group_rows'])) continue;
  ?>
    <div class="col-md-6 col-xl-4">
      <div class="card border-0 shadow-sm h-100">
        <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
          <span><i class="bi bi-bar-chart"></i> Ringkasan per <?= e($judul) ?></span>
          <a class="small text-decoration-none" href="<?= e(rekap_url($f, BASE_URL . '/rekap/list.php', ['grup' => $grupKey, 'hal' => 1])) ?>">buka</a>
        </div>
        <div class="card-body p-0">
          <table class="table table-sm mb-0">
            <thead class="table-light"><tr><th><?= e($judul) ?></th><th class="text-end">Tiket</th><th class="text-end">KG</th><th class="text-end">Setelah Pajak</th></tr></thead>
            <tbody>
            <?php $limit = 6; $n = 0; foreach ($miniData['group_rows'] as $gr): if ($n++ >= $limit) break; ?>
              <tr>
                <td class="text-truncate" style="max-width:150px" title="<?= e($gr['label']) ?>"><?= e($gr['label']) ?></td>
                <td class="text-end"><?= (int)$gr['n'] ?></td>
                <td class="text-end"><?= rekap_num($gr['kg'], 0) ?></td>
                <td class="text-end"><?= format_rupiah($gr['net']) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (count($miniData['group_rows']) > $limit): ?>
              <tr class="table-light"><td colspan="4" class="small text-center">
                + <?= count($miniData['group_rows']) - $limit ?> kelompok lain
              </td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
