<?php
// =========================================================
// Ekspor Rekapitulasi ke Excel (.xlsx) dan PDF (.pdf)
// ---------------------------------------------------------
// Menerima semua filter yang sama dengan rekap/list.php.
// ?export=xlsx  -> unduh file Excel (multi sheet: rincian + ringkasan)
// ?export=pdf   -> unduh file PDF (A4 landscape, tabel bergaris)
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/rekap_data.php';
require_once __DIR__ . '/../includes/xlsx_writer.php';
require_once __DIR__ . '/../includes/pdf_writer.php';
require_login();

$user = current_user();
$data = rekap_fetch($pdo, rekap_parse_filters($_GET, $user['role'], $user['id']));
$f    = $data['filters'];
$t    = $data['totals'];
$type = ($_GET['export'] ?? 'xlsx') === 'pdf' ? 'pdf' : 'xlsx';

// Semua baris (tanpa paging) untuk file ekspor
$dataAll = $f['semua_baris'] ? $data : rekap_fetch($pdo, array_merge($f, ['semua_baris' => true]));
$tabelAll = rekap_tabel($dataAll);

// Ringkasan per dimensi, selalu dihitung ulang supaya sheet-nya lengkap
$ringkas = [];
foreach (['bulanan' => 'Ringkasan per Bulan', 'daerah' => 'Ringkasan per Daerah',
          'pic' => 'Ringkasan per PIC', 'vendor' => 'Ringkasan per Supplier',
          'status' => 'Ringkasan per Status'] as $gk => $judul) {
    $d = rekap_fetch($pdo, array_merge($f, ['semua_baris' => true, 'grup' => $gk]));
    if (!empty($d['group_rows'])) {
        $ringkas[$gk] = ['judul' => $judul, 'data' => $d, 'tabel' => rekap_tabel($d)];
    }
}

// ------------------------------------------------------------
// Deskripsi filter (dipakai di kop Excel & PDF)
// ------------------------------------------------------------
$filterLines = [];
if ($f['q'] !== '')              $filterLines[] = 'Pencarian: "' . $f['q'] . '"';
if ($f['daerah'])                $filterLines[] = 'Daerah: ' . $f['daerah'];
if ($f['vendor_id']) {
    $vn = $pdo->prepare("SELECT name FROM vendors WHERE id = ?");
    $vn->execute([$f['vendor_id']]);
    $filterLines[] = 'Supplier: ' . $vn->fetchColumn();
}
if ($f['pakai_pic_id']) {
    $un = $pdo->prepare("SELECT name FROM users WHERE id = ?");
    $un->execute([$f['pakai_pic_id']]);
    $filterLines[] = 'PIC: ' . $un->fetchColumn();
}
foreach (['status_approval' => 'Status Petugas', 'status_finance_approval' => 'Status Finance',
          'status_dirops' => 'Status Dirops', 'status_pembayaran' => 'Status Pembayaran'] as $k => $lab) {
    if ($f[$k]) {
        $mapAll = REKAP_LABEL_PETUGAS + REKAP_LABEL_BAYAR;
        $filterLines[] = $lab . ': ' . ($mapAll[$f[$k]] ?? $f[$k]);
    }
}
if ($f['hanya_selesai']) $filterLines[] = 'Hanya yang sudah dibayar';

$periode   = 'Periode: ' . rekap_label_periode($f);
$dibuatOleh = 'Dibuat oleh: ' . $user['name'] . ' (' . role_label($user['role']) . ') pada ' . date('d.m.Y H:i');
$namaDasar  = 'Rekap-Pembelian_' . str_replace([':', ' '], '', ($f['dari'] ?: 'semua')) . '-' . str_replace([':', ' '], '', ($f['sampai'] ?: 'semua'));

// ============================================================
// EXCEL
// ============================================================
if ($type === 'xlsx') {
    $xl = new XlsxWriter();

    $mainJudul = $f['grup'] === 'tiket' ? 'Rekap Tiket' : REKAP_GRUPS[$f['grup']];
    $mainTabel = $f['grup'] === 'tiket' ? $tabelAll : rekap_tabel($dataAll);

    $blocks = [
        ['type' => 'title', 'text' => 'REKAPITULASI PEMBELIAN - ' . $mainJudul],
        ['type' => 'subtitle', 'text' => $periode],
        ['type' => 'subtitle', 'text' => $dibuatOleh],
    ];
    if ($filterLines) {
        $blocks[] = ['type' => 'subtitle', 'text' => 'Filter: ' . implode('  |  ', $filterLines)];
    }
    $blocks[] = ['type' => 'subtitle', 'text' => 'Jumlah tiket: ' . (int)$t['n']
        . '   |   Total berat: ' . number_format((float)$t['kg'], 2, ',', '.') . ' KG'
        . '   |   Sebelum pajak: ' . number_format((float)$t['bruto'], 0, ',', '.')
        . '   |   Potongan: ' . number_format((float)$t['pot'], 0, ',', '.')
        . '   |   Setelah pajak: ' . number_format((float)$t['net'], 0, ',', '.')];
    $blocks[] = ['type' => 'spacer'];

    $widths = [];
    foreach ($mainTabel['columns'] as $i => $c) {
        $widths[$i] = max(9, min(34, (float)($c['w'] ?? 12)));
    }
    $headerRow = count($blocks) + 1;
    $blocks[] = ['type' => 'table', 'columns' => $mainTabel['columns'], 'rows' => $mainTabel['rows'], 'totals_row' => true];
    $lastRow = $headerRow + count($mainTabel['rows']);

    $xl->addSheet($mainJudul, $blocks, [
        'landscape'  => true,
        'widths'     => $widths,
        'freezeRows' => $headerRow,
        'autofilter' => 'A' . $headerRow . ':' . chr(65 + min(25, max(1, count($mainTabel['columns'])) - 1)) . $lastRow,
    ]);

    foreach ($ringkas as $gk => $r) {
        $b = [['type' => 'title', 'text' => $r['judul']], ['type' => 'subtitle', 'text' => $periode], ['type' => 'spacer']];
        $w = [];
        foreach ($r['tabel']['columns'] as $i => $c) $w[$i] = max(12, min(30, (float)($c['w'] ?? 14)));
        $b[] = ['type' => 'table', 'columns' => $r['tabel']['columns'], 'rows' => $r['tabel']['rows'], 'totals_row' => true];
        $xl->addSheet(mb_substr($r['judul'], 0, 31), $b, ['widths' => $w]);
    }

    // Lembar keterangan - supaya file bisa dibaca orang lain tanpa penjelasan lisan
    $xl->addSheet('Keterangan', [[
        'type' => 'table',
        'columns' => [['label' => 'Kolom', 't' => 'text'], ['label' => 'Penjelasan', 't' => 'text']],
        'rows' => [
            ['Total Sebelum Pajak', 'Berat Basah (KG) x Harga Basah. Sama dengan kolom total_harga di database.'],
            ['Potongan Pajak', 'PPh 0,25% bila supplier punya NPWP, 0,5% bila tidak.'],
            ['Total Setelah Pajak', 'Total Sebelum Pajak dikurangi Potongan Pajak. Nilai inilah yang dibayarkan ke supplier.'],
            ['DRC (%)', '(Harga Basah / Harga Harian Notaring) x 100, dihitung otomatis oleh sistem.'],
            ['Status Petugas/Finance/Dirops', 'Hasil approval pada tiap tahap sesuai alur PIC -> Petugas -> Finance -> Dirops.'],
            ['Status Pembayaran', 'Proses akhir oleh Finance setelah Dirops menyetujui.'],
            ['Semua angka', 'Sudah termasuk baris TOTAL di baris terakhir tiap tabel.'],
        ],
    ]], ['widths' => [26, 96]]);

    $xl->download($namaDasar . '_' . preg_replace('/[^a-z0-9]/i', '', $f['grup']) . '.xlsx');
}

// ============================================================
// PDF
// ============================================================
$pdf = new PdfWriter(true);
$pdf->heading('REKAPITULASI PEMBELIAN', [$periode, $dibuatOleh, $filterLines ? 'Filter: ' . implode('  |  ', $filterLines) : '']);

$pdf->sectionTitle('RINGKASAN UMUM', REKAP_GRUPS[$f['grup']]);
$pdf->kvBlock([
    ['Jumlah tiket', (int)$t['n'] . ' tiket'],
    ['Total berat basah', number_format((float)$t['kg'], 2, ',', '.') . ' KG'],
    ['Total sebelum pajak', format_rupiah($t['bruto'])],
    ['Potongan pajak', format_rupiah($t['pot'])],
    ['Total setelah pajak (dibayarkan)', format_rupiah($t['net'])],
    ['Sudah dibayar / total', (int)$data['per_status']['selesai'] . ' dari ' . (int)$t['n'] . ' tiket'],
]);

if ($f['grup'] !== 'tiket') {
    $gtabel = rekap_tabel($dataAll);
    $pdf->sectionTitle('HASIL PENGELOMPOKAN: ' . strtoupper(REKAP_GRUPS[$f['grup']]));
    $pdf->table(rekap_pdf_cols($gtabel['columns'], true), $gtabel['rows'], ['totals_row' => true, 'fontSize' => 7.6]);
}

foreach ($ringkas as $gk => $r) {
    if ($f['grup'] === $gk) continue;
    $rows = array_slice($r['tabel']['rows'], 0, 12);
    $pdf->sectionTitle(strtoupper($r['judul']), count($r['tabel']['rows']) > 12 ? 'menampilkan 12 teratas dari ' . count($r['tabel']['rows']) : '');
    $pdf->table(rekap_pdf_cols($r['tabel']['columns'], true), $rows, ['totals_row' => true, 'fontSize' => 7.4]);
}

$pdf->sectionTitle('RINCIAN PEMBELIAN', (int)$t['n'] . ' baris' . ($f['grup'] === 'tiket' ? '' : ' (semua tiket sesuai filter)'));
$dtabel = rekap_tabel_pdf_detail($dataAll);
$pdf->table($dtabel['columns'], $dtabel['rows'], ['totals_row' => true, 'fontSize' => 6.6, 'rowHeight' => 10.5]);
$pdf->footnote('Dokumen dibuat otomatis oleh Purchasing Management System. Potongan pajak memakai asumsi NPWP pada data transaksi saat rekap dibuat.');
$pdf->download($namaDasar . '.pdf', 'Rekapitulasi Pembelian');
