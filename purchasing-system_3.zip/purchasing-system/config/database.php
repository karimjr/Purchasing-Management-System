<?php
// =========================================================
// Konfigurasi koneksi database
// Sesuaikan dengan pengaturan phpMyAdmin / MySQL di server kamu
// =========================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'potensib_purchasing_db');
define('DB_USER', 'potensib_pbs');
define('DB_PASS', 'arsari-group');

// Auto-detect base URL so links work no matter what folder the app sits in
// (e.g. http://localhost/purchasing-system)
$appPath = str_replace('\\', '/', dirname(__DIR__));
$docRoot = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'));
$baseUrl = $docRoot !== '' ? str_replace($docRoot, '', $appPath) : '';
define('BASE_URL', $baseUrl === '' ? '' : $baseUrl);

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}
