<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'petugas']);
$pageTitle = 'Approval Pembelian';

$filter = $_GET['status'] ?? 'menunggu';
$allowed = ['menunggu', 'revisi_harga', 'disetujui', 'ditolak', 'semua'];
if (!in_array($filter, $allowed)) $filter = 'menunggu';

$sql = "SELECT p.*, v.name as vendor_name, u.name as pic_name, u.whatsapp as pic_whatsapp
        FROM purchases p
        JOIN vendors v ON v.id = p.vendor_id
        JOIN users u ON u.id = p.pic_id";
$params = [];
if ($filter !== 'semua') {
    $sql .= " WHERE p.status_approval = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY p.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$purchases = $stmt->fetchAll();

$waUsersByRole = [
    'petugas' => get_users_with_wa($pdo, ['petugas']),
    'dirops'  => get_users_with_wa($pdo, ['dirops']),
    'finance' => get_users_with_wa($pdo, ['finance']),
];

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-check2-square"></i> Approval Pembelian</h4>
<p class="text-muted small mt-n2">Data yang sudah disetujui tetap ditampilkan pada tab Disetujui. Gunakan tombol WhatsApp untuk mengingatkan Finance. Untuk melihat progres lengkap (approval + pembayaran) semua tiket, buka menu <a href="<?= BASE_URL ?>/pembelian/list.php">Daftar Pembelian</a>.</p>

<ul class="nav nav-pills mb-4">
  <?php foreach (['menunggu' => 'Menunggu', 'revisi_harga' => 'Revisi Harga', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak', 'semua' => 'Semua'] as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?= $filter === $key ? 'active bg-success' : 'text-dark' ?>" href="?status=<?= $key ?>"><?= $label ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="table-responsive">
  <table class="table table-hover align-middle bg-white">
    <thead class="table-light">
      <tr>
        <th>No Ticket</th>
        <th>Tanggal</th>
        <th>PIC</th>
        <th>Supplier</th>
        <th>Berat Basah</th>
        <th>DRC</th>
        <th>Harga Pembayaran</th>
        <th>Status Approval</th>
        <th>Status Pembayaran</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($purchases)): ?>
        <tr><td colspan="10" class="text-center text-muted py-4">Tidak ada data.</td></tr>
      <?php else: foreach ($purchases as $row): ?>
        <tr>
          <td><?= e($row['no_ticket']) ?></td>
          <td><?= format_tanggal($row['tanggal']) ?></td>
          <td><?= e($row['pic_name']) ?></td>
          <td><?= e($row['vendor_name']) ?></td>
          <td><?= e($row['berat_basah']) ?> KG</td>
          <td><?= e($row['drc']) ?> %</td>
          <td><?= format_rupiah($row['total_harga']) ?></td>
          <td><?= badge_approval($row['status_approval']) ?></td>
          <td><?= badge_pembayaran($row['status_pembayaran']) ?></td>
          <td>
            <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
            <?php if ($row['status_approval'] === 'menunggu'): ?>
              <a href="<?= BASE_URL ?>/approval/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses"><i class="bi bi-check2-square"></i> Proses</a>
            <?php elseif ($row['status_approval'] === 'revisi_harga' && !empty($row['pic_whatsapp'])): ?>
              <?php $revisionMsg = "Permisi, mohon dibantu menyesuaikan Harga Basah pada tiket {$row['no_ticket']} sesuai catatan Petugas: " . ($row['catatan_revisi_harga'] ?: 'mohon dilakukan negosiasi ulang sesuai arahan terbaru') . ". Data dan foto lainnya tidak perlu diinput ulang. Setelah disesuaikan, silakan simpan kembali agar dapat kami periksa. Terima kasih."; ?>
              <a href="<?= e(wa_link($row['pic_whatsapp'], $revisionMsg)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success" title="Kirim permintaan revisi ke PIC"><i class="bi bi-whatsapp"></i> WA ke PIC</a>
            <?php else: ?>
              <?= render_wa_button($row, $waUsersByRole) ?>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
