<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'petugas']);
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name as vendor_name, u.name as pic_name FROM purchases p
                        JOIN vendors v ON v.id = p.vendor_id JOIN users u ON u.id = p.pic_id WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data tidak ditemukan.');
    redirect('/approval/list.php');
}
if ($purchase['status_approval'] !== 'menunggu') {
    set_flash('warning', 'Pembelian ini sudah diproses sebelumnya.');
    redirect('/pembelian/detail.php?id=' . $id);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $decision = $_POST['decision'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');

    if (!in_array($decision, ['disetujui', 'ditolak', 'revisi_harga'])) {
        set_flash('danger', 'Keputusan tidak valid.');
    } elseif (in_array($decision, ['ditolak','revisi_harga']) && $catatan === '') {
        set_flash('danger', 'Catatan wajib diisi untuk penolakan atau permintaan revisi harga.');
    } else {
        // Setelah Petugas menyetujui, tiket masuk ke Finance untuk verifikasi internal.
        $stmt = $pdo->prepare("UPDATE purchases SET status_approval=?, catatan_approval=?, catatan_revisi_harga=?, revisi_harga_by=?, revisi_harga_at=IF(?='revisi_harga', NOW(), revisi_harga_at), approved_by=IF(?='disetujui', ?, approved_by), approved_at=IF(?='disetujui', NOW(), approved_at), last_reminder_stage=NULL, last_reminder_at=NULL WHERE id=?");
        $stmt->execute([$decision, $catatan ?: null, $decision === 'revisi_harga' ? $catatan : null, $decision === 'revisi_harga' ? $user['id'] : null, $decision, $decision, $user['id'], $decision, $id]);

        $label = $decision === 'disetujui' ? 'Disetujui oleh Petugas' : ($decision === 'revisi_harga' ? 'Diminta Revisi Harga oleh Petugas' : 'Ditolak oleh Petugas');
        log_activity($pdo, $id, $label, $catatan ?: null);

        // Notifikasi ke PIC pemilik data: pembelian sudah diproses oleh Petugas
        $decisionLabel = $decision === 'disetujui' ? 'disetujui' : ($decision === 'revisi_harga' ? 'diminta revisi harga' : 'ditolak');
        create_notification(
            $pdo,
            $purchase['pic_id'],
            "Pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Petugas ({$user['name']}).",
            '/pembelian/detail.php?id=' . $id,
            $id,
            'approval_selesai'
        );
        if ($decision !== 'revisi_harga') {
            notify_user_wa(
                $pdo,
                $purchase['pic_id'],
                "Permisi, kami informasikan bahwa pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Petugas ({$user['name']}).",
                $id
            );
        }

        if ($decision === 'revisi_harga') {
            create_notification($pdo, $purchase['pic_id'], "Permintaan revisi harga untuk pembelian {$purchase['no_ticket']} dari Petugas ({$user['name']}). Catatan: {$catatan}", '/pembelian/edit.php?id=' . $id, $id, 'revisi_harga');
            notify_user_wa($pdo, $purchase['pic_id'], "Permisi, mohon dibantu menyesuaikan harga pembelian {$purchase['no_ticket']} sesuai catatan Petugas: {$catatan}. Data lain dan foto tidak perlu diinput ulang. Terima kasih.", $id);
        }

        // Tahap berikutnya adalah verifikasi/approval Finance, bukan Dirops.
        if ($decision === 'disetujui') {
            notify_role(
                $pdo, ['finance', 'admin'],
                "Pembelian {$purchase['no_ticket']} dari {$purchase['pic_name']} telah disetujui Petugas dan menunggu verifikasi/approval Finance.",
                '/finance/list.php?status=menunggu_finance', $id, 'finance_menunggu', $user['id']
            );
            notify_role_wa(
                $pdo, ['finance'],
                "Permisi Bapak/Ibu Finance, mohon dibantu verifikasi dan approval pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . "), yang telah disetujui Petugas. Setelah disetujui Finance, mohon dilanjutkan permintaan approval kepada Bapak/Ibu Direktur Operasional. Terima kasih.",
                $id
            );
        }

        set_flash('success', "Pembelian {$purchase['no_ticket']} telah $decision.");
        redirect('/approval/list.php?status=' . ($decision === 'disetujui' ? 'disetujui' : ($decision === 'revisi_harga' ? 'revisi_harga' : 'ditolak')));
    }
}

$pageTitle = 'Proses Approval';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-check2-square"></i> Proses Approval - <?= e($purchase['no_ticket']) ?></h4>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Ringkasan Pembelian</div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr><td class="label text-success fw-semibold" style="width:45%">Tanggal</td><td><?= format_tanggal($purchase['tanggal']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">PIC</td><td><?= e($purchase['pic_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Supplier</td><td><?= e($purchase['vendor_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">No Nota</td><td><?= e($purchase['no_nota']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Berat Basah</td><td><?= e($purchase['berat_basah']) ?> KG</td></tr>
          <tr><td class="label text-success fw-semibold">DRC</td><td><?= e($purchase['drc']) ?> %</td></tr>
          <tr><td class="label text-success fw-semibold">Harga Basah</td><td><?= format_rupiah($purchase['harga_basah']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Harga Pembayaran</td><td class="fw-bold"><?= format_rupiah($purchase['total_harga']) ?></td></tr>
        </table>
        <?php
        // v12: peninjau melihat SEMUA berkas tiket (foto utama + dokumen pendukung),
        // tidak hanya purchases.foto. Tampilan dipakai dari helper yang sama dengan
        // halaman detail, jadi tidak bisa beda-beda kalau aturannya diubah.
        $fotosTiket = purchase_fotos($pdo, $purchase);
        if ($fotosTiket) {
            echo foto_galeri_html($fotosTiket, ['purchase_id' => $id]);
        } ?>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Keputusan</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="id" value="<?= $id ?>">
          <div class="mb-3">
            <label class="form-label">Catatan / alasan <span class="text-muted">(wajib untuk Revisi Harga dan Penolakan)</span></label>
            <textarea name="catatan" class="form-control" rows="3" placeholder="Contoh: Data sesuai, DRC terverifikasi."></textarea>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" name="decision" value="disetujui" class="btn btn-success flex-fill">
              <i class="bi bi-check-lg"></i> Setujui
            </button>
            <button type="submit" name="decision" value="revisi_harga" class="btn btn-warning flex-fill" onclick="return confirm('Minta PIC menyesuaikan harga?')"><i class="bi bi-arrow-repeat"></i> Minta Revisi Harga</button>
            <button type="submit" name="decision" value="ditolak" class="btn btn-danger flex-fill" onclick="return confirm('Tolak pembelian ini?')">
              <i class="bi bi-x-lg"></i> Tolak
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
