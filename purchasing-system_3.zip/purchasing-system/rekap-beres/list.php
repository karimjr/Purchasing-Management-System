<?php
// =========================================================
// Rekapitulasi BERES
// ---------------------------------------------------------
// Rekapitulasi transaksi yang SUDAH BERES (status bayar "Done").
//   1. Filter periode + supplier + daerah + pencarian.
//   2. Kartu ringkasan angka.
//   3. Ringkasan per PIC.
//   4. Tabel rincian + pagination.
// Ekspor Excel/PDF mengikuti filter yang sedang aktif.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/rekap_beres_data.php';
require_login();

$user = current_user();
$data = rb_fetch($pdo, rb_parse_filters($_GET, $user['role'], $user['id']));
$f    = $data['filters'];
$t    = $data['totals'];

$daerahList = $pdo->query("SELECT DISTINCT daerah FROM purchases WHERE daerah <> '' ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
if (!$daerahList) {
    $daerahList = $pdo->query("SELECT DISTINCT daerah FROM daily_prices ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
}

// Daftar supplier (hanya yang punya transaksi)
$supplierList = $pdo->query("
    SELECT DISTINCT v.id, v.name
    FROM purchases p
    JOIN vendors v ON v.id = p.vendor_id
    ORDER BY v.name
")->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = 'Rekapitulasi Beres';
include __DIR__ . '/../includes/header.php';
?>
<style>
/* ---- gaya khusus halaman Rekap Beres (prefix rb-) ---- */
.rb-chip {
  display: inline-block; font-size: .77rem; padding: .3rem .75rem;
  border-radius: 2rem; border: 1px solid #dfe5e9; background: #fff;
  color: #444; text-decoration: none; white-space: nowrap;
}
.rb-chip:hover { border-color: var(--brand-green); color: var(--brand-green-dark); }
.rb-chip.active { background: var(--brand-green); border-color: var(--brand-green); color: #fff; }

.rb-kpi { border: none; border-radius: .8rem; color: #fff; box-shadow: 0 1px 4px rgba(0,0,0,.10); }
.rb-kpi .rb-kpi-num { font-size: 1.12rem !important; }

.rb-tbl th {
  font-size: .74rem; text-transform: uppercase; letter-spacing: .03em;
  color: #5b6b79; white-space: nowrap; background: #f6f8f9 !important;
}
.rb-tbl td { font-size: .88rem; vertical-align: middle; }
.rb-tbl .rb-num { white-space: nowrap; }
.rb-row-total td {
  background: var(--brand-green-light) !important;
  color: var(--brand-green-dark); font-weight: 700;
  border-top: 2px solid var(--brand-green);
}
.rb-picbar { height: 4px; width: 100%; max-width: 150px; border-radius: 2px; background: #e9eef1; margin-top: 4px; overflow: hidden; }
.rb-picbar > span { display: block; height: 100%; background: var(--brand-green); border-radius: 2px; }
.rb-empty { padding: 2.5rem 1rem; text-align: center; color: #8a949c; }
.rb-empty .bi { font-size: 2rem; display: block; margin-bottom: .5rem; color: #c3ccd2; }
</style>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <div>
    <h4 class="mb-1"><i class="bi bi-patch-check-fill"></i> Rekapitulasi Beres</h4>
    <div class="small text-muted">
      <span class="badge text-bg-success bg-opacity-10 text-success border border-success-subtle me-1"><i class="bi bi-check2-circle"></i> Hanya yang sudah dibayar</span>
      Periode <strong><?= e(rekap_label_periode($f)) ?></strong>
      &middot; <?= e(rb_label_grup($f)) ?>
      <?php if ($user['role'] === 'pic'): ?>&middot; hanya data Anda sendiri<?php endif; ?>
    </div>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <a href="<?= BASE_URL ?>/rekap/list.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-clipboard-data"></i> Rekap Lengkap</a>
    <button type="submit" form="rbForm" name="export" value="xlsx" formaction="<?= BASE_URL ?>/rekap-beres/export.php" class="btn btn-success btn-sm">
      <i class="bi bi-file-earmark-excel"></i> Export Excel
    </button>
    <button type="submit" form="rbForm" name="export" value="pdf" formaction="<?= BASE_URL ?>/rekap-beres/export.php" class="btn btn-outline-danger btn-sm">
      <i class="bi bi-file-earmark-pdf"></i> Export PDF
    </button>
  </div>
</div>

<!-- ==================== FILTER ==================== -->
<form method="get" action="<?= BASE_URL ?>/rekap-beres/list.php" id="rbForm" class="mb-4">
  <div class="card border-0 shadow-sm">
    <div class="card-body py-3">
      <div class="row g-2 align-items-end mb-2">
        <div class="col-6 col-md-3">
          <label class="form-label small mb-1 text-muted fw-semibold">Dari tanggal</label>
          <input type="date" name="dari" value="<?= e($f['dari']) ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small mb-1 text-muted fw-semibold">Sampai tanggal</label>
          <input type="date" name="sampai" value="<?= e($f['sampai']) ?>" class="form-control form-control-sm">
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small mb-1 text-muted fw-semibold">Supplier</label>
          <select name="supplier" class="form-select form-select-sm">
            <option value="">Semua supplier</option>
            <?php foreach ($supplierList as $s): ?>
              <option value="<?= (int)$s['id'] ?>" <?= (int)$f['supplier'] === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-3">
          <label class="form-label small mb-1 text-muted fw-semibold">Daerah</label>
          <select name="daerah" class="form-select form-select-sm">
            <option value="">Semua daerah</option>
            <?php foreach ($daerahList as $d): ?>
              <option value="<?= e($d) ?>" <?= $f['daerah'] === $d ? 'selected' : '' ?>><?= e($d) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="row g-2 align-items-end mb-3">
        <div class="col-md-7 col-12">
          <label class="form-label small mb-1 text-muted fw-semibold">Periode cepat</label>
          <div class="d-flex flex-wrap gap-1">
            <?php foreach (REKAP_PERIODE_PESAT as $key => $label): ?>
              <?php list($qd, $qs) = rb_quick_range($key); ?>
              <a class="rb-chip <?= ($f['dari'] === $qd && $f['sampai'] === $qs) ? 'active' : '' ?>"
                 href="<?= e(rb_url($f, BASE_URL . '/rekap-beres/list.php', ['quick' => $key, 'dari' => '', 'sampai' => '', 'hal' => 1])) ?>">
                <?= e($label) ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="col-md-5 col-12">
          <label class="form-label small mb-1 text-muted fw-semibold">Cari</label>
          <div class="input-group input-group-sm">
            <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
            <input type="text" name="q" value="<?= e($f['q']) ?>" class="form-control"
                   placeholder="No Ticket, No Nota, supplier...">
          </div>
        </div>
      </div>
      <div class="row g-2">
        <div class="col-12 d-flex gap-2">
          <button type="submit" class="btn btn-brand btn-sm"><i class="bi bi-funnel"></i> Terapkan</button>
          <a href="<?= BASE_URL ?>/rekap-beres/list.php" class="btn btn-outline-secondary btn-sm" title="Reset semua filter"><i class="bi bi-arrow-counterclockwise"></i></a>
        </div>
      </div>
      <input type="hidden" name="hal" value="1">
    </div>
  </div>
</form>

<!-- ==================== KARTU RINGKASAN ==================== -->
<div class="row g-3 mb-4">
  <?php
  $kpi = [
      ['Jumlah Tiket Beres', (int)$t['n'] . ' tiket', 'bi-receipt', '#1e8449'],
      ['Total Berat Basah', number_format((float)$t['kg'], 2, ',', '.') . ' KG', 'bi-box-seam', '#2c7fb8'],
      ['Total Sebelum Pajak', format_rupiah($t['bruto']), 'bi-cash-stack', '#5b6b79'],
      ['Total Setelah Pajak', format_rupiah($t['net']), 'bi-wallet2', '#16693a'],
  ];
  foreach ($kpi as $k): ?>
    <div class="col-6 col-xl-3">
      <div class="card rb-kpi h-100" style="background:<?= $k[3] ?>">
        <div class="card-body py-3">
          <div class="small text-white-50"><i class="bi <?= $k[2] ?>"></i> <?= e($k[0]) ?></div>
          <div class="rb-kpi-num fw-bold text-white mt-1"><?= e($k[1]) ?></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<?php if (!$data['rows'] && (int)$t['n'] === 0): ?>
  <div class="card border-0 shadow-sm mb-4">
    <div class="rb-empty">
      <i class="bi bi-inbox"></i>
      Belum ada transaksi beres untuk filter ini.<br>
      <span class="small">Coba ubah periode / pilih supplier lain, atau <a href="<?= BASE_URL ?>/rekap-beres/list.php">reset filter</a>.</span>
    </div>
  </div>
<?php else: ?>

<!-- ==================== RINGKASAN PER PIC ==================== -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-header bg-white py-2">
    <span class="fw-bold"><i class="bi bi-bar-chart"></i> Ringkasan per PIC</span>
    <span class="small text-muted d-none d-sm-inline">&mdash; proporsi berdasarkan total setelah pajak</span>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 rb-tbl">
        <thead>
          <tr>
            <th>PIC</th>
            <th class="text-end">Tiket</th>
            <th class="text-end">Berat (KG)</th>
            <th class="text-end">Sebelum Pajak</th>
            <th class="text-end">Setelah Pajak</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $netTotal = max(0.0001, (float)$t['net']);
          foreach ($data['per_pic'] as $r):
              $pct = (float)$r['net'] > 0 ? (int)round(((float)$r['net'] / $netTotal) * 100) : 0;
          ?>
            <tr>
              <td>
                <span class="fw-semibold"><?= e($r['pic']) ?></span>
                <span class="small text-muted ms-1">(<?= $pct ?>%)</span>
                <span class="rb-picbar"><span style="width:<?= $pct ?>%"></span></span>
              </td>
              <td class="text-end rb-num"><?= (int)$r['n'] ?></td>
              <td class="text-end rb-num"><?= number_format((float)$r['kg'], 2, ',', '.') ?></td>
              <td class="text-end rb-num"><?= format_rupiah($r['bruto']) ?></td>
              <td class="text-end rb-num fw-semibold"><?= format_rupiah($r['net']) ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="rb-row-total">
            <td>TOTAL</td>
            <td class="text-end rb-num"><?= (int)$t['n'] ?></td>
            <td class="text-end rb-num"><?= number_format((float)$t['kg'], 2, ',', '.') ?></td>
            <td class="text-end rb-num"><?= format_rupiah($t['bruto']) ?></td>
            <td class="text-end rb-num"><?= format_rupiah($t['net']) ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- ==================== TABEL RINCIAN ==================== -->
<div class="card border-0 shadow-sm mb-4">
  <div class="card-header bg-white d-flex flex-wrap justify-content-between align-items-center gap-2 py-2">
    <span class="fw-bold"><i class="bi bi-table"></i> Rincian
      <span class="text-muted small fw-normal">(<?= (int)$t['n'] ?> tiket sesuai filter)</span></span>
    <div class="d-flex gap-2 align-items-center">
      <label class="small text-muted mb-0" for="rbSortJump">Urutkan</label>
      <select id="rbSortJump" class="form-select form-select-sm" style="width:auto" onchange="location=this.value">
        <?php foreach (RB_SORTS as $k => $lab): ?>
          <option value="<?= e(rb_url($f, BASE_URL . '/rekap-beres/list.php', ['sort' => $k, 'hal' => 1])) ?>" <?= $f['sort'] === $k ? 'selected' : '' ?>><?= e($lab) ?></option>
        <?php endforeach; ?>
      </select>
      <form method="get" action="<?= BASE_URL ?>/rekap-beres/list.php" class="m-0">
        <input type="hidden" name="dari" value="<?= e($f['dari']) ?>">
        <input type="hidden" name="sampai" value="<?= e($f['sampai']) ?>">
        <input type="hidden" name="daerah" value="<?= e($f['daerah']) ?>">
        <input type="hidden" name="supplier" value="<?= e($f['supplier'] ?: '') ?>">
        <input type="hidden" name="q" value="<?= e($f['q']) ?>">
        <input type="hidden" name="sort" value="<?= e($f['sort']) ?>">
        <input type="hidden" name="hal" value="1">
        <select name="per_page" class="form-select form-select-sm" style="width:auto" onchange="this.form.submit()">
          <?php foreach ([25, 50, 100] as $pp): ?>
            <option value="<?= $pp ?>" <?= (int)$f['per_page'] === $pp ? 'selected' : '' ?>><?= $pp ?> / hal</option>
          <?php endforeach; ?>
        </select>
      </form>
    </div>
  </div>
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover align-middle mb-0 rb-tbl">
        <thead>
          <tr>
            <th>No Ticket</th>
            <th>Tanggal</th>
            <th>Daerah</th>
            <th>PIC</th>
            <th>Supplier</th>
            <th class="text-end">Berat (KG)</th>
            <th class="text-end">Sebelum Pajak</th>
            <th class="text-end">Setelah Pajak</th>
            <th>Tgl Dibayar</th>
          </tr>
        </thead>
        <tbody>
          <?php if (!$data['rows']): ?>
            <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada data untuk filter ini.</td></tr>
          <?php endif; ?>
          <?php foreach ($data['rows'] as $r): ?>
            <tr>
              <td><a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= (int)$r['id'] ?>" class="text-decoration-none fw-semibold text-success"><?= e($r['no_ticket']) ?></a></td>
              <td class="rb-num"><?= e(format_tanggal($r['tanggal'])) ?></td>
              <td><?= e($r['daerah']) ?></td>
              <td><?= e($r['pic_name']) ?></td>
              <td class="text-truncate" style="max-width:220px" title="<?= e($r['vendor_name']) ?>"><?= e($r['vendor_name']) ?></td>
              <td class="text-end rb-num"><?= number_format((float)$r['berat_basah'], 2, ',', '.') ?></td>
              <td class="text-end rb-num"><?= format_rupiah($r['total_harga']) ?></td>
              <td class="text-end rb-num fw-semibold"><?= format_rupiah($r['nilai_net']) ?></td>
              <td class="rb-num"><?= $r['processed_at'] ? e(format_tanggal($r['processed_at'])) : '-' ?></td>
            </tr>
          <?php endforeach; ?>
          <tr class="rb-row-total">
            <td>TOTAL (<?= (int)$t['n'] ?> tiket)</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td class="text-end rb-num"><?= number_format((float)$t['kg'], 2, ',', '.') ?></td>
            <td class="text-end rb-num"><?= format_rupiah($t['bruto']) ?></td>
            <td class="text-end rb-num"><?= format_rupiah($t['net']) ?></td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <?php if ($data['total_hal'] > 1): ?>
    <div class="card-footer bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
      <span class="small text-muted">
        Halaman <?= (int)$f['hal'] ?> dari <?= (int)$data['total_hal'] ?>
        (<?= (int)$data['grand_total'] ?> baris) &middot; ekspor mengambil <strong>semua</strong> baris
      </span>
      <nav class="d-flex gap-1 flex-wrap">
        <?php
        $hal = (int)$f['hal'];
        $links = [];
        if ($hal > 1) $links['&laquo;'] = 1;
        if ($hal > 1) $links['&lsaquo;'] = $hal - 1;
        for ($i = max(1, $hal - 2); $i <= min($data['total_hal'], $hal + 2); $i++) $links[(string)$i] = $i;
        if ($hal < $data['total_hal']) $links['&rsaquo;'] = $hal + 1;
        if ($hal < $data['total_hal']) $links['&raquo;'] = $data['total_hal'];
        foreach ($links as $lab => $pn): ?>
          <a class="btn btn-sm btn-outline-success <?= $lab == (string)$hal ? 'active' : '' ?>"
             href="<?= e(rb_url($f, BASE_URL . '/rekap-beres/list.php', ['hal' => $pn])) ?>"><?= $lab ?></a>
        <?php endforeach; ?>
      </nav>
    </div>
  <?php endif; ?>
</div>

<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>