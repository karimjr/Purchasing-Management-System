<?php
// =========================================================
// Ekspor Rekapitulasi BERES ke Excel (.xlsx) dan PDF (.pdf)
// ---------------------------------------------------------
// Menerima filter yang sama dengan rekap-beres/list.php:
//   ?export=xlsx  -> file Excel (sheet Rincian + Per PIC + Keterangan)
//   ?export=pdf   -> file PDF (A4 landscape, tabel tipis)
// Semua angka dihitung dari fungsi yang sama dengan halaman
// layar (includes/rekap_beres_data.php), jadi hasilnya PERSIS
// sama dengan yang tampil di layar.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/rekap_beres_data.php';
require_once __DIR__ . '/../includes/xlsx_writer.php';
require_once __DIR__ . '/../includes/pdf_writer.php';
require_login();

$user = current_user();
$data = rb_fetch($pdo, rb_parse_filters($_GET, $user['role'], $user['id']));
$f    = $data['filters'];   // pakai filter hasil rb_fetch (sudah berisi supplier_nama)
$t    = $data['totals'];
$type = (($_GET['export'] ?? 'xlsx') === 'pdf') ? 'pdf' : 'xlsx';

// ------------------------------------------------------------
// Kolom rincian tipis (sama dengan tampilan layar)
// ------------------------------------------------------------
$cols = [
    ['label' => 'No Ticket',        'pdfLabel' => 'NO TICKET',     't' => 'text',  'w' => 16, 'pdfW' => 70],
    ['label' => 'Tanggal',          'pdfLabel' => 'TANGGAL',       't' => 'date',  'w' => 11, 'pdfW' => 46],
    ['label' => 'Daerah',           'pdfLabel' => 'DAERAH',        't' => 'text',  'w' => 14, 'pdfW' => 56],
    ['label' => 'PIC',              'pdfLabel' => 'PIC',           't' => 'text',  'w' => 15, 'pdfW' => 56],
    ['label' => 'Supplier',         'pdfLabel' => 'SUPPLIER',      't' => 'text',  'w' => 22, 'pdfW' => 84],
    ['label' => 'Berat (KG)',       'pdfLabel' => 'BERAT (KG)',    't' => 'num',   'w' => 12, 'pdfW' => 46],
    ['label' => 'Sebelum Pajak',    'pdfLabel' => 'SEBELUM PAJAK', 't' => 'money', 'w' => 16, 'pdfW' => 66],
    ['label' => 'Setelah Pajak',    'pdfLabel' => 'SETELAH PAJAK', 't' => 'money', 'w' => 16, 'pdfW' => 66],
    ['label' => 'Tgl Dibayar',      'pdfLabel' => 'TGL DIBAYAR',   't' => 'text',  'w' => 12, 'pdfW' => 46],
];

$detailRows = [];
foreach ($data['rows'] as $r) {
    $detailRows[] = [
        ['v' => $r['no_ticket'], 't' => 'text'],
        ['v' => $r['tanggal'], 't' => 'date'],
        ['v' => $r['daerah'], 't' => 'text'],
        ['v' => $r['pic_name'], 't' => 'text'],
        ['v' => $r['vendor_name'], 't' => 'text'],
        ['v' => (float)$r['berat_basah'], 't' => 'num'],
        ['v' => (float)$r['total_harga'], 't' => 'money'],
        ['v' => (float)$r['nilai_net'], 't' => 'money'],
        ['v' => $r['processed_at'] ? substr($r['processed_at'], 0, 10) : '', 't' => 'date'],
    ];
}
$grand = [
    ['v' => 'TOTAL (' . (int)$t['n'] . ' tiket)', 't' => 'text'],
    ['v' => '', 't' => 'text'],
    ['v' => '', 't' => 'text'],
    ['v' => '', 't' => 'text'],
    ['v' => '', 't' => 'text'],
    ['v' => (float)$t['kg'], 't' => 'num'],
    ['v' => (float)$t['bruto'], 't' => 'money'],
    ['v' => (float)$t['net'], 't' => 'money'],
    ['v' => '', 't' => 'text'],
];
$detailRows[] = $grand;

$picCols = [
    ['label' => 'PIC', 'pdfLabel' => 'PIC', 't' => 'text', 'w' => 24, 'pdfW' => 90],
    ['label' => 'Jumlah Tiket', 'pdfLabel' => 'TIKET', 't' => 'int', 'w' => 12, 'pdfW' => 40],
    ['label' => 'Berat (KG)', 'pdfLabel' => 'BERAT (KG)', 't' => 'num', 'w' => 14, 'pdfW' => 60],
    ['label' => 'Sebelum Pajak', 'pdfLabel' => 'SEBELUM PAJAK', 't' => 'money', 'w' => 18, 'pdfW' => 78],
    ['label' => 'Setelah Pajak', 'pdfLabel' => 'SETELAH PAJAK', 't' => 'money', 'w' => 18, 'pdfW' => 78],
];
$picRows = [];
foreach ($data['per_pic'] as $r) {
    $picRows[] = [
        ['v' => $r['pic'], 't' => 'text'],
        ['v' => (int)$r['n'], 't' => 'int'],
        ['v' => (float)$r['kg'], 't' => 'num'],
        ['v' => (float)$r['bruto'], 't' => 'money'],
        ['v' => (float)$r['net'], 't' => 'money'],
    ];
}
$picRows[] = [
    ['v' => 'TOTAL', 't' => 'text'],
    ['v' => (int)$t['n'], 't' => 'int'],
    ['v' => (float)$t['kg'], 't' => 'num'],
    ['v' => (float)$t['bruto'], 't' => 'money'],
    ['v' => (float)$t['net'], 't' => 'money'],
];

// ------------------------------------------------------------
// Deskripsi filter (dipakai di kop Excel & PDF)
// ------------------------------------------------------------
$filterLines = [rb_label_grup($f)];   // "Supplier: ..." atau "Semua supplier"
if ($f['daerah'] !== '') $filterLines[] = 'Daerah: ' . $f['daerah'];
if ($f['q'] !== '')      $filterLines[] = 'Pencarian: "' . $f['q'] . '"';
$periode    = 'Periode: ' . rekap_label_periode($f);
$dibuatOleh = 'Dibuat oleh: ' . $user['name'] . ' (' . role_label($user['role']) . ') pada ' . date('d.m.Y H:i');
$namaDasar  = 'Rekap-Beres_' . str_replace([':', ' '], '', ($f['dari'] ?: 'semua'))
           . '-' . str_replace([':', ' '], '', ($f['sampai'] ?: 'semua'));

// Kolom versi PDF (pakai pdfLabel/pdfW)
$pdfCols = [];
foreach ($cols as $c) {
    $pdfCols[] = [
        'label' => $c['pdfLabel'],
        't'     => $c['t'],
        'w'     => (float)$c['pdfW'],
        'align' => in_array($c['t'], ['money', 'num', 'int'], true) ? 'right' : 'left',
    ];
}
$pdfPicCols = [];
foreach ($picCols as $c) {
    $pdfPicCols[] = [
        'label' => $c['pdfLabel'],
        't'     => $c['t'],
        'w'     => (float)$c['pdfW'],
        'align' => in_array($c['t'], ['money', 'num', 'int'], true) ? 'right' : 'left',
    ];
}

// ============================================================
// EXCEL
// ============================================================
if ($type === 'xlsx') {
    $xl = new XlsxWriter();

    $blocks = [
        ['type' => 'title', 'text' => 'REKAPITULASI BERES (SUDAH DIBAYAR)'],
        ['type' => 'subtitle', 'text' => $periode],
        ['type' => 'subtitle', 'text' => 'Filter: ' . implode('  |  ', $filterLines)],
        ['type' => 'subtitle', 'text' => $dibuatOleh],
        ['type' => 'subtitle', 'text' => 'Jumlah tiket: ' . (int)$t['n']
            . '   |   Total berat: ' . number_format((float)$t['kg'], 2, ',', '.') . ' KG'
            . '   |   Sebelum pajak: ' . number_format((float)$t['bruto'], 0, ',', '.')
            . '   |   Setelah pajak: ' . number_format((float)$t['net'], 0, ',', '.')],
        ['type' => 'spacer'],
    ];
    $widths = [];
    foreach ($cols as $i => $c) $widths[$i] = max(9, min(34, (float)$c['w']));
    $headerRow = count($blocks) + 1;
    $blocks[] = ['type' => 'table', 'columns' => $cols, 'rows' => $detailRows, 'totals_row' => true];
    $lastRow = $headerRow + count($detailRows);
    $xl->addSheet('Rincian', $blocks, [
        'landscape'  => true,
        'widths'     => $widths,
        'freezeRows' => $headerRow,
        'autofilter' => 'A' . $headerRow . ':I' . $lastRow,
    ]);

    $b = [
        ['type' => 'title', 'text' => 'RINGKASAN PER PIC'],
        ['type' => 'subtitle', 'text' => $periode],
        ['type' => 'subtitle', 'text' => 'Filter: ' . implode('  |  ', $filterLines)],
        ['type' => 'spacer'],
    ];
    $w = [];
    foreach ($picCols as $i => $c) $w[$i] = max(10, min(30, (float)$c['w']));
    $b[] = ['type' => 'table', 'columns' => $picCols, 'rows' => $picRows, 'totals_row' => true];
    $xl->addSheet('Per PIC', $b, ['widths' => $w]);

    $xl->addSheet('Keterangan', [[
        'type' => 'table',
        'columns' => [['label' => 'Poin', 't' => 'text'], ['label' => 'Penjelasan', 't' => 'text']],
        'rows' => [
            ['Cakupan data', 'Hanya transaksi dengan Status Pembayaran "Selesai / Done" (sudah dibayar).'],
            ['Filter Supplier', 'Jika supplier dipilih, hanya transaksi dari supplier tersebut yang dimuat. Jika tidak, semua supplier dimuat.'],
            ['Berat (KG)', 'Berat basah dari tiket pembelian.'],
            ['Sebelum Pajak', 'Berat Basah (KG) x Harga Basah (total_harga).'],
            ['Setelah Pajak', 'Total Sebelum Pajak dikurangi potongan pajak (PPh 0,25% bila supplier punya NPWP, 0,5% bila tidak). Nilai inilah yang dibayarkan ke supplier.'],
            ['Tgl Dibayar', 'Tanggal Finance menandai pembayaran selesai (processed_at).'],
        ],
    ]], ['widths' => [22, 100]]);

    $xl->download($namaDasar . '.xlsx');
}

// ============================================================
// PDF
// ============================================================
$pdf = new PdfWriter(true);
$pdf->heading('REKAPITULASI BERES (SUDAH DIBAYAR)', [$periode, 'Filter: ' . implode('  |  ', $filterLines), $dibuatOleh]);

$pdf->sectionTitle('RINGKASAN UMUM');
$pdf->kvBlock([
    ['Jumlah tiket', (int)$t['n'] . ' tiket'],
    ['Total berat basah', number_format((float)$t['kg'], 2, ',', '.') . ' KG'],
    ['Total sebelum pajak', format_rupiah($t['bruto'])],
    ['Potongan pajak', format_rupiah($t['pot'])],
    ['Total setelah pajak', format_rupiah($t['net'])],
]);

$pdf->sectionTitle('RINGKASAN PER PIC');
$pdf->table($pdfPicCols, $picRows, ['totals_row' => true, 'fontSize' => 7.6]);

$pdf->sectionTitle('RINCIAN', (int)$t['n'] . ' baris');
$pdf->table($pdfCols, $detailRows, ['totals_row' => true, 'fontSize' => 7.2, 'rowHeight' => 11]);
$pdf->footnote('Dokumen dibuat otomatis oleh Purchasing Management System. Hanya berisi transaksi yang sudah beres (status pembayaran Selesai / Done).');
$pdf->download($namaDasar . '.pdf', 'Rekapitulasi Beres');