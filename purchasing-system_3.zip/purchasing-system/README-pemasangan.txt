REKAPITULASI BERES - PETUNJUK PEMASANGAN
========================================

Fitur baru: halaman khusus rekapitulasi untuk transaksi yang
SUDAH BERES (status pembayaran "Selesai / Done") saja, dengan
filter PIC:
  - Semua PIC
  - Pak Arnold & Pak Tomo
  - Bu Dewi & Bu Ayu
  - Bu Martha

Tampilan dibuat baru & ringkas (bukan seperti halaman
Rekapitulasi lama): tombol besar pilih PIC + jumlah tiket,
filter periode/daerah/pencarian, kartu ringkasan angka,
ringkasan per PIC, dan tabel rincian tipis (9 kolom).
Tersedia Export Excel & PDF yang angkanya sama persis dengan
layar.

---------------------------------------------------------
CARA PASANG (3 file baru + 1 file berubah)
---------------------------------------------------------
Salin file-file ini ke folder aplikasi di hosting, dengan
struktur yang sama persis:

  purchasing-system/
    includes/rekap_beres_data.php   (BARU - lapisan data)
    includes/sidebar.php            (BERUBAH - ditambahkan 1 menu)
    rekap-beres/list.php            (BARU - halaman utama)
    rekap-beres/export.php          (BARU - export Excel/PDF)

CATATAN: file includes/sidebar.php di zip ini sudah termasuk
menu baru. Kalau kamu tidak mau menimpa sidebar.php, cukup
salin 3 file baru saja lalu tambahkan menu ini sendiri di
includes/sidebar.php, tepat di bawah menu "Rekapitulasi":

      <li class="nav-item">
        <a href="<?= BASE_URL ?>/rekap-beres/list.php"
           class="nav-link text-white <?= nav_active('rekap-beres', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-patch-check"></i> Rekap Beres
        </a>
      </li>

Setelah file disalin, selesai - tidak perlu import database,
tidak perlu instal library apa pun.

---------------------------------------------------------
HALAMAN & AKSES
---------------------------------------------------------
- Menu sidebar : "Rekap Beres" (di bawah "Rekapitulasi")
- URL          : /rekap-beres/list.php
- Yang boleh lihat: admin, petugas, pic, finance, dirops
  (sama seperti Rekapitulasi).
- User role PIC tetap hanya melihat data PIC-nya sendiri
  (kebijakan yang sama dengan halaman-halaman lain).

---------------------------------------------------------
CARA KERJA FILTER PIC
---------------------------------------------------------
Filter mencocokkan NAMA PIC di tabel users secara
case-insensitive (hanya yang sudah beres):
  - "Pak Arnold & Pak Tomo" -> nama mengandung "arnold" ATAU "tomo"
  - "Bu Dewi & Bu Ayu"      -> nama mengandung "dewi" ATAU "ayu"
  - "Bu Martha"             -> nama mengandung "martha"

Jadi tidak masalah kalau nama lengkap di database berbeda
(mis. "Arnold Siregar" tetap masuk ke kelompok Arnold & Tomo).

---------------------------------------------------------
MAU MENAMBAH / MENGUBAH KELOMPOK PIC?
---------------------------------------------------------
Buka file: includes/rekap_beres_data.php
Edit konstanta RB_GRUP_PIC di bagian atas, contoh:

  const RB_GRUP_PIC = [
      'arnold_tomo' => ['label' => 'Pak Arnold & Pak Tomo', 'names' => ['arnold', 'tomo']],
      'dewi_ayu'    => ['label' => 'Bu Dewi & Bu Ayu',      'names' => ['dewi', 'ayu']],
      'martha'      => ['label' => 'Bu Martha',             'names' => ['martha']],
      'budi'        => ['label' => 'Pak Budi',              'names' => ['budi']],   // <-- tambah
  ];

- 'label'  : teks yang tampil di tombol & di file ekspor.
- 'names'  : potongan nama (huruf kecil) yang dicocokkan.
- urutan  : urutan kemunculan tombol di halaman.

Setelah disimpan, tombol baru langsung muncul di halaman.

---------------------------------------------------------
HALAMAN LAMA TIDAK DIUBAH
---------------------------------------------------------
Rekapitulasi lama (/rekap/list.php) tetap seperti biasa dan
tidak terpengaruh.
