<?php
require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/laporan_ho.php';   // tombol "Lapor HO" di daftar bawah
require_login();
$user = current_user();
$pageTitle = 'Dashboard';

// Hitung ringkasan sesuai role
if ($user['role'] === 'pic') {
    $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE pic_id = ?");
    $totalStmt->execute([$user['id']]);
    $total = $totalStmt->fetchColumn();

    $menungguStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE pic_id = ? AND status_approval = 'menunggu'");
    $menungguStmt->execute([$user['id']]);
    $menunggu = $menungguStmt->fetchColumn();

    $ditolakStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE pic_id = ? AND status_approval = 'ditolak'");
    $ditolakStmt->execute([$user['id']]);
    $ditolak = $ditolakStmt->fetchColumn();

    $selesaiStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE pic_id = ? AND status_pembayaran = 'selesai'");
    $selesaiStmt->execute([$user['id']]);
    $selesai = $selesaiStmt->fetchColumn();

    $recentStmt = $pdo->prepare("SELECT p.*, v.name as vendor_name FROM purchases p JOIN vendors v ON v.id = p.vendor_id WHERE p.pic_id = ? ORDER BY p.created_at DESC LIMIT 5");
    $recentStmt->execute([$user['id']]);
    $recent = $recentStmt->fetchAll();

} elseif ($user['role'] === 'petugas') {
    $total = $pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();
    $menunggu = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'menunggu'")->fetchColumn();
    $ditolak = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'ditolak'")->fetchColumn();
    $selesai = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'disetujui'")->fetchColumn();
    $recent = $pdo->query("SELECT p.*, v.name as vendor_name FROM purchases p JOIN vendors v ON v.id = p.vendor_id ORDER BY p.created_at DESC LIMIT 5")->fetchAll(); // antrean: lihat kartu di bawah

} elseif ($user['role'] === 'dirops') {
    $total = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'disetujui'")->fetchColumn();
    $menunggu = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'disetujui' AND status_dirops = 'menunggu'")->fetchColumn();
    $ditolak = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_dirops = 'ditolak'")->fetchColumn();
    $selesai = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_dirops = 'disetujui'")->fetchColumn();
    $recent = $pdo->query("SELECT p.*, v.name as vendor_name FROM purchases p JOIN vendors v ON v.id = p.vendor_id ORDER BY p.created_at DESC LIMIT 5")->fetchAll(); // antrean: lihat kartu di bawah

} elseif ($user['role'] === 'finance') {
    // $menunggu diisi di bawah oleh hitungan antrean (perhatikan blok "Antrean" berikut):
    // dulu di sini hanya menghitung status_dirops = 'menunggu' (itu antrean Dirops, bukan
    // antrean Finance) sehingga tiket yang baru disetujui Dirops tidak pernah muncul.
    $total = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'disetujui'")->fetchColumn();
    $menunggu = 0;
    $ditolak = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_pembayaran = 'gagal' OR status_finance_approval = 'ditolak' OR status_dirops = 'ditolak'")->fetchColumn();
    $selesai = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_pembayaran = 'selesai'")->fetchColumn();
    $recent = $pdo->query("SELECT p.*, v.name as vendor_name FROM purchases p JOIN vendors v ON v.id = p.vendor_id ORDER BY (p.status_pembayaran = 'selesai') DESC, p.created_at DESC LIMIT 5")->fetchAll();

} else { // admin
    $total = $pdo->query("SELECT COUNT(*) FROM purchases")->fetchColumn();
    $menunggu = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'menunggu'")->fetchColumn();
    $ditolak = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_approval = 'ditolak' OR status_pembayaran = 'gagal'")->fetchColumn();
    $selesai = $pdo->query("SELECT COUNT(*) FROM purchases WHERE status_pembayaran = 'selesai'")->fetchColumn();
    $recent = $pdo->query("SELECT p.*, v.name as vendor_name FROM purchases p JOIN vendors v ON v.id = p.vendor_id ORDER BY (p.status_pembayaran = 'selesai') DESC, p.created_at DESC LIMIT 5")->fetchAll();
}

// =========================================================
// ANTREAN "PERLU TINDAKAN SAYA"
// Definisi tiap tahap di bawah SENGAJA disalin apa adanya dari $stages di
// function run_wa_reminders() (includes/functions.php) dan dari filter halaman
// daftar masing-masing role, supaya jumlah di dashboard = di daftar = reminder WA.
// Finance punya DUA antrean: (1) verifikasi sebelum Dirops, (2) pembayaran setelah Dirops.
// =========================================================
$antreanDef = [];
if ($user['role'] === 'finance') {
    $antreanDef[] = [
        'judul'     => 'Menunggu verifikasi & approval Finance',
        'where'     => "p.status_approval = 'disetujui' AND p.status_finance_approval = 'menunggu'",
        'umurKolom' => 'approved_at',
        'aksiUrl'   => '/finance/approve.php?id=',
        'aksiLabel' => 'Approval Finance',
        'daftarUrl' => '/finance/list.php?status=menunggu_finance',
    ];
    $antreanDef[] = [
        'judul'     => 'Disetujui Dirops - menunggu pembayaran',
        'where'     => "p.status_dirops = 'disetujui' AND p.status_pembayaran IN ('sudah_diajukan_ho','menunggu_pembayaran','sedang_diproses')",
        'umurKolom' => 'dirops_at',
        'aksiUrl'   => '/finance/process.php?id=',
        'aksiLabel' => 'Update Status Pembayaran',
        'daftarUrl' => '/finance/list.php?status=menunggu_pembayaran',
    ];
} elseif ($user['role'] === 'petugas') {
    $antreanDef[] = [
        'judul'     => 'Menunggu persetujuan Petugas',
        'where'     => "p.status_approval = 'menunggu'",
        'umurKolom' => 'created_at',
        'aksiUrl'   => '/approval/process.php?id=',
        'aksiLabel' => 'Proses',
        'daftarUrl' => '/approval/list.php?status=menunggu',
    ];
} elseif ($user['role'] === 'dirops') {
    $antreanDef[] = [
        'judul'     => 'Menunggu approval Direktur Operasional',
        'where'     => "p.status_finance_approval = 'disetujui' AND p.status_dirops = 'menunggu'",
        'umurKolom' => 'finance_approval_at',
        'aksiUrl'   => '/dirops/process.php?id=',
        'aksiLabel' => 'Proses Approval',
        'daftarUrl' => '/dirops/list.php?status=menunggu',
    ];
}

$antrean = [];
$antreanTotal = 0;
foreach ($antreanDef as $def) {
    $antreanTotal += (int)$pdo->query('SELECT COUNT(*) FROM purchases p WHERE ' . $def['where'])->fetchColumn();
    $st = $pdo->query('SELECT p.*, v.name AS vendor_name, u.name AS pic_name FROM purchases p
                        JOIN vendors v ON v.id = p.vendor_id
                        JOIN users u ON u.id = p.pic_id
                        WHERE ' . $def['where'] . '
                        ORDER BY p.' . $def['umurKolom'] . ' ASC
                        LIMIT 5');
    foreach ($st->fetchAll() as $baris) {
        $baris['_antrean'] = $def['judul'];
        $baris['_umurKolom'] = $def['umurKolom'];
        $baris['_aksiUrl'] = $def['aksiUrl'];
        $baris['_aksiLabel'] = $def['aksiLabel'];
        $antrean[] = $baris;
    }
}
$antreanTerakhir = $antreanDef[0]['daftarUrl'] ?? '';
if (!empty($antreanDef)) $menunggu = $antreanTotal;   // kartu kuning = antrean yang benar-benar menunggu Anda

// Harga Harian (Notaring) hari ini - ditampilkan di dashboard Dirops
$hargaHariIni = [];
if ($user['role'] === 'dirops') {
    $hhStmt = $pdo->prepare("SELECT daerah, harga, catatan, updated_at FROM daily_prices WHERE tanggal = CURDATE() ORDER BY daerah");
    $hhStmt->execute();
    $hargaHariIni = $hhStmt->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<h3 class="mb-1">Selamat datang, <?= e($user['name']) ?></h3>
<p class="text-muted">Ringkasan sebagai <strong><?= e(role_label($user['role'])) ?></strong></p>

<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3">
    <div class="card stat-card p-3" style="background-color:#1e8449;">
      <div class="small">Total Pembelian</div>
      <div class="fs-2 fw-bold"><?= (int)$total ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card p-3" style="background-color:#e0a800;">
      <div class="small">Menunggu Proses</div>
      <div class="fs-2 fw-bold"><?= (int)$menunggu ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card p-3" style="background-color:#dc3545;">
      <div class="small">Ditolak / Gagal</div>
      <div class="fs-2 fw-bold"><?= (int)$ditolak ?></div>
    </div>
  </div>
  <div class="col-6 col-lg-3">
    <div class="card stat-card p-3" style="background-color:#0dcaf0;">
      <div class="small">Selesai</div>
      <div class="fs-2 fw-bold"><?= (int)$selesai ?></div>
    </div>
  </div>
</div>

<?php if ($user['role'] === 'dirops'): ?>
<div class="card mb-4" style="border-left:4px solid #1e8449;">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <span class="fw-semibold text-success"><i class="bi bi-tag"></i> Harga Harian (Notaring) Hari Ini &middot; <?= format_tanggal(date('Y-m-d')) ?></span>
      <a class="small" href="<?= BASE_URL ?>/harga-harian/list.php">lihat riwayat &raquo;</a>
    </div>
    <?php if ($hargaHariIni): ?>
      <div class="row g-2">
        <?php foreach ($hargaHariIni as $hh): ?>
          <div class="col-md-4"><div class="border rounded p-2 h-100">
            <div class="small text-success fw-semibold"><?= e($hh['daerah']) ?></div>
            <div class="fs-4 fw-bold"><?= format_rupiah($hh['harga']) ?> / KG</div>
            <?php if ($hh['catatan']): ?><div class="small text-muted">Catatan: <?= e($hh['catatan']) ?></div><?php endif; ?>
          </div></div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="text-muted">Belum ada harga yang ditetapkan untuk hari ini.</div>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if (!empty($antreanDef)): ?>
<div class="card mb-4">
  <div class="card-header bg-white d-flex justify-content-between align-items-center flex-wrap gap-2">
    <span class="fw-bold"><i class="bi bi-inbox-fill text-warning"></i> Antrean yang Perlu Tindakan Saya</span>
    <span class="small text-muted">
      <?php if ($antreanTotal > 0): ?>
        <span class="badge text-bg-warning"><?= (int)$antreanTotal ?> menunggu</span>
        <a class="ms-2" href="<?= BASE_URL ?><?= e($antreanTerakhir) ?>">buka daftar &raquo;</a>
      <?php else: ?>
        bersih - tidak ada yang menunggu tindakan Anda
      <?php endif; ?>
    </span>
  </div>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead class="table-light">
        <tr>
          <th>Antrean</th>
          <th>No Ticket / Nota</th>
          <th>Tanggal &amp; Daerah</th>
          <th>Supplier / PIC</th>
          <th class="text-end">Berat</th>
          <th class="text-end">Nilai</th>
          <th>Menunggu</th>
          <th>Status</th>
          <th class="text-end">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($antrean)): ?>
          <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada yang perlu ditindaklanjuti sekarang. Tiket yang baru disetujui Dirops akan muncul di sini.</td></tr>
        <?php else: foreach ($antrean as $row):
          $patok = !empty($row[$row['_umurKolom']]) ? $row[$row['_umurKolom']] : null;
          $jamTunggu = $patok ? (int)floor((time() - strtotime($patok)) / 3600) : null;
          $teksTunggu = $jamTunggu === null ? '-' : ($jamTunggu < 1 ? 'baru saja' : ($jamTunggu < 48 ? $jamTunggu . ' jam' : (int)floor($jamTunggu / 24) . ' hari'));
          $lamaBanget = $jamTunggu !== null && $jamTunggu >= 24;
        ?>
          <tr>
            <td><span class="badge text-bg-light border"><?= e($row['_antrean']) ?></span></td>
            <td>
              <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= (int)$row['id'] ?>" class="fw-bold text-decoration-none"><?= e($row['no_ticket']) ?></a>
              <div class="small text-muted">Nota <?= e($row['no_nota']) ?></div>
            </td>
            <td><?= format_tanggal($row['tanggal']) ?><div class="small text-muted"><?= e($row['daerah']) ?></div></td>
            <td><?= e($row['vendor_name']) ?><div class="small text-muted">PIC: <?= e($row['pic_name']) ?></div></td>
            <td class="text-end"><?= e(number_format((float)$row['berat_basah'], 2, ',', '.')) ?> KG</td>
            <td class="text-end fw-bold"><?= e(format_rupiah($row['total_harga'])) ?></td>
            <td><span class="<?= $lamaBanget ? 'text-danger fw-bold' : 'text-muted' ?>"><?= e($teksTunggu) ?></span></td>
            <td>
              <?= badge_pembayaran($row['status_pembayaran']) ?>
              <div class="small text-muted mt-1">Dirops: <?= e(str_replace('_', ' ', $row['status_dirops'])) ?></div>
            </td>
            <td class="text-end text-nowrap">
              <a href="<?= BASE_URL ?><?= e($row['_aksiUrl']) ?><?= (int)$row['id'] ?>" class="btn btn-sm btn-brand"><i class="bi bi-check2-square"></i> <?= e($row['_aksiLabel']) ?></a>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header bg-white fw-bold">Aktivitas Terbaru</div>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead class="table-light">
        <tr>
          <th>No Ticket</th>
          <th>Tanggal</th>
          <th>Supplier</th>
          <th>Berat Basah</th>
          <th>Status Approval</th>
          <th>Status Pembayaran</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recent)): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">Belum ada data.</td></tr>
        <?php else: foreach ($recent as $row): ?>
          <tr>
            <td><?= e($row['no_ticket']) ?></td>
            <td><?= format_tanggal($row['tanggal']) ?></td>
            <td><?= e($row['vendor_name']) ?></td>
            <td><?= e($row['berat_basah']) ?> KG</td>
            <td><?= badge_approval($row['status_approval']) ?></td>
            <td><?= badge_pembayaran($row['status_pembayaran']) ?></td>
            <td class="text-end text-nowrap">
              <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Lihat detail"><i class="bi bi-eye"></i></a><?php
              // Pintasan: tombol laporan HO langsung di daftar, tidak perlu masuk ke detail dulu.
              // ho_tombol_html() sendiri yang memutuskan: mengembalikan null kalau tiket ini belum
              // boleh dilaporkan (approval belum lengkap / email HO belum diaktifkan Admin),
              // dan otomatis menyisipkan .eml sebagai cadangan + memuat lapor-ho.js sekali per halaman.
              if (in_array($user['role'], ['finance', 'admin'], true)) {
                  $hoCepat = ho_tombol_html($pdo, $row, 'btn-outline-primary', '<i class="bi bi-envelope-paper"></i> Lapor HO');
                  if ($hoCepat !== null) {
                      echo chr(10) . '              ' . $hoCepat;
                      $hoSudah = ho_sudah_dilaporkan($pdo, $row['id']);
                      if ($hoSudah) {
                          echo chr(10) . '              <div class="small text-muted mt-1"><i class="bi bi-check2"></i> dilaporkan '
                             . e(format_tanggal_waktu($hoSudah['created_at'])) . ' oleh ' . e($hoSudah['user_name']) . '</div>';
                      }
                  }
              } ?>
            </td>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
