<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'pic']);
$user = current_user();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data tidak ditemukan.');
    redirect('/pembelian/list.php');
}
if ($user['role'] !== 'admin' && $purchase['pic_id'] != $user['id']) {
    set_flash('danger', 'Anda tidak punya akses untuk menghapus data ini.');
    redirect('/pembelian/list.php');
}
if ($purchase['status_approval'] !== 'menunggu') {
    set_flash('warning', 'Data yang sudah diproses approval tidak dapat dihapus.');
    redirect('/pembelian/list.php');
}

// v12: tiket boleh punya lebih dari satu berkas (foto bokar + dokumen pendukung).
// Semuanya ikut dihapus dari folder uploads supaya tidak tinggal berkas yatim,
// lalu barisnya dibersihkan (tabel tidak pakai foreign key, jadi dibersihkan manual).
foreach (purchase_fotos($pdo, $purchase) as $f) {
    $path = __DIR__ . '/../uploads/' . $f['file'];
    if (is_file($path)) {
        @unlink($path);
    }
}
if (purchase_fotos_tersedia($pdo)) {
    $pdo->prepare("DELETE FROM purchase_fotos WHERE purchase_id = ?")->execute([$id]);
}

$stmt = $pdo->prepare("DELETE FROM purchases WHERE id = ?");
$stmt->execute([$id]);

set_flash('success', 'Data pembelian berhasil dihapus.');
redirect('/pembelian/list.php');
