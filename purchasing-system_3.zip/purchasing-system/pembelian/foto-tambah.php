<?php
// =========================================================
// Tambah "Foto Bokar & Dokumen Pendukung" untuk tiket yang sudah dibuat (v12)
// ---------------------------------------------------------
// Sengaja BERDIRI SENDIRI, tidak digabung ke pembelian/edit.php, karena:
//   - edit.php hanya boleh dibuka saat status 'menunggu' / 'revisi_harga' dan
//     pada mode revisi harga menyetel ulang 4 flag approval, sedangkan
//   - dokumen lapangan (foto bon, surat jalan, bukti timbangan) sering baru ada
//     SETELAH tiket berjalan, dan menambah lampiran tidak boleh mengubah angka
//     maupun status approval apa pun.
// Jalur ini karena itu hanya menulis tabel purchase_fotos + purchase_logs.
// =========================================================
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'pic']);
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/pembelian/list.php');
}

// CATATAN: kalau kiriman melebihi post_max_size, PHP mengosongkan $_POST dan $_FILES
// SELURUHNYA - jadi id tiket pun ikut hilang. Karena itu penjaga ukuran harus dibaca
// di sini, SEBELUM $_POST['id'], kalau tidak user cuma melihat "Data tidak ditemukan".
$pesanPost = upload_pesan_post_kebesaran();
if ($pesanPost) {
    set_flash('danger', $pesanPost);
    redirect('/pembelian/list.php');
}

$id = (int)($_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();
if (!$purchase) {
    set_flash('danger', 'Data pembelian tidak ditemukan.');
    redirect('/pembelian/list.php');
}
if ($user['role'] !== 'admin' && $purchase['pic_id'] != $user['id']) {
    set_flash('danger', 'Anda tidak punya akses ke data pembelian ini.');
    redirect('/dashboard.php');
}

$tipeFlash = 'success';
$pesan = [];

$kuotaTotal = FOTO_MAKS_TAMBAHAN + 1;             // 1 foto utama + 8 dokumen tambahan
$sudahAda   = count(purchase_fotos($pdo, $purchase));
$sisa       = max(0, $kuotaTotal - $sudahAda);

if ($purchase['status_pembayaran'] === 'selesai' && $user['role'] !== 'admin') {
    $tipeFlash = 'warning';
    $pesan[]  = 'Tiket yang sudah selesai dibayar tidak bisa ditambah dokumen lagi (arsip sudah terkunci). Minta Admin bila memang perlu.';
} elseif ($sisa <= 0) {
    $tipeFlash = 'warning';
    $pesan[]  = 'Kuota dokumen tiket ini sudah penuh (' . $kuotaTotal . ' berkas). Hapus salah satu dulu bila ingin mengganti.';
} else {
    $up = handle_photo_upload_multi(__DIR__ . '/../uploads', $sisa,
        'Sisa kuota tiket ini ' . $sisa . ' berkas (' . $kuotaTotal . ' berkas per tiket) - sisanya tidak disimpan.');
    if (!$up['files']) {
        $tipeFlash = 'danger';
        $pesan[] = $up['errors'] ? implode(' ', $up['errors']) : 'Tidak ada berkas yang diterima. Pilih foto dahulu, lalu unggah ulang.';
    } else {
        $simpan = purchase_fotos_simpan($pdo, $id, $up['files'], $user['id'], __DIR__ . '/../uploads');
        if ($simpan['tersimpan'] > 0) {
            $pesan[] = $simpan['tersimpan'] . ' dokumen ditambahkan ke tiket ' . $purchase['no_ticket'] . '.';
            log_activity($pdo, $id, 'Foto Dokumen', $simpan['tersimpan'] . ' berkas diunggah oleh ' . $user['name']);
        }
        if ($simpan['pesan']) {
            $tipeFlash = 'danger';
            $pesan[] = $simpan['pesan'];
        }
        if ($up['errors']) {
            if ($tipeFlash === 'success') $tipeFlash = 'warning';
            $pesan[] = 'Yang tidak tersimpan: ' . implode(' ', $up['errors']);
        }
        if ($simpan['tersimpan'] === 0 && !$simpan['pesan'] && !$up['errors']) {
            $tipeFlash = 'danger';
            $pesan[] = 'Dokumen tidak tersimpan. Ulangi, atau kirim lewat formulir tambah pembelian.';
        }
    }
}

set_flash($tipeFlash, implode(' ', $pesan));
redirect('/pembelian/detail.php?id=' . $id);
