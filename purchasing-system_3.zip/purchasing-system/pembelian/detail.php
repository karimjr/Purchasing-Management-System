<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name as vendor_name, v.alamat as vendor_alamat, v.telepon as vendor_telepon,
                        u.name as pic_name, a.name as approved_by_name, f.name as processed_by_name, d.name as dirops_by_name
                        FROM purchases p
                        JOIN vendors v ON v.id = p.vendor_id
                        JOIN users u ON u.id = p.pic_id
                        LEFT JOIN users a ON a.id = p.approved_by
                        LEFT JOIN users f ON f.id = p.processed_by
                        LEFT JOIN users d ON d.id = p.dirops_by
                        WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data pembelian tidak ditemukan.');
    redirect('/dashboard.php');
}

// PIC hanya boleh lihat miliknya sendiri
if ($user['role'] === 'pic' && $purchase['pic_id'] != $user['id']) {
    set_flash('danger', 'Anda tidak punya akses ke data ini.');
    redirect('/dashboard.php');
}

$logStmt = $pdo->prepare("SELECT l.*, u.name as user_name FROM purchase_logs l JOIN users u ON u.id = l.user_id WHERE l.purchase_id = ? ORDER BY l.created_at ASC");
$logStmt->execute([$id]);
$logs = $logStmt->fetchAll();

// =========================================================
// Tombol WA manual: siapa yang perlu dihubungi selanjutnya di tahap
// approval saat ini, sesuai alur PIC -> Petugas -> Finance -> Dirops -> Finance.
// Klik tombol akan membuka WhatsApp (wa.me) dengan pesan yang sudah
// terisi otomatis, tanpa lewat gateway API.
// =========================================================
$waTargetRole = null;
$waTargetLabel = '';
$waMessage = '';

if ($purchase['status_approval'] === 'menunggu') {
    $waTargetRole = 'petugas';
    $waTargetLabel = 'Petugas';
    $waMessage = "Permisi Bapak/Ibu Petugas, mohon kesediaannya untuk memeriksa dan memberikan persetujuan atas pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . "). Apabila data sudah sesuai, mohon kiranya dapat diproses. Terima kasih atas bantuan dan waktunya.";
} elseif ($purchase['status_approval'] === 'disetujui' && $purchase['status_finance_approval'] === 'menunggu') {
    $waTargetRole = 'finance';
    $waTargetLabel = 'Finance';
    $waMessage = "Permisi Bapak/Ibu Finance, mohon dibantu verifikasi dan approval pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . "). Setelah disetujui, mohon dilanjutkan permintaan approval kepada Direktur Operasional. Terima kasih.";
} elseif ($purchase['status_finance_approval'] === 'disetujui' && $purchase['status_dirops'] === 'menunggu') {
    $waTargetRole = 'dirops';
    $waTargetLabel = 'Direktur Operasional';
    $waMessage = "Permisi Bapak/Ibu Direktur Operasional, mohon dibantu approval pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} yang telah disetujui Petugas dan Finance. Mohon diberikan keputusan beserta catatan bila belum disetujui. Terima kasih.";
} elseif ($purchase['status_dirops'] === 'disetujui' && !in_array($purchase['status_pembayaran'], ['selesai', 'dibatalkan'])) {
    $waTargetRole = 'finance';
    $waTargetLabel = 'Finance';
    $waMessage = "Permisi Bapak/Ibu Finance, terkait tiket pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . "), telah saya setujui. Silakan dilanjutkan ke proses pembayaran sesuai prosedur. Mohon dibantu memperbarui statusnya apabila sudah diajukan ke HO, sedang diproses, selesai, atau terdapat kendala. Terima kasih.";
}

$waTargetUsers = $waTargetRole ? get_users_with_wa($pdo, [$waTargetRole]) : [];

// Finance juga bisa mengabarkan progres pembayaran ke Dirops secara manual
$waDiropsProgressUsers = [];
if ($user['role'] === 'finance' || $user['role'] === 'admin') {
    if ($purchase['status_dirops'] === 'disetujui') {
        $waDiropsProgressUsers = get_users_with_wa($pdo, ['dirops']);
        $waProgressMessage = "Laporan progres: Pembelian {$purchase['no_ticket']} - status pembayaran saat ini: " . str_replace('_', ' ', $purchase['status_pembayaran']) . ".";
    }
}

$pageTitle = 'Detail Pembelian';
include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-receipt"></i> Detail Pembelian - <?= e($purchase['no_ticket']) ?></h4>
  <a href="javascript:history.back()" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
</div>

<?php if (($user['role'] === 'petugas' || $user['role'] === 'admin') && $purchase['status_approval'] === 'revisi_harga' && !empty($purchase['pic_id'])):
  $picStmt = $pdo->prepare("SELECT whatsapp FROM users WHERE id = ? AND is_active = 1");
  $picStmt->execute([$purchase['pic_id']]);
  $picWhatsapp = $picStmt->fetchColumn();
  if ($picWhatsapp):
    $revisionMsg = "Permisi, mohon dibantu menyesuaikan Harga Basah pada tiket {$purchase['no_ticket']} sesuai catatan Petugas: " . ($purchase['catatan_revisi_harga'] ?: 'mohon dilakukan negosiasi ulang sesuai arahan terbaru') . ". Data dan foto lainnya tidak perlu diinput ulang. Setelah disesuaikan, silakan simpan kembali agar dapat kami periksa. Terima kasih.";
?>
  <div class="alert alert-warning d-flex flex-wrap align-items-center gap-2 mb-3"><strong><i class="bi bi-arrow-repeat"></i> Menunggu revisi harga dari PIC:</strong><a href="<?= e(wa_link($picWhatsapp, $revisionMsg)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success"><i class="bi bi-whatsapp"></i> WA ke PIC</a></div>
<?php endif; ?>
<?php endif; ?>

<?php if (!empty($waTargetUsers)): ?>
  <div class="alert alert-success d-flex flex-wrap align-items-center gap-2 mb-3">
    <div class="me-2"><i class="bi bi-whatsapp fs-5"></i> <strong>Ingatkan <?= e($waTargetLabel) ?> lewat WhatsApp:</strong></div>
    <?php foreach ($waTargetUsers as $wu): ?>
      <a href="<?= e(wa_link($wu['whatsapp'], $waMessage)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success">
        <i class="bi bi-whatsapp"></i> WA ke <?= e($wu['name']) ?>
      </a>
    <?php endforeach; ?>
  </div>
<?php elseif ($waTargetRole): ?>
  <div class="alert alert-warning small mb-3">
    <i class="bi bi-exclamation-triangle"></i> Belum ada user role <?= e($waTargetLabel) ?> yang punya nomor WhatsApp terdaftar. Tambahkan di menu Manajemen User.
  </div>
<?php endif; ?>

<?php if (!empty($waDiropsProgressUsers)): ?>
  <div class="alert alert-info d-flex flex-wrap align-items-center gap-2 mb-3">
    <div class="me-2"><i class="bi bi-whatsapp fs-5"></i> <strong>Lapor progres pembayaran ke Dirops:</strong></div>
    <?php foreach ($waDiropsProgressUsers as $wu): ?>
      <a href="<?= e(wa_link($wu['whatsapp'], $waProgressMessage)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary">
        <i class="bi bi-whatsapp"></i> WA ke <?= e($wu['name']) ?>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php
// =========================================================
// Email laporan ke HO (Pak Arnold).
// Muncul hanya untuk Finance/Admin dan hanya kalau tiketnya sudah
// benar-benar tuntas: disetujui Petugas + Finance + Dirops dan
// status pembayaran sudah "Selesai / Done".
// Sekali klik -> aplikasi email bawaan (Outlook) terbuka dengan
// subjek & isi sudah terisi, tinggal ditekan Kirim.
// =========================================================
$hoTombol = null;
$hoInfo = null;
$hoSudah = null;
if (in_array($user['role'], ['finance', 'admin'], true)) {
    $hoInfo = ho_laporan($pdo, $purchase);
    if (!empty($hoInfo['siap'])) {
        $hoTombol = ho_tombol_html($pdo, $purchase, 'btn-primary', null, 'hoFallback');
    }
    $hoSudah = ho_sudah_dilaporkan($pdo, $id);
}
?>
<?php if ($hoInfo && $hoTombol): ?>
  <div class="alert alert-primary d-flex flex-wrap align-items-center gap-2 mb-3">
    <div class="me-2">
      <i class="bi bi-envelope-paper fs-5"></i>
      <strong>Laporkan pembayaran ke <?= e($hoInfo['nama']) ?> (HO)</strong>
      <div class="small text-muted">Email: <strong><?= e($hoInfo['kepada']) ?></strong><?= $hoInfo['cc'] ? ' (cc: ' . e($hoInfo['cc']) . ')' : '' ?> - tombol di samping membuka Outlook dengan pesan siap kirim.</div>
    </div>
    <?= $hoTombol ?>
    <?php if (!empty($hoInfo['web']) && $hoInfo['rute_laptop'] !== 'mailto'): ?>
    <a href="<?= e($hoInfo['web']) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary"
       title="Khusus laptop: Outlook new dibuka pada tab/jendela baru dengan kepada, subjek, dan isi sudah terisi">
      <i class="bi bi-outlook"></i> Buka Outlook <span class="d-none d-md-inline">(di laptop)</span>
    </a>
    <?php endif; ?>
    <button type="button" class="btn btn-sm btn-outline-primary" onclick="hoSalin('isiEmailHo')" title="Cadangan kalau Outlook tidak terbuka">
      <i class="bi bi-clipboard"></i> Salin isi email
    </button>
    <?php if (!empty($hoSudah)): ?>
      <span class="badge text-bg-light border text-success">
        <i class="bi bi-check2"></i> Sudah dilaporkan <?= e(format_tanggal_waktu($hoSudah['created_at'])) ?> oleh <?= e($hoSudah['user_name']) ?>
      </span>
    <?php endif; ?>
  </div>

  <?php // Muncul sendiri kalau Outlook tidak terbuka setelah tombol ditekan ?>
  <div id="hoFallback" class="alert alert-warning small mb-3 d-none">
    <div class="fw-semibold mb-1"><i class="bi bi-exclamation-triangle"></i> Outlook-nya tidak terbuka? Pakai salah satu cara ini</div>
    <div data-role="hasil-server" class="mb-1"></div>
    <ol class="mb-2 ps-3">
      <li><strong>Klik 2x berkas .eml</strong> yang terunduh dari folder Download &mdash; Outlook membukanya sebagai email baru yang sudah terisi, tinggal tekan <em>Kirim</em>.</li>
      <li>Atau <strong>Salin isi email</strong> (tombol di atas) lalu tempel di jendela email baru:
        kepada <code><?= e($hoInfo['kepada']) ?></code>, subjek <code><?= e($hoInfo['subjek']) ?></code>.</li>
      <?php if (($hoInfo['rute_laptop'] ?? 'mailto') !== 'mailto'): ?>
      <li>Di <strong>laptop</strong>: tombol utama sudah mencoba <strong>New Outlook</strong> (<code>ms-outlook://compose</code>),
        lalu <code>mailto:</code>, lalu Outlook di browser - cara yang berhasil diingat di komputer ini.
        Belum terbuka juga? Tekan <strong>Buka New Outlook</strong> atau <strong>Buka Outlook di browser</strong> di bawah ini.</li>
      <?php else: ?>
      <li>Di <strong>laptop</strong>: tombol diatur memakai <code>mailto:</code> (aplikasi email default Windows).
        Kalau tidak terbuka, minta Admin mengubahnya di <em>Pengaturan Email Laporan &rarr; Kalau dibuka dari laptop/komputer</em>
        menjadi <strong>Buka Outlook new dulu</strong>.</li>
      <?php endif; ?>
      <li>Supaya tombol <em>Lapor HO</em> biasa juga membuka Outlook di laptop, set
        <em>Windows Settings &gt; Apps &gt; Default apps &gt; Email = Outlook</em> <strong>dan</strong>
        <em>Choose defaults by protocol &gt; MAILTO = Outlook</em>. Catatan: New Outlook mengabaikan protokol
        khusus (<code>outlook:</code> / <code>ms-outlook:</code>), jadi jangan pakai opsi "Paksa Outlook desktop"
        kalau Outlook-nya yang baru.</li>
    </ol>
    <?php if (!empty($hoInfo['msoutlook'])): ?>
    <a href="<?= e($hoInfo['msoutlook']) ?>" data-role="buka-msoutlook" class="btn btn-sm btn-primary"
       title="Membuka APLIKASI Outlook (new) di laptop ini, pesan sudah terisi"><i class="bi bi-outlook"></i> Buka New Outlook</a>
    <?php endif; ?>
    <?php if (!empty($hoInfo['web'])): ?>
    <a href="<?= e($hoInfo['web']) ?>" data-role="buka-outlook" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary"
       title="Outlook di browser (tab baru) dengan pesan siap kirim"><i class="bi bi-window-stack"></i> Buka Outlook di browser</a>
    <?php endif; ?>
    <a href="<?= BASE_URL ?>/finance/lapor-ho-eml.php?id=<?= (int)$id ?>" class="btn btn-sm btn-warning">
      <i class="bi bi-file-earmark-arrow-down"></i> Unduh berkas .eml
    </a>
    <a href="#" data-role="buka-manual" class="btn btn-sm btn-outline-dark"><i class="bi bi-envelope"></i> Coba buka email bawaan lagi</a>
    <button type="button" class="btn btn-sm btn-outline-dark" onclick="hoSalin('isiEmailHo')"><i class="bi bi-clipboard"></i> Salin isi email</button>
    <div class="small text-muted mt-2">
      Supaya <code>mailto:</code> dan <code>ms-outlook:</code> jatuh ke <strong>aplikasi New Outlook</strong>,
      Outlook (new) harus jadi aplikasi email default Windows:
      <a href="ms-settings:defaultapps"><i class="bi bi-gear"></i> buka halaman aturannya</a>
      &rarr; <em>Email</em> dan <em>Choose defaults by protocol &rarr; MAILTO</em> = <strong>Outlook (new)</strong>.
      <span class="d-block mt-1">Salah kenali perangkat / cara yang diingat sudah tidak cocok?
        <a href="#" onclick="return hoPilihPerangkat('laptop')">Saya pakai laptop</a> &middot;
        <a href="#" onclick="return hoPilihPerangkat('hp')">Saya pakai HP</a> &middot;
        <a href="#" onclick="return hoLupaRute()">Ulangi pemilihan cara</a>
      </span>
    </div>
  </div>

  <details class="mb-3">
    <summary class="small text-muted" style="cursor:pointer">Lihat dulu isi emailnya</summary>
    <div class="bg-white border rounded p-3 mt-2">
      <div class="small"><span class="text-muted">Kepada:</span> <strong><?= e($hoInfo['kepada']) ?></strong></div>
      <div class="small mb-2"><span class="text-muted">Subjek:</span> <strong><?= e($hoInfo['subjek']) ?></strong></div>
      <pre id="isiEmailHo" class="small mb-0" style="white-space:pre-wrap"><?= e($hoInfo['isi']) ?></pre>
    </div>
  </details>
<?php elseif ($hoInfo && $hoInfo['alasan'] !== ''): ?>
  <div class="alert alert-light border small mb-3"><i class="bi bi-info-circle"></i> <?= e($hoInfo['alasan']) ?></div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-8">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Informasi Pembelian</div>
      <div class="card-body">
        <div class="row row-cols-2 row-cols-md-3 g-3">
          <div><span class="label d-block text-success fw-semibold">No Ticket</span><?= e($purchase['no_ticket']) ?></div>
          <div><span class="label d-block text-success fw-semibold">Tanggal</span><?= format_tanggal($purchase['tanggal']) ?></div>
          <div><span class="label d-block text-success fw-semibold">Daerah</span><?= e($purchase['daerah']) ?></div>
          <div><span class="label d-block text-success fw-semibold">PIC</span><?= e($purchase['pic_name']) ?></div>
          <div><span class="label d-block text-success fw-semibold">Supplier</span><?= e($purchase['vendor_name']) ?></div>
          <div><span class="label d-block text-success fw-semibold">No Nota</span><?= e($purchase['no_nota']) ?></div>
          <div><span class="label d-block text-success fw-semibold">Berat Basah / Tonase</span><?= e($purchase['berat_basah']) ?> KG</div>
          <div><span class="label d-block text-success fw-semibold">Harga Basah</span><?= format_rupiah($purchase['harga_basah']) ?></div>
          <div><span class="label d-block text-success fw-semibold">Harga Harian (Notaring)</span><?= format_rupiah($purchase['harga_notaring']) ?></div>
          <div><span class="label d-block text-success fw-semibold">DRC</span><?= e($purchase['drc']) ?> %</div>
          <div><span class="label d-block text-success fw-semibold">Total Sebelum Pajak</span><?= format_rupiah($purchase['total_harga']) ?></div>
          <div><span class="label d-block text-success fw-semibold">NPWP</span><?= $purchase['punya_npwp'] ? 'Ada (potongan 0,25%)' : 'Tidak Ada (potongan 0,5%)' ?></div>
          <div><span class="label d-block text-success fw-semibold">Total Potongan Pajak</span><?= format_rupiah(total_potongan_pajak($purchase)) ?></div>
          <div><span class="label d-block text-success fw-semibold">Total Setelah Pajak</span><strong><?= format_rupiah(total_setelah_pajak($purchase)) ?></strong></div>
        </div>

        <hr>
        <div class="d-flex gap-2 mb-3 flex-wrap">
          <?= badge_approval($purchase['status_approval']) ?>
          <?php if ($purchase['status_approval'] === 'disetujui'): ?>
            <?= badge_finance_approval($purchase['status_finance_approval']) ?>
            <?= badge_dirops($purchase['status_dirops']) ?>
          <?php endif; ?>
          <?= badge_pembayaran($purchase['status_pembayaran']) ?>
        </div>

        <?php if ($purchase['catatan_revisi_harga']): ?>
          <div class="alert alert-warning border"><strong>Permintaan Revisi Harga dari Petugas:</strong> <?= e($purchase['catatan_revisi_harga']) ?></div>
        <?php endif; ?>

        <?php if ($purchase['catatan_approval']): ?>
          <div class="alert alert-light border">
            <strong>Catatan Petugas:</strong> <?= e($purchase['catatan_approval']) ?>
            <?php if ($purchase['approved_by_name']): ?>
              <div class="small text-muted">oleh <?= e($purchase['approved_by_name']) ?> pada <?= format_tanggal_waktu($purchase['approved_at']) ?></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($purchase['catatan_finance_approval']): ?>
          <div class="alert alert-light border"><strong>Catatan Approval Finance:</strong> <?= e($purchase['catatan_finance_approval']) ?></div>
        <?php endif; ?>

        <?php if ($purchase['catatan_dirops']): ?>
          <div class="alert alert-light border">
            <strong>Catatan Direktur Operasional:</strong> <?= e($purchase['catatan_dirops']) ?>
            <?php if ($purchase['dirops_by_name']): ?>
              <div class="small text-muted">oleh <?= e($purchase['dirops_by_name']) ?> pada <?= format_tanggal_waktu($purchase['dirops_at']) ?></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($purchase['catatan_finance']): ?>
          <div class="alert alert-light border">
            <strong>Catatan Finance:</strong> <?= e($purchase['catatan_finance']) ?>
            <?php if ($purchase['processed_by_name']): ?>
              <div class="small text-muted">oleh <?= e($purchase['processed_by_name']) ?> pada <?= format_tanggal_waktu($purchase['processed_at']) ?></div>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php
        // =========================================================
        // Foto Bokar & Dokumen Pendukung (v12)
        // Satu tiket boleh punya beberapa berkas: foto utama (purchases.foto,
        // tidak berubah peran seperti dulu) + dokumen tambahan (purchase_fotos).
        // PIC dan Admin boleh MENAMBAH berkas di sini tanpa menyentuh data harga
        // maupun status approval - itu sengaja jalur terpisah dari edit.php.
        // =========================================================
        $fotosTiket = purchase_fotos($pdo, $purchase);
        $fotoKunci  = $purchase['status_pembayaran'] === 'selesai' && $user['role'] !== 'admin';
        $bolehFoto  = !$fotoKunci && in_array($user['role'], ['admin', 'pic'], true)
                      && ($user['role'] === 'admin' || $purchase['pic_id'] == $user['id']);
        $kuotaSisa  = max(0, (FOTO_MAKS_TAMBAHAN + 1) - count($fotosTiket));
        if ($fotosTiket) {
            echo foto_galeri_html($fotosTiket, ['purchase_id' => $id, 'boleh_hapus' => $bolehFoto]);
        } else {
            echo '<div class="mt-3"><span class="label d-block text-success fw-semibold mb-2"><i class="bi bi-images"></i> Foto Bokar &amp; Dokumen Pendukung</span>'
               . '<div class="small text-muted">Belum ada berkas untuk tiket ini.</div></div>';
        }
        ?>
        <?php if ($bolehFoto): ?>
          <div class="card border mt-2">
            <div class="card-body py-3">
              <?php if ($kuotaSisa <= 0): ?>
                <div class="small text-muted mb-0"><i class="bi bi-info-circle"></i> Kuota dokumen sudah penuh (<?= FOTO_MAKS_TAMBAHAN + 1 ?> berkas per tiket). Hapus salah satu berkas di atas untuk mengganti.</div>
              <?php else: ?>
                <form method="post" action="<?= BASE_URL ?>/pembelian/foto-tambah.php" enctype="multipart/form-data">
                  <input type="hidden" name="id" value="<?= $id ?>">
                  <label class="form-label mb-1" for="fotoTambahInput"><i class="bi bi-camera"></i> Tambah Foto Bokar / Dokumen Pendukung</label>
                  <div class="d-flex gap-2 flex-wrap align-items-center">
                    <input type="file" name="fotos[]" id="fotoTambahInput" class="form-control" accept="image/*" multiple required style="max-width:340px">
                    <button type="submit" class="btn btn-brand"><i class="bi bi-upload"></i> Unggah</button>
                  </div>
                  <div class="form-text" id="fotoTambahHint">
                    Boleh pilih beberapa berkas sekaligus (foto bokar/timbangan, nota, surat jalan, dokumen lain).
                    Sisa kuota tiket ini: <?= $kuotaSisa ?> berkas &middot; JPG/PNG/WEBP<?= FOTO_MAKS_BYTES > 0 ? ' &middot; maksimal ' . round(FOTO_MAKS_BYTES / 1048576) . ' MB per berkas' : '' ?>.
                  </div>
                </form>
                <script src="<?= BASE_URL ?>/assets/js/image-compress.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/image-compress.js') ?>"></script>
                <script>
                  (function () {
                    var el = document.getElementById('fotoTambahInput');
                    var hint = document.getElementById('fotoTambahHint');
                    var asal = hint.innerHTML;
                    if (!el || !window.ImageCompress) return;
                    var K = <?= json_encode(foto_kompres_opsi(true)) ?>;
                    ImageCompress.attachAutoCompress(el, {
                      maxDimension: K.maxDimension,
                      quality: K.quality,
                      onMany: function (hasil, diterima) {
                        if (!hasil || !hasil.length) return;
                        var kb = hasil.reduce(function (a, r) { return a + r.finalKB; }, 0);
                        var teks = hasil.length + ' berkas siap dikirim (' + kb + ' KB' + (diterima ? ' setelah diperkecil di HP' : ', ukuran asli') + ').';
                        if (!diterima && K.postMax > 0 && kb * 1024 > K.postMax * 0.9) {
                          teks += ' <span class="text-danger">Browser ini tidak bisa memasang kembali hasil perkecilan - total berkas melebihi batas kiriman server (' + Math.round(K.postMax / 1048576 * 10) / 10 + ' MB).</span>';
                        }
                        hint.innerHTML = teks;
                      }
                    });
                    el.addEventListener('change', function () { if (!el.files.length) hint.innerHTML = asal; });
                  })();
                </script>
              <?php endif; ?>
            </div>
          </div>
        <?php elseif ($fotoKunci): ?>
          <div class="alert alert-light border small mt-3 mb-0"><i class="bi bi-lock"></i> Tiket sudah selesai dibayar - berkas dokumen terkunci (hanya Admin yang boleh mengubahnya).</div>
        <?php endif; ?>

        <div class="mt-4 d-flex gap-2 flex-wrap">
          <?php if (in_array($purchase['status_approval'], ['menunggu','revisi_harga']) && ($user['role'] === 'admin' || $purchase['pic_id'] == $user['id'])): ?>
            <a href="<?= BASE_URL ?>/pembelian/edit.php?id=<?= $id ?>" class="btn btn-outline-primary"><i class="bi bi-pencil"></i> Edit</a>
          <?php endif; ?>
          <?php if ($user['role'] === 'petugas' && $purchase['status_approval'] === 'menunggu'): ?>
            <a href="<?= BASE_URL ?>/approval/process.php?id=<?= $id ?>" class="btn btn-brand"><i class="bi bi-check2-square"></i> Proses Approval</a>
          <?php endif; ?>
          <?php if ($user['role'] === 'finance' && $purchase['status_approval'] === 'disetujui' && $purchase['status_finance_approval'] === 'menunggu'): ?>
            <a href="<?= BASE_URL ?>/finance/approve.php?id=<?= $id ?>" class="btn btn-brand"><i class="bi bi-check2-square"></i> Approval Finance</a>
          <?php endif; ?>
          <?php if ($user['role'] === 'dirops' && $purchase['status_approval'] === 'disetujui' && $purchase['status_finance_approval'] === 'disetujui' && $purchase['status_dirops'] === 'menunggu'): ?>
            <a href="<?= BASE_URL ?>/dirops/process.php?id=<?= $id ?>" class="btn btn-brand"><i class="bi bi-person-check"></i> Proses Approval Dirops</a>
          <?php endif; ?>
          <?php if ($user['role'] === 'finance' && $purchase['status_approval'] === 'disetujui' && $purchase['status_finance_approval'] === 'disetujui' && $purchase['status_dirops'] === 'disetujui' && !in_array($purchase['status_pembayaran'], ['selesai', 'dibatalkan'])): ?>
            <a href="<?= BASE_URL ?>/finance/process.php?id=<?= $id ?>" class="btn btn-brand"><i class="bi bi-cash-coin"></i> Proses Pembayaran</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card">
      <div class="card-header bg-white fw-bold">Riwayat / Timeline</div>
      <div class="card-body">
        <ul class="list-unstyled mb-0">
          <?php foreach ($logs as $log): ?>
            <li class="mb-3 pb-3 border-bottom">
              <div class="fw-semibold"><i class="bi bi-dot text-success"></i><?= e($log['action']) ?></div>
              <div class="small text-muted"><?= format_tanggal_waktu($log['created_at']) ?> oleh <?= e($log['user_name']) ?></div>
              <?php if ($log['keterangan']): ?>
                <div class="small mt-1"><?= e($log['keterangan']) ?></div>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
          <?php if (empty($logs)): ?>
            <li class="text-muted small">Belum ada riwayat.</li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
