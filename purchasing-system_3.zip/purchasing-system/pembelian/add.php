<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'pic']);
$user = current_user();
$pageTitle = 'Tambah Pembelian';

$vendors = $pdo->query("SELECT * FROM vendors ORDER BY name")->fetchAll();
$dailyPriceRows = $pdo->query("SELECT tanggal, daerah, harga FROM daily_prices ORDER BY daerah, tanggal DESC")->fetchAll();
$dailyPrices = []; foreach ($dailyPriceRows as $dp) $dailyPrices[$dp['tanggal'].'|'.$dp['daerah']] = $dp['harga'];
$regions = $pdo->query("SELECT DISTINCT daerah FROM daily_prices WHERE daerah <> '' ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
$todayRegion = $pdo->query("SELECT daerah FROM daily_prices WHERE tanggal = CURDATE() ORDER BY daerah LIMIT 1")->fetchColumn();
$defaultRegion = $todayRegion ?: ($regions[0] ?? 'Umum');
$noNotaPreview = get_no_nota_counter_info($pdo)['next'];

$errors = [];
$form = [
    'tanggal' => date('Y-m-d'),
    'vendor_id' => '',
    'daerah' => $defaultRegion,
    'punya_npwp' => '0',
    'berat_basah' => '',
    'harga_basah' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['tanggal'] = $_POST['tanggal'] ?? '';
    $form['vendor_id'] = $_POST['vendor_id'] ?? '';
    $form['daerah'] = trim($_POST['daerah'] ?? 'Umum');
    $form['punya_npwp'] = $_POST['punya_npwp'] ?? '0';
    $form['berat_basah'] = $_POST['berat_basah'] ?? '';
    $form['harga_basah'] = $_POST['harga_basah'] ?? '';

    $pesanPost = upload_pesan_post_kebesaran();
    if ($pesanPost) {
        $errors[] = $pesanPost;
    }

    if ($form['tanggal'] === '') $errors[] = 'Tanggal wajib diisi.';
    if ($form['vendor_id'] === '') $errors[] = 'Supplier wajib dipilih.';
    if ($form['berat_basah'] === '' || !is_numeric($form['berat_basah'])) $errors[] = 'Berat Basah wajib diisi dengan angka.';
    if ($form['harga_basah'] === '' || !is_numeric($form['harga_basah'])) $errors[] = 'Harga Basah wajib diisi dengan angka.';

    // Ambil harga harian (notaring/kering) untuk tanggal yang dipilih -> dipakai hitung DRC
    $hargaNotaring = null;
    if ($form['tanggal'] !== '') {
        $hpStmt = $pdo->prepare("SELECT harga FROM daily_prices WHERE tanggal = ? AND daerah = ?");
        $hpStmt->execute([$form['tanggal'], $form['daerah']]);
        $hargaNotaring = $hpStmt->fetchColumn();
        if (!$hargaNotaring) {
            $areaStmt = $pdo->prepare("SELECT daerah FROM daily_prices WHERE tanggal = ? ORDER BY daerah");
            $areaStmt->execute([$form['tanggal']]);
            $availableAreas = $areaStmt->fetchAll(PDO::FETCH_COLUMN);
            $areaHint = $availableAreas ? ' Daerah yang tersedia pada tanggal tersebut: ' . implode(', ', $availableAreas) . '.' : ' Belum ada daerah yang ditetapkan pada tanggal tersebut.';
            $errors[] = 'Harga Harian (notaring/kering) untuk daerah dan tanggal ini belum ditetapkan oleh Petugas.' . $areaHint;
        }
    }

    // "Foto Bokar & Dokumen Pendukung" - boleh lebih dari satu berkas (v12).
    // Berkas pertama menjadi foto utama (purchases.foto) supaya semua halaman lama
    // (daftar, approval, Dirops, rekap) tetap punya gambar; sisanya masuk purchase_fotos.
    // Yang penting untuk approval & pembayaran (tanggal, supplier, harga) tetap disimpan
    // walaupun ada satu foto yang bermasalah -> foto yang gagal hanya jadi peringatan.
    $fotoName = null;
    $fotoTambahan = [];
    $fotoPeringatan = [];
    if (empty($errors)) {
        $upFoto = handle_photo_upload_multi(__DIR__ . '/../uploads', FOTO_MAKS_TAMBAHAN + 1);
        $fotoPeringatan = $upFoto['errors'];
        if ($upFoto['files']) {
            $fotoName = array_shift($upFoto['files']);
            $fotoTambahan = $upFoto['files'];
        } elseif ($fotoPeringatan) {
            $errors[] = implode(' ', $fotoPeringatan);   // semua berkas gagal
            $fotoPeringatan = [];
        }
    }

    if (empty($errors)) {
        $drc = calculate_drc($form['harga_basah'], $hargaNotaring);
        $pajak = ($form['punya_npwp'] === '1') ? 0.25 : 0.50;
        $totalSebelumPajak = (float)$form['berat_basah'] * (float)$form['harga_basah'];
        $totalSetelahPajak = round($totalSebelumPajak * (1 - $pajak / 100), 2);
        $noTicket = generate_no_ticket($pdo);
        $noNota = generate_no_nota($pdo);
        $picId = $user['role'] === 'admin' ? ($_POST['pic_id'] ?? $user['id']) : $user['id'];

        $stmt = $pdo->prepare("INSERT INTO purchases
            (no_ticket, no_nota, tanggal, daerah, pic_id, vendor_id, berat_basah, harga_basah, harga_notaring, drc, foto, status_approval, status_pembayaran)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'menunggu', 'belum_diajukan')");
        $stmt->execute([
            $noTicket, $noNota, $form['tanggal'], $form['daerah'], $picId, $form['vendor_id'],
            $form['berat_basah'], $form['harga_basah'], $hargaNotaring, $drc, $fotoName
        ]);
        $newId = $pdo->lastInsertId();
        $taxStmt = $pdo->prepare("UPDATE purchases SET punya_npwp=?, persentase_pajak=?, total_setelah_pajak=? WHERE id=?");
        $taxStmt->execute([(int)$form['punya_npwp'], $pajak, $totalSetelahPajak, $newId]);

        if ($fotoTambahan) {
            $simpanFoto = purchase_fotos_simpan($pdo, $newId, $fotoTambahan, $user['id'], __DIR__ . '/../uploads');
            if ($simpanFoto['pesan']) $fotoPeringatan[] = $simpanFoto['pesan'];
            $jumlahFoto = ($fotoName ? 1 : 0) + $simpanFoto['tersimpan'];
        } else {
            $jumlahFoto = $fotoName ? 1 : 0;
        }
        log_activity($pdo, $newId, 'Dibuat', "Pembelian dibuat oleh " . $user['name']
                   . ($jumlahFoto > 0 ? ' (Foto Bokar & Dokumen Pendukung: ' . $jumlahFoto . ' berkas)' : ''));

        // Notifikasi ke Petugas & Admin: ada pembelian baru yang menunggu approval
        notify_role(
            $pdo,
            ['petugas', 'admin'],
            "Pembelian baru {$noTicket} dari {$user['name']} menunggu approval.",
            '/pembelian/detail.php?id=' . $newId,
            $newId,
            'approval_menunggu',
            $user['id']
        );
        notify_role_wa(
            $pdo,
            ['petugas'],
            "Permisi Bapak/Ibu Petugas, mohon kesediaannya untuk memeriksa dan memberikan persetujuan atas pembelian baru {$noTicket} dari PIC {$user['name']}. Apabila data dan dokumen sudah sesuai, mohon kiranya dapat diproses. Terima kasih atas bantuan dan waktunya.",
            $newId
        );

        $pesanSukses = "Pembelian berhasil ditambahkan dengan No Ticket: $noTicket";
        if ($fotoPeringatan) {
            set_flash('warning', $pesanSukses . ' Perhatian: ' . implode(' ', $fotoPeringatan));
        } else {
            set_flash('success', $pesanSukses);
        }
        redirect('/pembelian/detail.php?id=' . $newId);
    }
}

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-plus-lg"></i> Tambah Pembelian</h4>

<div id="connStatus" class="alert py-2 px-3 mb-3 d-flex align-items-center gap-2" style="display:none!important;">
  <span id="connStatusIcon"></span>
  <span id="connStatusText"></span>
</div>

<div id="pendingPanel" class="card mb-3" style="display:none;">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h6 class="mb-0"><i class="bi bi-cloud-upload"></i> Data Belum Terkirim (<span id="pendingCount">0</span>)</h6>
      <button type="button" class="btn btn-sm btn-outline-secondary" id="syncNowBtn">
        <i class="bi bi-arrow-repeat"></i> Kirim Sekarang
      </button>
    </div>
    <div id="pendingList" class="list-group list-group-flush small"></div>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0">
      <?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data" id="pembelianForm">
      <input type="hidden" name="client_uuid" id="clientUuidInput">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Tanggal</label>
          <input type="date" id="tanggalInput" name="tanggal" class="form-control" value="<?= e($form['tanggal']) ?>" required>
          <div class="form-text" id="hargaHarianHint"></div>
        </div>
        <div class="col-md-4">
          <label class="form-label">Supplier</label>
          <select name="vendor_id" id="vendorSelect" class="form-select" required>
            <option value="">-- Pilih Supplier --</option>
            <?php foreach ($vendors as $v): ?>
              <option value="<?= $v['id'] ?>" <?= $form['vendor_id'] == $v['id'] ? 'selected' : '' ?>><?= e(supplier_label($v['name'], $v['kode'] ?? '')) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="form-text">Pilih daerah sesuai harga yang ditetapkan Petugas. Harga Harian berlaku berdasarkan tanggal dan daerah. Belum ada vendor? <a href="<?= BASE_URL ?>/vendors/add.php">Tambah vendor baru</a></div>
        </div>
        <div class="col-md-4">
          <label class="form-label">Daerah</label>
          <select name="daerah" id="daerahInput" class="form-select" required><option value="">-- Pilih Daerah --</option><?php foreach ($regions as $region): ?><option value="<?= e($region) ?>" <?= ($form['daerah'] ?? 'Umum') === $region ? 'selected' : '' ?>><?= e($region) ?></option><?php endforeach; ?></select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Status NPWP Supplier</label>
          <select name="punya_npwp" id="punyaNpwpInput" class="form-select"><option value="0" <?= $form['punya_npwp'] === '0' ? 'selected' : '' ?>>Tidak memiliki NPWP (potongan 0,5%)</option><option value="1" <?= $form['punya_npwp'] === '1' ? 'selected' : '' ?>>Memiliki NPWP (potongan 0,25%)</option></select>
        </div>
        <div class="col-md-4">
          <label class="form-label">No Nota</label>
          <input type="text" class="form-control" value="<?= e($noNotaPreview) ?>" disabled>
          <div class="form-text">Perkiraan nomor urut berikutnya. Nomor final dibuat otomatis saat data disimpan (bisa berbeda kalau ada input lain masuk bersamaan).</div>
        </div>

        <div class="col-md-4">
          <label class="form-label">Berat Basah / Tonase (KG)</label>
          <input type="number" step="0.01" id="beratBasahInput" name="berat_basah" class="form-control" value="<?= e($form['berat_basah']) ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Harga Basah (Rp / KG)</label>
          <input type="number" step="0.01" id="hargaBasahInput" name="harga_basah" class="form-control" value="<?= e($form['harga_basah']) ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">DRC (%) &mdash; otomatis</label>
          <input type="text" class="form-control" id="drcPreview" value="-" disabled>
          <div class="form-text">DRC = Harga Basah &divide; Harga Harian (notaring)</div>
        </div>

        <div class="col-12">
          <label class="form-label"><i class="bi bi-images"></i> Foto Bokar &amp; Dokumen Pendukung</label>
          <input type="file" name="fotos[]" id="fotoInput" class="form-control" accept="image/*" multiple>
          <div class="form-text" id="fotoHint">
            Boleh lebih dari satu: foto bokar (timbangan), nota, surat jalan, dokumen pendukung lainnya.
            Format JPG/PNG/WEBP, maksimal <?= FOTO_MAKS_TAMBAHAN + 1 ?> berkas<?= FOTO_MAKS_BYTES > 0 ? ' &middot; ' . round(FOTO_MAKS_BYTES / 1048576) . ' MB per berkas' : '' ?>
            (otomatis dioptimalkan di HP sebelum dikirim, jadi foto kamera besar pun aman).
            Berkas pertama menjadi foto utama yang tampil di daftar.
          </div>
          <div id="fotoPreview" class="row g-2 mt-1"></div>
        </div>
        <div class="col-md-3"><label class="form-label">Total Sebelum Pajak</label><input type="text" class="form-control" id="pembayaranPreview" value="-" disabled></div>
        <div class="col-md-3"><label class="form-label">Total Potongan Pajak</label><input type="text" class="form-control" id="pembayaranTaxPreview" value="-" disabled></div>
        <div class="col-md-3"><label class="form-label">Total Setelah Pajak</label><input type="text" class="form-control" id="pembayaranNetPreview" value="-" disabled><div class="form-text">NPWP: potongan 0,25%; tanpa NPWP: 0,5%.</div></div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-brand" id="submitBtn"><i class="bi bi-save"></i> Simpan Pembelian</button>
        <a href="<?= BASE_URL ?>/pembelian/list.php" class="btn btn-outline-secondary">Batal</a>
      </div>
      <div class="form-text mt-2">No Ticket akan dibuat otomatis oleh sistem setelah data disimpan.</div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/image-compress.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/image-compress.js') ?>"></script>
<script src="<?= BASE_URL ?>/assets/js/offline-queue.js?v=<?= (int)@filemtime(__DIR__ . '/../assets/js/offline-queue.js') ?>"></script>
<script>
const hargaHarian = <?= json_encode($dailyPrices) ?>;
const vendorNames = <?php $labelVendor = []; foreach ($vendors as $v) { $labelVendor[$v['id']] = supplier_label($v['name'], $v['kode'] ?? ''); } echo json_encode($labelVendor); ?>;
const vendorNpwp = <?= json_encode(array_column($vendors, 'punya_npwp', 'id')) ?>;
const tanggalInput = document.getElementById('tanggalInput');
const daerahInput = document.getElementById('daerahInput');
const punyaNpwpInput = document.getElementById('punyaNpwpInput');
const pembayaranNetPreview = document.getElementById('pembayaranNetPreview');
const pembayaranTaxPreview = document.getElementById('pembayaranTaxPreview');
const beratBasahInput = document.getElementById('beratBasahInput');
const hargaBasahInput = document.getElementById('hargaBasahInput');
const hint = document.getElementById('hargaHarianHint');
const drcPreview = document.getElementById('drcPreview');
const pembayaranPreview = document.getElementById('pembayaranPreview');
const form = document.getElementById('pembelianForm');
const vendorSelect = document.getElementById('vendorSelect');
const clientUuidInput = document.getElementById('clientUuidInput');
const submitBtn = document.getElementById('submitBtn');

function formatRupiah(num) {
  return 'Rp ' + Number(num).toLocaleString('id-ID');
}

function currentHargaNotaring() {
  const key = tanggalInput.value + '|' + daerahInput.value;
  return hargaHarian[key] ? Number(hargaHarian[key]) : null;
}

function updateHint() {
  const notaring = currentHargaNotaring();
  if (notaring) {
    hint.innerHTML = 'Harga Harian (notaring) daerah ini: <strong>' + formatRupiah(notaring) + '</strong> / KG';
  } else {
    hint.innerHTML = '<span class="text-danger">Belum ada Harga Harian yang ditetapkan Petugas untuk tanggal ini. Hubungi Petugas dahulu.</span>';
  }
  updateCalculations();
}

function updateCalculations() {
  const notaring = currentHargaNotaring();
  const hargaBasah = parseFloat(hargaBasahInput.value);
  const berat = parseFloat(beratBasahInput.value);

  if (notaring && !isNaN(hargaBasah) && hargaBasah > 0) {
    const drc = (hargaBasah / notaring) * 100;
    drcPreview.value = drc.toFixed(2) + ' %';
  } else {
    drcPreview.value = '-';
  }

  if (!isNaN(hargaBasah) && !isNaN(berat) && berat > 0) {
    const total = hargaBasah * berat;
    const pajak = punyaNpwpInput.value === '1' ? 0.25 : 0.50;
    pembayaranPreview.value = formatRupiah(total);
    pembayaranTaxPreview.value = formatRupiah(total * pajak / 100);
    pembayaranNetPreview.value = formatRupiah(total * (1 - pajak / 100));
  } else {
    pembayaranPreview.value = '-';
    pembayaranTaxPreview.value = '-';
    pembayaranNetPreview.value = '-';
  }
}

vendorSelect.addEventListener('change', function () { if (vendorNpwp[this.value] !== undefined) punyaNpwpInput.value = String(vendorNpwp[this.value]); updateCalculations(); });
tanggalInput.addEventListener('change', updateHint);
hargaBasahInput.addEventListener('input', updateCalculations);
daerahInput.addEventListener('input', updateHint);
punyaNpwpInput.addEventListener('change', updateCalculations);
beratBasahInput.addEventListener('input', updateCalculations);
updateHint();

// Kompres foto otomatis begitu dipilih, supaya tidak gagal upload gara-gara
// ukuran file dari kamera HP kegedean (kode error 1 di php.ini hosting).
const fotoInput = document.getElementById('fotoInput');
const fotoHint = document.getElementById('fotoHint');
const fotoHintAwal = fotoHint.innerHTML;
const fotoPreview = document.getElementById('fotoPreview');
const FOTO_MAKS = <?= (int)FOTO_MAKS_TAMBAHAN + 1 ?>;
const KOMPRES = <?= json_encode(foto_kompres_opsi(true)) ?>;   // mengikuti batas server

function renderFotoPreview() {
  const files = Array.from(fotoInput.files || []);
  fotoPreview.innerHTML = '';
  files.forEach(function (f, i) {
    const col = document.createElement('div');
    col.className = 'col-4 col-md-2';
    const nama = document.createElement('div');
    nama.className = 'small text-muted text-truncate';
    nama.textContent = (i === 0 ? 'Utama: ' : '') + f.name;
    const img = document.createElement('img');
    img.className = 'foto-thumb w-100';
    img.style.height = '64px';
    img.alt = 'pratinjau ' + f.name;
    const pembaca = new FileReader();
    if (/^image\//.test(f.type)) { pembaca.onload = function (e) { img.src = e.target.result; }; pembaca.readAsDataURL(f); }
    else { img.remove(); }
    col.appendChild(img);
    col.appendChild(nama);
    col.appendChild(Object.assign(document.createElement('div'), { className: 'small', textContent: Math.round(f.size / 1024) + ' KB' }));
    fotoPreview.appendChild(col);
  });
  if (files.length > FOTO_MAKS) {
    fotoHint.innerHTML = '<span class="text-danger">Terlalu banyak berkas: ' + files.length + ' dipilih, yang tersimpan hanya ' + FOTO_MAKS + ' pertama.</span>';
  }
}

fotoInput.addEventListener('change', renderFotoPreview);

// Kompres SEMUA berkas yang dipilih (bukan hanya berkas pertama).
// Untuk banyak berkas diperkecil lebih agresif (1400 px / kualitas 0.68): hosting biasanya
// membatasi post_max_size 2 MB dan ukuran beberapa foto terakumulasi dalam satu kiriman.
ImageCompress.attachAutoCompress(fotoInput, {
  maxDimension: KOMPRES.maxDimension,
  quality: KOMPRES.quality,
  onMany: function (results, diterima) {
    if (!results || !results.length) return;
    const gagal = results.filter(function (r) { return r.error; });
    const sebelum = results.reduce(function (a, r) { return a + r.originalKB; }, 0);
    const sesudah = results.reduce(function (a, r) { return a + r.finalKB; }, 0);
    let teks = results.length + ' foto siap dikirim: ' + sebelum + ' KB &rarr; <strong>' + sesudah + ' KB</strong>.';
    if (gagal.length) {
      teks = '<span class="text-warning">' + gagal.length + ' foto gagal dikompres dan dipakai apa adanya. ' + teks + '</span>';
    }
    if (KOMPRES.postMax > 0 && sesudah * 1024 > KOMPRES.postMax * 0.9) {
      teks += '<div class="text-danger mt-1">Total ' + sesudah + ' KB mendekati/melebihi batas kiriman server (' + Math.round(KOMPRES.postMax / 1048576 * 10) / 10 + ' MB). '
            + 'Kurangi berkasnya, sisanya tambahkan dari halaman detail tiket setelah disimpan.</div>';
    }
    if (!diterima) {
      teks += '<div class="text-danger mt-1">Browser ini tidak mengizinkan foto hasil perkecilan dipasang kembali, '
            + 'jadi foto dikirim apa adanya (' + sesudah + ' KB). Kalau nanti gagal tersimpan, kecilkan foto lebih dulu '
            + 'atau unggah satu per satu dari halaman detail tiket.</div>';
    }
    fotoHint.innerHTML = teks;
  },
});

// =========================================================
// Mode Offline: simpan di HP kalau gak ada internet, auto-kirim kalau online
// =========================================================
clientUuidInput.value = OfflineQueue.uuid();

const connStatus = document.getElementById('connStatus');
const connStatusIcon = document.getElementById('connStatusIcon');
const connStatusText = document.getElementById('connStatusText');

function renderConnStatus() {
  connStatus.style.setProperty('display', 'flex', 'important');
  if (navigator.onLine) {
    connStatus.className = 'alert alert-success py-2 px-3 mb-3 d-flex align-items-center gap-2';
    connStatusIcon.innerHTML = '<i class="bi bi-wifi"></i>';
    connStatusText.textContent = 'Online - data akan langsung tersimpan ke server.';
  } else {
    connStatus.className = 'alert alert-warning py-2 px-3 mb-3 d-flex align-items-center gap-2';
    connStatusIcon.innerHTML = '<i class="bi bi-wifi-off"></i>';
    connStatusText.textContent = 'Tidak ada koneksi internet - data akan disimpan dulu di HP dan otomatis terkirim nanti.';
  }
}
window.addEventListener('online', () => { renderConnStatus(); renderPendingPanel(); });
window.addEventListener('offline', renderConnStatus);
renderConnStatus();

const pendingPanel = document.getElementById('pendingPanel');
const pendingCount = document.getElementById('pendingCount');
const pendingList = document.getElementById('pendingList');

function statusBadge(status) {
  const map = {
    pending: '<span class="badge text-bg-secondary">Menunggu sinyal</span>',
    syncing: '<span class="badge text-bg-info">Mengirim...</span>',
    error: '<span class="badge text-bg-danger">Gagal - perlu dicek</span>',
  };
  return map[status] || map.pending;
}

async function renderPendingPanel() {
  const items = await OfflineQueue.getAllPending();
  pendingCount.textContent = items.length;
  pendingPanel.style.display = items.length ? 'block' : 'none';
  pendingList.innerHTML = '';
  items.sort((a, b) => b.created_at - a.created_at).forEach((item) => {
    const vendorName = vendorNames[item.vendor_id] || ('Supplier #' + item.vendor_id);
    const jumlahBerkas = 1 + ((item.fotos_blobs || []).length);
    const div = document.createElement('div');
    div.className = 'list-group-item d-flex justify-content-between align-items-start';
    div.innerHTML =
      '<div>' +
        '<div><strong>' + item.tanggal + '</strong> &middot; ' + vendorName + '</div>' +
        '<div class="text-muted">' + item.berat_basah + ' KG &middot; Rp ' + Number(item.harga_basah).toLocaleString('id-ID') + '/KG</div>' +
        '<div class="small text-muted">disimpan ' + (item.usia_hari > 0 ? item.usia_hari + ' hari lalu' : 'hari ini')
          + (jumlahBerkas > 1 ? ' &middot; ' + jumlahBerkas + ' foto' : '') + '</div>' +
        (item.usia_hari >= 5 ? '<div class="text-danger small mt-1">Sudah ' + item.usia_hari + ' hari menganggur. Safari/iOS bisa menghapus antrian yang lama tidak dibuka (praktisnya sekitar 7 hari) - sambungkan internet lalu tekan Kirim Sekarang.</div>' : '') +
        (item.error_message ? '<div class="text-danger small mt-1">' + item.error_message + '</div>' : '') +
      '</div>' +
      '<div class="text-end">' + statusBadge(item.status) + '</div>';
    pendingList.appendChild(div);
  });
}

document.getElementById('syncNowBtn').addEventListener('click', async () => {
  await OfflineQueue.syncAll(() => renderPendingPanel());
  renderPendingPanel();
});

form.addEventListener('submit', function (e) {
  if (navigator.onLine) {
    // Online seperti biasa: submit normal ke server (kode PHP di halaman ini yang proses)
    return;
  }

  e.preventDefault();

  const fotoSemua = Array.from(document.getElementById('fotoInput').files || []);
  const fotoFile = fotoSemua[0] || null;
  const record = {
    client_uuid: clientUuidInput.value,
    tanggal: tanggalInput.value,
    vendor_id: document.getElementById('vendorSelect').value,
    daerah: daerahInput.value,
    punya_npwp: punyaNpwpInput.value,
    berat_basah: beratBasahInput.value,
    harga_basah: hargaBasahInput.value,
    foto_blob: fotoFile,
    foto_name: fotoFile ? fotoFile.name : null,
    // v12: sisa berkas (dokumen pendukung) ikut disimpan di HP lalu dikirim
    // berurutan saat online, supaya urutannya sama seperti saat dipilih.
    fotos_blobs: fotoSemua.slice(1),
    fotos_names: fotoSemua.slice(1).map(function (f) { return f.name; }),
  };

  if (!record.tanggal || !record.vendor_id || !record.berat_basah || !record.harga_basah) {
    alert('Mohon lengkapi semua data wajib sebelum disimpan offline.');
    return;
  }

  OfflineQueue.enqueue(record).then(() => {
    alert('Tidak ada internet. Data sudah disimpan di HP dan akan otomatis terkirim begitu ada sinyal.');
    form.reset();
    clientUuidInput.value = OfflineQueue.uuid();
    updateHint();
    renderPendingPanel();
  });
});

renderPendingPanel();
OfflineQueue.refreshReferenceData();

// Begitu ada data referensi baru (misal Petugas baru saja menetapkan Harga
// Harian dan berhasil sync), otomatis perbarui tampilan tanpa perlu reload -
// PIC langsung lihat harga terbaru.
window.addEventListener('offlinequeue:referencedata', function (e) {
  if (e.detail && e.detail.daily_prices) {
    Object.assign(hargaHarian, e.detail.daily_prices);
    updateHint();
  }
  if (e.detail && e.detail.vendors) {
    e.detail.vendors.forEach((v) => { vendorNames[v.id] = v.kode ? (v.name + ' (' + v.kode + ')') : v.name; });
  }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
