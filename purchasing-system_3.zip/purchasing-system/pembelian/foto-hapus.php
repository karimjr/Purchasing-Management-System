<?php
// =========================================================
// Hapus SATU dokumen tambahan (v12)
// ---------------------------------------------------------
// Yang boleh dihapus di sini hanya berkas dari tabel purchase_fotos. Foto UTAMA
// (purchases.foto) tidak bisa dihapus lewat jalur ini - memang begitu aturannya
// sejak awal: foto utama diganti lewat pembelian/edit.php, bukan dihapus, supaya
// tiket tidak pernah kehilangan bukti pokoknya.
// =========================================================
require_once __DIR__ . '/../includes/init.php';
// HANYA PIC (tiketnya sendiri) dan Admin. Petugas/Finance/Dirops melihat galeri yang sama
// tapi tidak bisa menghapus: berkas bukti tidak boleh hilang di tengah proses approval,
// dan peninjau cukup mencatat keberatannya di catatan approval seperti sebelumnya.
require_role(['admin', 'pic']);
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/pembelian/list.php');
}

$id     = (int)($_POST['id'] ?? 0);
$fotoId = (int)($_POST['foto_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();
if (!$purchase) {
    set_flash('danger', 'Data pembelian tidak ditemukan.');
    redirect('/pembelian/list.php');
}

if ($user['role'] === 'pic' && $purchase['pic_id'] != $user['id']) {
    set_flash('danger', 'Anda tidak punya akses ke data pembelian ini.');
    redirect('/dashboard.php');
}
if ($purchase['status_pembayaran'] === 'selesai' && $user['role'] !== 'admin') {
    set_flash('warning', 'Tiket yang sudah selesai dibayar tidak bisa diubah dokumennya. Minta Admin bila memang perlu.');
    redirect('/pembelian/detail.php?id=' . $id);
}

if (!purchase_fotos_tersedia($pdo)) {
    set_flash('warning', 'Fitur dokumen tambahan belum aktif di server ini (tabel purchase_fotos belum ada). Jalankan migration_v12_foto_multi.sql.');
    redirect('/pembelian/detail.php?id=' . $id);
}

$stmt = $pdo->prepare("SELECT f.*, u.name AS user_name FROM purchase_fotos f
                       LEFT JOIN users u ON u.id = f.uploaded_by
                       WHERE f.id = ? AND f.purchase_id = ?");
$stmt->execute([$fotoId, $id]);
$foto = $stmt->fetch();
if (!$foto) {
    set_flash('danger', 'Dokumen tersebut tidak ditemukan.');
    redirect('/pembelian/detail.php?id=' . $id);
}

// PIC hanya boleh menghapus berkas yang IA unggah sendiri (Admin boleh semuanya), dan
// tidak lagi setelah tiket selesai dibayar. Penjaga ini harus berada SETELAH baris
// purchase_fotos dibaca - di atas sana $foto belum ada, jadi aturannya tidak berlaku.
if ($user['role'] === 'pic' && (int)($foto['uploaded_by'] ?? 0) > 0 && (int)$foto['uploaded_by'] !== (int)$user['id']) {
    set_flash('warning', 'Dokumen ini diunggah oleh ' . ($foto['user_name'] ?: 'pengguna lain')
            . ', jadi hanya yang mengunggahnya atau Admin yang bisa menghapusnya.');
    redirect('/pembelian/detail.php?id=' . $id);
}

$delOk = false;
$path = __DIR__ . '/../uploads/' . $foto['file'];
// nama berkas dibuat aplikasi (foto_<hex>) + realpath wajib di dalam folder uploads:
// mencegah berkas di luar folder ikut terhapus kalau tabel diisi manual.
if (preg_match('/^foto_[a-z0-9]+\.[a-z]{3,4}$/', $foto['file']) && is_file($path)) {
    $real = realpath($path);
    $batas = realpath(__DIR__ . '/../uploads');
    if ($real && $batas && strpos($real, $batas . DIRECTORY_SEPARATOR) === 0) {
        $delOk = @unlink($real);
    }
} elseif (!is_file($path)) {
    $delOk = true; // berkasnya memang sudah tidak ada, barisnya tetap boleh dibersihkan
}

if (!$delOk) {
    set_flash('danger', 'Berkas foto gagal dihapus dari server. Hubungi administrator hosting (izin folder uploads).');
    redirect('/pembelian/detail.php?id=' . $id);
}

$pdo->prepare("DELETE FROM purchase_fotos WHERE id = ?")->execute([$fotoId]);
log_activity($pdo, $id, 'Foto Dihapus', 'Satu dokumen pendukung dihapus oleh ' . $user['name']);
set_flash('success', 'Dokumen berhasil dihapus.');
redirect('/pembelian/detail.php?id=' . $id);
