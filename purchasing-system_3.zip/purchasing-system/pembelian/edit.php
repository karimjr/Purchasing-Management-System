<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'pic']);
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM purchases WHERE id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data pembelian tidak ditemukan.');
    redirect('/pembelian/list.php');
}
if ($user['role'] !== 'admin' && $purchase['pic_id'] != $user['id']) {
    set_flash('danger', 'Anda tidak punya akses untuk mengubah data ini.');
    redirect('/pembelian/list.php');
}
if ($purchase['status_approval'] === 'revisi_harga') {
    $isPriceRevision = true;
} else {
    $isPriceRevision = false;
}
if ($purchase['status_approval'] !== 'menunggu' && $purchase['status_approval'] !== 'revisi_harga') {
    set_flash('warning', 'Data yang sudah diproses approval tidak dapat diubah lagi.');
    redirect('/pembelian/detail.php?id=' . $id);
}

$vendors = $pdo->query("SELECT * FROM vendors ORDER BY name")->fetchAll();
$dailyPriceRows = $pdo->query("SELECT tanggal, daerah, harga FROM daily_prices")->fetchAll(); $dailyPrices = []; foreach ($dailyPriceRows as $dp) $dailyPrices[$dp['tanggal'].'|'.$dp['daerah']] = $dp['harga'];
$regions = $pdo->query("SELECT DISTINCT daerah FROM daily_prices WHERE daerah <> '' ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);
$errors = [];
$form = $purchase;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['tanggal'] = $isPriceRevision && $user['role'] !== 'admin' ? $purchase['tanggal'] : ($_POST['tanggal'] ?? '');
    $form['vendor_id'] = $isPriceRevision && $user['role'] !== 'admin' ? $purchase['vendor_id'] : ($_POST['vendor_id'] ?? '');
    $form['daerah'] = $isPriceRevision && $user['role'] !== 'admin' ? ($purchase['daerah'] ?? 'Umum') : trim($_POST['daerah'] ?? ($purchase['daerah'] ?? 'Umum'));
    $form['punya_npwp'] = $isPriceRevision && $user['role'] !== 'admin' ? ($purchase['punya_npwp'] ?? '0') : ($_POST['punya_npwp'] ?? ($purchase['punya_npwp'] ?? '0'));
    $form['berat_basah'] = $_POST['berat_basah'] ?? '';
    $form['harga_basah'] = $_POST['harga_basah'] ?? '';
    // No Nota & No Tiket dibuat otomatis saat pembelian pertama kali dibuat.
    // Hanya Admin yang boleh mengoreksi manual (misal salah generate/duplikat), PIC tidak.
    if ($user['role'] === 'admin') {
        $form['no_nota'] = trim($_POST['no_nota'] ?? $purchase['no_nota']);
        $form['no_ticket'] = trim($_POST['no_ticket'] ?? $purchase['no_ticket']);
        if ($form['no_ticket'] === '') {
            $errors[] = 'No Tiket wajib diisi.';
        } elseif ($form['no_ticket'] !== $purchase['no_ticket']) {
            $cek = $pdo->prepare("SELECT id FROM purchases WHERE no_ticket = ? AND id <> ? LIMIT 1");
            $cek->execute([$form['no_ticket'], $id]);
            if ($cek->fetchColumn()) {
                $errors[] = 'No Tiket "' . $form['no_ticket'] . '" sudah dipakai tiket lain. Pakai nomor lain.';
            }
        }
    }

    if ($form['tanggal'] === '') $errors[] = 'Tanggal wajib diisi.';
    if ($form['vendor_id'] === '') $errors[] = 'Supplier wajib dipilih.';
    if ($form['berat_basah'] === '' || !is_numeric($form['berat_basah'])) $errors[] = 'Berat Basah wajib diisi dengan angka.';
    if ($form['harga_basah'] === '' || !is_numeric($form['harga_basah'])) $errors[] = 'Harga Basah wajib diisi dengan angka.';

    $hargaNotaring = null;
    if ($form['tanggal'] !== '') {
        $hpStmt = $pdo->prepare("SELECT harga FROM daily_prices WHERE tanggal = ? AND daerah = ?");
        $hpStmt->execute([$form['tanggal'], $form['daerah']]);
        $hargaNotaring = $hpStmt->fetchColumn();
        if (!$hargaNotaring) {
            $errors[] = 'Harga Harian (notaring/kering) untuk tanggal ini belum ditetapkan oleh Petugas. Hubungi Petugas terlebih dahulu, atau pilih tanggal lain.';
        }
    }

    $fotoName = $purchase['foto'];
    if (empty($errors)) {
        try {
            $uploaded = handle_photo_upload('foto', __DIR__ . '/../uploads');
            if ($uploaded) {
                $fotoName = $uploaded;
            }
        } catch (Exception $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (empty($errors)) {
        $drc = calculate_drc($form['harga_basah'], $hargaNotaring);
        $pajak = ($form['punya_npwp'] === '1') ? 0.25 : 0.50;
        $totalSetelahPajak = round(((float)$form['harga_basah'] * (float)$form['berat_basah']) * (1 - $pajak / 100), 2);
        $stmt = $pdo->prepare("UPDATE purchases SET tanggal=?, daerah=?, vendor_id=?, no_nota=?, no_ticket=?, berat_basah=?, harga_basah=?, harga_notaring=?, drc=?, punya_npwp=?, persentase_pajak=?, total_setelah_pajak=?, foto=?, status_approval=IF(?='revisi_harga','menunggu',status_approval), status_finance_approval=IF(?='revisi_harga','menunggu',status_finance_approval), status_dirops=IF(?='revisi_harga','menunggu',status_dirops), status_pembayaran=IF(?='revisi_harga','belum_diajukan',status_pembayaran), catatan_revisi_harga=IF(?='revisi_harga',catatan_revisi_harga,NULL) WHERE id=?");
        $stmt->execute([
            $form['tanggal'], $form['daerah'], $form['vendor_id'], $form['no_nota'], $form['no_ticket'],
            $form['berat_basah'], $form['harga_basah'], $hargaNotaring, $drc, (int)$form['punya_npwp'], $pajak, $totalSetelahPajak, $fotoName, $isPriceRevision ? 'revisi_harga' : $purchase['status_approval'], $isPriceRevision ? 'revisi_harga' : $purchase['status_approval'], $isPriceRevision ? 'revisi_harga' : $purchase['status_approval'], $isPriceRevision ? 'revisi_harga' : $purchase['status_approval'], $isPriceRevision ? 'revisi_harga' : $purchase['status_approval'], $id
        ]);
        if ($isPriceRevision) { notify_role($pdo, ['petugas','admin'], "PIC {$user['name']} telah menyesuaikan harga pembelian {$purchase['no_ticket']} sesuai permintaan revisi. Mohon diperiksa kembali.", '/approval/process.php?id='.$id, $id, 'approval_menunggu', $user['id']); notify_role_wa($pdo, ['petugas'], "Permisi Bapak/Ibu Petugas, PIC {$user['name']} telah menyesuaikan harga tiket {$purchase['no_ticket']} sesuai permintaan revisi. Mohon dibantu untuk memeriksa kembali. Terima kasih.", $id); }
        log_activity($pdo, $id, 'Diedit', "Data diubah oleh " . $user['name']);
        set_flash('success', 'Data pembelian berhasil diperbarui.');
        redirect('/pembelian/detail.php?id=' . $id);
    }
}

$pageTitle = 'Edit Pembelian';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-pencil"></i> Edit Pembelian - <?= e($purchase['no_ticket']) ?></h4>

<?php if ($errors): ?>
  <div class="alert alert-danger">
    <ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<?= $id ?>">
      <div class="row g-3">
        <div class="col-md-4">
          <label class="form-label">Tanggal</label>
          <input type="date" id="tanggalInput" name="tanggal" class="form-control" <?= $isPriceRevision && $user['role'] !== 'admin' ? 'readonly' : '' ?> value="<?= e($form['tanggal']) ?>" required>
          <div class="form-text" id="hargaHarianHint"></div>
        </div>
        <div class="col-md-4">
          <label class="form-label">Supplier</label>
          <select name="vendor_id" class="form-select" required <?= $isPriceRevision && $user['role'] !== 'admin' ? 'disabled' : '' ?>
            <?php foreach ($vendors as $v): ?>
              <option value="<?= $v['id'] ?>" <?= $form['vendor_id'] == $v['id'] ? 'selected' : '' ?>><?= e(supplier_label($v['name'], $v['kode'] ?? '')) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4"><label class="form-label">Daerah</label><select name="daerah" id="daerahInput" class="form-select" required <?= $isPriceRevision && $user['role'] !== 'admin' ? 'disabled' : '' ?>><option value="">-- Pilih Daerah --</option><?php foreach ($regions as $region): ?><option value="<?= e($region) ?>" <?= ($form['daerah'] ?? 'Umum') === $region ? 'selected' : '' ?>><?= e($region) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-4"><label class="form-label">Status NPWP Supplier</label><select name="punya_npwp" id="punyaNpwpInput" class="form-select" <?= $isPriceRevision && $user['role'] !== 'admin' ? 'disabled' : '' ?>><option value="0" <?= (int)($form['punya_npwp'] ?? 0) === 0 ? 'selected' : '' ?>>Tidak memiliki NPWP (0,5%)</option><option value="1" <?= (int)($form['punya_npwp'] ?? 0) === 1 ? 'selected' : '' ?>>Memiliki NPWP (0,25%)</option></select></div>
        <div class="col-md-4">
          <label class="form-label">No Nota</label>
          <?php if ($user['role'] === 'admin'): ?>
            <input type="text" name="no_nota" class="form-control" value="<?= e($form['no_nota']) ?>" required>
            <div class="form-text">Admin dapat mengoreksi No Nota secara manual bila perlu.</div>
          <?php else: ?>
            <input type="text" class="form-control" value="<?= e($form['no_nota']) ?>" disabled>
            <div class="form-text">Dibuat otomatis oleh sistem, tidak bisa diubah.</div>
          <?php endif; ?>
        </div>

        <div class="col-md-4">
          <label class="form-label">No Tiket</label>
          <?php if ($user['role'] === 'admin'): ?>
            <input type="text" name="no_ticket" class="form-control" value="<?= e($form['no_ticket']) ?>" required>
            <div class="form-text">Admin dapat menetapkan/mengoreksi No Tiket tiket ini. Nomor tidak boleh sama dengan tiket lain.</div>
          <?php else: ?>
            <input type="text" class="form-control" value="<?= e($form['no_ticket']) ?>" disabled>
            <div class="form-text">Dibuat otomatis berurutan oleh sistem.</div>
          <?php endif; ?>
        </div>

        <div class="col-md-4">
          <label class="form-label">Berat Basah / Tonase (KG)</label>
          <input type="number" step="0.01" id="beratBasahInput" name="berat_basah" class="form-control" value="<?= e($form['berat_basah']) ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">Harga Basah (Rp / KG)</label>
          <input type="number" step="0.01" id="hargaBasahInput" name="harga_basah" class="form-control" value="<?= e($form['harga_basah']) ?>" required>
        </div>
        <div class="col-md-4">
          <label class="form-label">DRC (%) &mdash; otomatis</label>
          <input type="text" class="form-control" id="drcPreview" value="<?= e($form['drc']) ?> %" disabled>
          <div class="form-text">DRC = Harga Basah &divide; Harga Harian (notaring)</div>
        </div>

        <div class="col-md-6">
          <label class="form-label">Foto Bukti Pembelian</label>
          <?php if ($isPriceRevision && $user['role'] !== 'admin'): ?><div class="form-text text-info">Mode revisi harga: data dan foto lama dipertahankan. Anda cukup mengubah Harga Basah.</div><?php endif; ?>
          <?php if ($purchase['foto']): ?>
            <div class="mb-2"><img src="<?= BASE_URL ?>/uploads/<?= e($purchase['foto']) ?>" class="foto-thumb"></div>
          <?php endif; ?>
          <input type="file" name="foto" id="fotoInput" class="form-control" accept="image/*" <?= $isPriceRevision && $user['role'] !== 'admin' ? 'disabled' : '' ?>>
          <div class="form-text" id="fotoHint">Kosongkan jika tidak ingin mengubah foto. Foto baru otomatis dikompres sebelum dikirim.</div>
        </div>
        <div class="col-md-6">
          <label class="form-label">Total Sebelum Pajak</label>
          <input type="text" class="form-control" id="pembayaranPreview" value="<?= format_rupiah($form['harga_basah'] * $form['berat_basah']) ?>" disabled>
          <div class="form-text">Harga Basah × Tonase</div>
          <div class="form-text">Harga Pembayaran = Harga Basah &times; Tonase (Berat Basah)</div>
        </div>
        <div class="col-md-3"><label class="form-label">Total Potongan Pajak</label><input type="text" class="form-control" id="pembayaranTaxPreview" value="-" disabled></div>
        <div class="col-md-3"><label class="form-label">Total Setelah Pajak</label><input type="text" class="form-control" id="pembayaranNetPreview" value="<?= format_rupiah($form['total_setelah_pajak'] ?? ($form['harga_basah'] * $form['berat_basah'])) ?>" disabled><div class="form-text">NPWP 0,25%; tanpa NPWP 0,5%.</div></div>
      </div>

      <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan Perubahan</button>
        <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $id ?>" class="btn btn-outline-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/image-compress.js"></script>
<script>
const hargaHarian = <?= json_encode($dailyPrices) ?>;
const tanggalInput = document.getElementById('tanggalInput');
const daerahInput = document.getElementById('daerahInput');
const punyaNpwpInput = document.getElementById('punyaNpwpInput');
const pembayaranNetPreview = document.getElementById('pembayaranNetPreview');
const pembayaranTaxPreview = document.getElementById('pembayaranTaxPreview');
const beratBasahInput = document.getElementById('beratBasahInput');
const hargaBasahInput = document.getElementById('hargaBasahInput');
const hint = document.getElementById('hargaHarianHint');
const drcPreview = document.getElementById('drcPreview');
const pembayaranPreview = document.getElementById('pembayaranPreview');

function formatRupiah(num) {
  return 'Rp ' + Number(num).toLocaleString('id-ID');
}

function currentHargaNotaring() {
  const key = tanggalInput.value + '|' + daerahInput.value; return hargaHarian[key] ? Number(hargaHarian[key]) : null;
}

function updateHint() {
  const notaring = currentHargaNotaring();
  if (notaring) {
    hint.innerHTML = 'Harga Harian (notaring) tanggal ini: <strong>' + formatRupiah(notaring) + '</strong> / KG';
  } else {
    hint.innerHTML = '<span class="text-danger">Belum ada Harga Harian yang ditetapkan Petugas untuk tanggal ini. Hubungi Petugas dahulu.</span>';
  }
  updateCalculations();
}

function updateCalculations() {
  const notaring = currentHargaNotaring();
  const hargaBasah = parseFloat(hargaBasahInput.value);
  const berat = parseFloat(beratBasahInput.value);

  if (notaring && !isNaN(hargaBasah) && hargaBasah > 0) {
    const drc = (hargaBasah / notaring) * 100;
    drcPreview.value = drc.toFixed(2) + ' %';
  } else if (!notaring) {
    drcPreview.value = '-';
  }

  if (!isNaN(hargaBasah) && !isNaN(berat) && berat > 0) {
    const total = hargaBasah * berat; const pajak = punyaNpwpInput.value === '1' ? 0.25 : 0.50; pembayaranPreview.value = formatRupiah(total); pembayaranTaxPreview.value = formatRupiah(total * pajak / 100); pembayaranNetPreview.value = formatRupiah(total * (1 - pajak / 100));
  }
}

daerahInput.addEventListener('input', updateHint); punyaNpwpInput.addEventListener('change', updateCalculations); tanggalInput.addEventListener('change', updateHint);
hargaBasahInput.addEventListener('input', updateCalculations);
beratBasahInput.addEventListener('input', updateCalculations);

const fotoInput = document.getElementById('fotoInput');
const fotoHint = document.getElementById('fotoHint');
ImageCompress.attachAutoCompress(fotoInput, {
  onDone: function (result) {
    if (result.error) {
      fotoHint.innerHTML = '<span class="text-warning">Gagal mengompres foto, dipakai apa adanya (' + result.originalKB + ' KB).</span>';
    } else if (result.finalKB < result.originalKB) {
      fotoHint.innerHTML = 'Foto dikompres: ' + result.originalKB + ' KB &rarr; <strong>' + result.finalKB + ' KB</strong>.';
    } else {
      fotoHint.textContent = 'Ukuran foto: ' + result.finalKB + ' KB.';
    }
  },
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
