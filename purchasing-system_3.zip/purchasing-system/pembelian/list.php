<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'pic', 'petugas', 'finance', 'dirops', 'manajemen']);
$user = current_user();
$pageTitle = 'Daftar Pembelian';

$search = trim($_GET['search'] ?? '');
$tanggal = trim($_GET['tanggal'] ?? '');
$statusApproval = trim($_GET['status_approval'] ?? '');
$statusPembayaran = trim($_GET['status_pembayaran'] ?? '');

$where = [];
$params = [];

if ($user['role'] === 'pic') {
    $where[] = 'p.pic_id = ?';
    $params[] = $user['id'];
}
if ($search !== '') {
    $where[] = '(p.no_ticket LIKE ? OR p.no_nota LIKE ? OR v.name LIKE ?)';
    $like = "%$search%";
    array_push($params, $like, $like, $like);
}
if ($tanggal !== '') {
    $where[] = 'p.tanggal = ?';
    $params[] = $tanggal;
}
if ($statusApproval !== '') {
    $where[] = 'p.status_approval = ?';
    $params[] = $statusApproval;
}
if ($statusPembayaran !== '') {
    $where[] = 'p.status_pembayaran = ?';
    $params[] = $statusPembayaran;
}

$sql = "SELECT p.*, v.name as vendor_name, u.name as pic_name
        FROM purchases p
        JOIN vendors v ON v.id = p.vendor_id
        JOIN users u ON u.id = p.pic_id";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY p.created_at DESC';

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$purchases = $stmt->fetchAll();
// v12: jumlah berkas per tiket diambil sekali query (bukan per baris) supaya halaman
// daftar tidak melambat kalau tiap tiket punya beberapa foto dokumen.
$fotosPerTiket = purchase_fotos_batch($pdo, $purchases);

// Cache daftar penerima WA per-role, dipakai untuk tombol WA cepat di setiap baris
$waUsersByRole = [
    'petugas' => get_users_with_wa($pdo, ['petugas']),
    'dirops'  => get_users_with_wa($pdo, ['dirops']),
    'finance' => get_users_with_wa($pdo, ['finance']),
];

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-cart3"></i> Daftar Pembelian <?= $user['role'] !== 'pic' ? '<span class="fs-6 text-muted">(Semua PIC)</span>' : '' ?></h4>
  <?php if (in_array($user['role'], ['admin', 'pic'])): ?>
    <a href="<?= BASE_URL ?>/pembelian/add.php" class="btn btn-brand">
      <i class="bi bi-plus-lg"></i> Tambah Pembelian
    </a>
  <?php endif; ?>
</div>

<form method="GET" class="row g-2 mb-4">
  <div class="col-md-3">
    <input type="date" name="tanggal" value="<?= e($tanggal) ?>" class="form-control" onchange="this.form.submit()">
  </div>
  <div class="col-md-4">
    <div class="input-group">
      <span class="input-group-text"><i class="bi bi-search"></i></span>
      <input type="text" name="search" value="<?= e($search) ?>" class="form-control" placeholder="Cari No Ticket / No Nota / Supplier...">
    </div>
  </div>
  <div class="col-md-2">
    <select name="status_approval" class="form-select" onchange="this.form.submit()">
      <option value="">Semua Approval</option>
      <option value="menunggu" <?= $statusApproval === 'menunggu' ? 'selected' : '' ?>>Menunggu Approval</option>
      <option value="disetujui" <?= $statusApproval === 'disetujui' ? 'selected' : '' ?>>Disetujui</option>
      <option value="ditolak" <?= $statusApproval === 'ditolak' ? 'selected' : '' ?>>Ditolak</option>
    </select>
  </div>
  <div class="col-md-2">
    <select name="status_pembayaran" class="form-select" onchange="this.form.submit()">
      <option value="">Semua Pembayaran</option>
      <option value="belum_diajukan" <?= $statusPembayaran === 'belum_diajukan' ? 'selected' : '' ?>>Belum Diajukan</option>
      <option value="menunggu_pembayaran" <?= $statusPembayaran === 'menunggu_pembayaran' ? 'selected' : '' ?>>Menunggu Pembayaran</option>
      <option value="sedang_diproses" <?= $statusPembayaran === 'sedang_diproses' ? 'selected' : '' ?>>Sedang Diproses</option>
      <option value="selesai" <?= $statusPembayaran === 'selesai' ? 'selected' : '' ?>>Selesai / Done</option>
      <option value="gagal" <?= $statusPembayaran === 'gagal' ? 'selected' : '' ?>>Gagal</option>
      <option value="dibatalkan" <?= $statusPembayaran === 'dibatalkan' ? 'selected' : '' ?>>Dibatalkan</option>
    </select>
  </div>
  <div class="col-md-1">
    <button class="btn btn-outline-secondary w-100" type="submit"><i class="bi bi-search"></i></button>
  </div>
</form>

<?php if (empty($purchases)): ?>
  <div class="text-center text-muted py-5">
    <i class="bi bi-inbox fs-1"></i>
    <p class="mt-2">Belum ada data pembelian.</p>
  </div>
<?php else: foreach ($purchases as $row): ?>
  <div class="card card-purchase mb-3">
    <div class="card-body">
      <div class="row">
        <div class="col-md-9">
          <div class="row row-cols-2 row-cols-md-3 g-2">
            <div><span class="label d-block">No Ticket</span><?= e($row['no_ticket']) ?></div>
            <div><span class="label d-block">Tanggal</span><?= format_tanggal($row['tanggal']) ?></div>
            <div><span class="label d-block">Daerah</span><?= e($row['daerah']) ?></div>
            <div><span class="label d-block">PIC</span><?= e($row['pic_name']) ?></div>
            <div><span class="label d-block">Supplier</span><?= e($row['vendor_name']) ?></div>
            <div><span class="label d-block">No Nota</span><?= e($row['no_nota']) ?></div>
            <div><span class="label d-block">Berat Basah</span><?= e($row['berat_basah']) ?> KG</div>
            <div><span class="label d-block">DRC</span><?= e($row['drc']) ?> %</div>
            <div><span class="label d-block">Harga Basah</span><?= format_rupiah($row['harga_basah']) ?></div>
            <div><span class="label d-block">Total Sebelum Pajak</span><?= format_rupiah($row['total_harga']) ?></div>
            <div><span class="label d-block">Total Potongan</span><?= format_rupiah(total_potongan_pajak($row)) ?></div>
            <div><span class="label d-block">Total Setelah Pajak</span><strong><?= format_rupiah(total_setelah_pajak($row)) ?></strong></div>
          </div>
          <div class="mt-2 d-flex gap-2 flex-wrap align-items-center">
            <?= badge_approval($row['status_approval']) ?>
            <?php if ($row['status_approval'] === 'disetujui'): ?>
              <?= badge_finance_approval($row['status_finance_approval']) ?>
              <?= badge_dirops($row['status_dirops']) ?>
            <?php endif; ?>
            <?= badge_pembayaran($row['status_pembayaran']) ?>
            <?= render_wa_button($row, $waUsersByRole) ?>
          </div>
        </div>
        <div class="col-md-3 d-flex flex-md-column justify-content-end align-items-md-end gap-2 mt-3 mt-md-0">
          <?php if ($row['foto']): ?>
            <div class="position-relative d-inline-block">
              <img src="<?= BASE_URL ?>/uploads/<?= e($row['foto']) ?>" class="foto-thumb" data-bs-toggle="modal" data-bs-target="#fotoModal<?= $row['id'] ?>" alt="foto bukti">
              <?php $jmlFotoBaris = count($fotosPerTiket[$row['id']] ?? []); ?>
              <?php if ($jmlFotoBaris > 1): ?>
                <span class="badge text-bg-dark position-absolute top-0 start-0 translate-middle" data-bs-toggle="modal" data-bs-target="#fotoModal<?= $row['id'] ?>"><?= $jmlFotoBaris ?></span>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          <div class="d-flex gap-2">
            <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
            <?php if ($row['status_approval'] === 'menunggu' && ($user['role'] === 'admin' || $row['pic_id'] == $user['id'])): ?>
              <a href="<?= BASE_URL ?>/pembelian/edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
              <a href="<?= BASE_URL ?>/pembelian/delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" title="Hapus" onclick="return confirm('Hapus data pembelian ini?')"><i class="bi bi-trash"></i></a>
            <?php endif; ?>
            <?php if ($user['role'] === 'petugas' && $row['status_approval'] === 'menunggu'): ?>
              <a href="<?= BASE_URL ?>/approval/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses Approval"><i class="bi bi-check2-square"></i></a>
            <?php endif; ?>
            <?php if ($user['role'] === 'dirops' && $row['status_approval'] === 'disetujui' && $row['status_finance_approval'] === 'disetujui' && $row['status_dirops'] === 'menunggu'): ?>
              <a href="<?= BASE_URL ?>/dirops/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses Approval Dirops"><i class="bi bi-person-check"></i></a>
            <?php endif; ?>
            <?php if ($user['role'] === 'finance' && $row['status_approval'] === 'disetujui' && $row['status_finance_approval'] === 'disetujui' && $row['status_dirops'] === 'disetujui' && !in_array($row['status_pembayaran'], ['selesai', 'dibatalkan'])): ?>
              <a href="<?= BASE_URL ?>/finance/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses Pembayaran"><i class="bi bi-cash-coin"></i></a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php if ($row['foto']): ?>
  <div class="modal fade" id="fotoModal<?= $row['id'] ?>" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title">Foto - <?= e($row['no_ticket']) ?></h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body text-center">
          <?php $galeriBaris = foto_galeri_html($fotosPerTiket[$row['id']] ?? [], ['purchase_id' => 0]); ?>
          <?php if ($galeriBaris !== ''): ?>
            <?= $galeriBaris ?>
          <?php else: ?>
            <img src="<?= BASE_URL ?>/uploads/<?= e($row['foto']) ?>" class="foto-preview">
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
<?php endforeach; endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
