<?php
// =========================================================
// Cron: Reminder WhatsApp berjenjang
// =========================================================
// Dijalankan berkala (disarankan tiap 1 jam) lewat Cron Job hosting,
// TIDAK dibuka lewat browser. Contoh pengaturan Cron Job di cPanel:
//
//   0 * * * *  php /home/USERNAME/public_html/purchasing-system/cron/wa_reminder.php
//
// (sesuaikan path & jadwal sesuai kebutuhan, minimal tiap 1 jam supaya
// pengingat cukup responsif tapi tidak membanjiri WhatsApp penerima).
//
// Script ini mengingatkan ULANG pihak yang belum bertindak di setiap
// tahap approval (Petugas -> Dirops -> Finance) kalau sudah lebih lama
// dari batas jam yang diatur di menu Pengaturan > WhatsApp (Admin).
// =========================================================

// Jangan jalankan lewat browser biasa, hanya lewat CLI (php-cli) atau
// tool cron hosting yang setara. Ini mencegah orang luar memicu kirim
// pesan massal lewat URL publik.
if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    die("Script ini hanya boleh dijalankan lewat CLI/Cron Job, bukan lewat browser.\n");
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$result = run_wa_reminders($pdo);

echo "[" . date('Y-m-d H:i:s') . "] Reminder WA selesai dijalankan.\n";
echo "  - Reminder ke Petugas: {$result['petugas']} tiket\n";
echo "  - Reminder ke Dirops  : {$result['dirops']} tiket\n";
echo "  - Reminder ke Finance : {$result['finance']} tiket\n";
