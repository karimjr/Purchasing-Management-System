<?php
// Endpoint JSON: data referensi (supplier + harga harian) supaya PIC bisa
// tetap mengisi form Tambah Pembelian walau HP sedang offline.
require_once __DIR__ . '/../includes/init.php';

$user = api_auth($pdo);
if (!$user || !in_array($user['role'], ['admin', 'pic', 'petugas'])) {
    json_response(['success' => false, 'message' => 'Tidak diizinkan. Silakan login ulang.'], 401);
}

// Kolom `kode` (No. ID Supplier) ikut dikirim supaya dropdown di HP tetap
// menampilkan "Nama (No. ID)" walau sedang offline. Kalau migrasi v17 belum
// dijalankan (kolom belum ada), otomatis kembali ke daftar tanpa kode.
try {
    $vendors = $pdo->query("SELECT id, kode, name, punya_npwp FROM vendors ORDER BY name")->fetchAll();
} catch (Exception $e) {
    $vendors = $pdo->query("SELECT id, name, punya_npwp FROM vendors ORDER BY name")->fetchAll();
}

// Kirim harga harian 90 hari terakhir + 7 hari ke depan (kalau ada) supaya cukup untuk offline
$stmt = $pdo->prepare("SELECT tanggal, daerah, harga FROM daily_prices WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)");
$stmt->execute();
$dailyPrices = [];
foreach ($stmt->fetchAll() as $row) $dailyPrices[$row['tanggal'] . '|' . $row['daerah']] = $row['harga'];

json_response([
    'success' => true,
    'user' => ['id' => $user['id'], 'name' => $user['name'], 'role' => $user['role']],
    'vendors' => $vendors,
    'daily_prices' => $dailyPrices,
    'server_time' => date('Y-m-d H:i:s'),
]);
