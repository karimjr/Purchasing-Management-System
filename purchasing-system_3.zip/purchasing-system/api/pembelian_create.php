<?php
// Endpoint JSON: dipakai oleh mekanisme auto-sync offline PIC.
// Menerima data yang sebelumnya disimpan di HP (IndexedDB) saat tidak ada
// internet, lalu menyimpannya ke database begitu koneksi kembali tersedia.
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Metode tidak diizinkan.'], 405);
}

$user = api_auth($pdo);
if (!$user || !in_array($user['role'], ['admin', 'pic'])) {
    json_response(['success' => false, 'message' => 'Sesi habis atau tidak diizinkan. Silakan login ulang di aplikasi.'], 401);
}

// Sama seperti halaman form: kalau post_max_size terlampaui, PHP mengosongkan seluruh
// $_POST/$_FILES, jadi pesan yang menjelaskan UKURANNYA harus keluar sebelum cek lain
// (kalau tidak, HP cuma menerima "client_uuid wajib diisi" yang tidak ada gunanya).
$pesanPost = upload_pesan_post_kebesaran();
if ($pesanPost) {
    json_response(['success' => false, 'message' => $pesanPost, 'foto_terlalu_besar' => true], 413);
}

$clientUuid = trim($_POST['client_uuid'] ?? '');
if ($clientUuid === '') {
    json_response(['success' => false, 'message' => 'client_uuid wajib diisi.'], 422);
}

// Anti-duplikat: kalau data dengan client_uuid ini sudah pernah masuk
// (misal sempat terkirim tapi HP tidak sempat terima konfirmasinya lalu
// mencoba kirim ulang), kembalikan data yang sudah ada, jangan bikin baris baru.
$existingStmt = $pdo->prepare("SELECT id, no_ticket FROM purchases WHERE client_uuid = ?");
$existingStmt->execute([$clientUuid]);
$existing = $existingStmt->fetch();
if ($existing) {
    json_response([
        'success' => true,
        'duplicate' => true,
        'id' => $existing['id'],
        'no_ticket' => $existing['no_ticket'],
        'message' => 'Data ini sudah tersimpan sebelumnya.',
    ]);
}

$form = [
    'tanggal'     => trim($_POST['tanggal'] ?? ''),
    'vendor_id'   => trim($_POST['vendor_id'] ?? ''),
    'daerah'      => trim($_POST['daerah'] ?? 'Umum'),
    'punya_npwp'  => trim($_POST['punya_npwp'] ?? '0'),
    'berat_basah' => trim($_POST['berat_basah'] ?? ''),
    'harga_basah' => trim($_POST['harga_basah'] ?? ''),
];

$errors = [];
if ($form['tanggal'] === '') $errors[] = 'Tanggal wajib diisi.';
if ($form['vendor_id'] === '') $errors[] = 'Supplier wajib dipilih.';
if ($form['berat_basah'] === '' || !is_numeric($form['berat_basah'])) $errors[] = 'Berat Basah wajib diisi dengan angka.';
if ($form['harga_basah'] === '' || !is_numeric($form['harga_basah'])) $errors[] = 'Harga Basah wajib diisi dengan angka.';

$hargaNotaring = null;
if ($form['tanggal'] !== '') {
    $hpStmt = $pdo->prepare("SELECT harga FROM daily_prices WHERE tanggal = ? AND daerah = ?");
    $hpStmt->execute([$form['tanggal'], $form['daerah']]);
    $hargaNotaring = $hpStmt->fetchColumn();
    if (!$hargaNotaring) {
        $errors[] = 'Harga Harian (notaring/kering) untuk tanggal ' . $form['tanggal'] . ' belum ditetapkan oleh Petugas. Hubungi Petugas, lalu coba sinkronkan lagi.';
    }
}

if ($errors) {
    json_response(['success' => false, 'message' => implode(' ', $errors)], 422);
}

$fotoName = null;
// v12: antrian offline di HP boleh mengirim beberapa berkas sekaligus (field fotos[]).
// Field "foto" versi lama tetap diterima, jadi HP yang antriannya dibuat sebelum
// update ini tetap terkirim tanpa foto hilang.
$upFoto = handle_photo_upload_multi(__DIR__ . '/../uploads');
if ($upFoto['files']) {
    $fotoName = array_shift($upFoto['files']);
}
$fotoTambahan = $upFoto['files'];
$fotoPeringatan = $upFoto['errors'];
if (!$fotoName && $fotoPeringatan) {
    json_response(['success' => false, 'message' => implode(' ', $fotoPeringatan)], 422);
}

$drc = calculate_drc($form['harga_basah'], $hargaNotaring);
$pajak = ($form['punya_npwp'] === '1') ? 0.25 : 0.50;
$totalSetelahPajak = round(((float)$form['berat_basah'] * (float)$form['harga_basah']) * (1 - $pajak / 100), 2);
$noTicket = generate_no_ticket($pdo);
$noNota = generate_no_nota($pdo);
$picId = $user['role'] === 'admin' ? ($_POST['pic_id'] ?? $user['id']) : $user['id'];

try {
    $stmt = $pdo->prepare("INSERT INTO purchases
        (no_ticket, client_uuid, no_nota, tanggal, daerah, pic_id, vendor_id, berat_basah, harga_basah, harga_notaring, drc, foto, status_approval, status_pembayaran)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'menunggu', 'belum_diajukan')");
    $stmt->execute([
        $noTicket, $clientUuid, $noNota, $form['tanggal'], $form['daerah'], $picId, $form['vendor_id'],
        $form['berat_basah'], $form['harga_basah'], $hargaNotaring, $drc, $fotoName
    ]);
    // ID WAJIB diambil di sini, tepat setelah INSERT. pdo_mysql di PHP 8 mengembalikan
    // lastInsertId() dari PERNYATAAAN TERAKHIR, jadi kalau dibaca setelah UPDATE di
    // bawah nilainya 0 -> log_activity menabrak foreign key purchase_logs (HTTP 500).
    $newId = (int)$pdo->lastInsertId();
    $taxStmt = $pdo->prepare("UPDATE purchases SET punya_npwp=?, persentase_pajak=?, total_setelah_pajak=? WHERE id=?");
    $taxStmt->execute([(int)$form['punya_npwp'], $pajak, $totalSetelahPajak, $newId]);
} catch (PDOException $e) {
    // Kemungkinan besar client_uuid bentrok karena race condition sinkronisasi ganda
    if ($e->getCode() === '23000') {
        $existingStmt->execute([$clientUuid]);
        $existing = $existingStmt->fetch();
        if ($existing) {
            json_response(['success' => true, 'duplicate' => true, 'id' => $existing['id'], 'no_ticket' => $existing['no_ticket']]);
        }
    }
    json_response(['success' => false, 'message' => 'Gagal menyimpan data ke database.'], 500);
}

if ($fotoTambahan) {
    $simpanFoto = purchase_fotos_simpan($pdo, $newId, $fotoTambahan, $user['id'], __DIR__ . '/../uploads');
    if ($simpanFoto['pesan']) $fotoPeringatan[] = $simpanFoto['pesan'];
    $jumlahFoto = ($fotoName ? 1 : 0) + $simpanFoto['tersimpan'];
} else {
    $jumlahFoto = $fotoName ? 1 : 0;
}

log_activity($pdo, $newId, 'Dibuat', "Pembelian dibuat oleh " . $user['name'] . ' (via sinkronisasi offline)'
           . ($jumlahFoto > 0 ? ', Foto Bokar & Dokumen Pendukung: ' . $jumlahFoto . ' berkas' : ''));

notify_role(
    $pdo,
    ['petugas', 'admin'],
    "Pembelian baru {$noTicket} dari {$user['name']} menunggu approval.",
    '/pembelian/detail.php?id=' . $newId,
    $newId,
    'approval_menunggu',
    $user['id']
);
notify_role_wa(
    $pdo,
    ['petugas'],
    "Permisi Bapak/Ibu Petugas, mohon kesediaannya untuk memeriksa dan memberikan persetujuan atas pembelian baru {$noTicket} dari PIC {$user['name']}. Apabila data dan dokumen sudah sesuai, mohon kiranya dapat diproses. Terima kasih atas bantuan dan waktunya.",
    $newId
);

json_response([
    'success'          => true,
    'id'               => $newId,
    'no_ticket'        => $noTicket,
    'foto_tersimpan'   => $jumlahFoto,
    'foto_peringatan'  => $fotoPeringatan,   // ditampilkan HP sebagai catatan, tidak membatalkan data
]);
