<?php
// Endpoint JSON: dipakai oleh mekanisme auto-sync offline Petugas untuk
// menetapkan/memperbarui Harga Harian (notaring/kering) per tanggal.
require_once __DIR__ . '/../includes/init.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Metode tidak diizinkan.'], 405);
}

$user = api_auth($pdo);
if (!$user || !in_array($user['role'], ['admin', 'petugas'])) {
    json_response(['success' => false, 'message' => 'Sesi habis atau tidak diizinkan. Silakan login ulang di aplikasi.'], 401);
}

$tanggal = trim($_POST['tanggal'] ?? '');
$daerah = trim($_POST['daerah'] ?? 'Umum');
$harga = trim($_POST['harga'] ?? '');
$catatan = trim($_POST['catatan'] ?? '');

$errors = [];
if ($tanggal === '') $errors[] = 'Tanggal wajib diisi.';
if ($harga === '' || !is_numeric($harga) || $harga <= 0) $errors[] = 'Harga wajib diisi dengan angka lebih dari 0.';

if ($errors) {
    json_response(['success' => false, 'message' => implode(' ', $errors)], 422);
}

// Upsert berdasarkan tanggal (tanggal = kunci unik alami, tidak perlu client_uuid)
$checkStmt = $pdo->prepare("SELECT id FROM daily_prices WHERE tanggal = ? AND daerah = ?");
$checkStmt->execute([$tanggal, $daerah]);
$row = $checkStmt->fetch();

if ($row) {
    $upd = $pdo->prepare("UPDATE daily_prices SET daerah=?, harga=?, catatan=?, set_by=? WHERE id=?");
    $upd->execute([$daerah, $harga, $catatan ?: null, $user['id'], $row['id']]);
    $id = $row['id'];
} else {
    $ins = $pdo->prepare("INSERT INTO daily_prices (tanggal, daerah, harga, catatan, set_by) VALUES (?, ?, ?, ?, ?)");
    $ins->execute([$tanggal, $daerah, $harga, $catatan ?: null, $user['id']]);
    $id = $pdo->lastInsertId();
}

json_response(['success' => true, 'id' => $id, 'tanggal' => $tanggal, 'daerah' => $daerah, 'harga' => $harga]);
