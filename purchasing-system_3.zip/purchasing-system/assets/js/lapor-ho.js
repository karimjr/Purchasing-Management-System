/**
 * Tombol "Lapor ke HO (Email)"
 * -------------------------------------------------------------
 * HP / tablet  : mailto: -> aplikasi email HP terbuka (perilaku awal, terbukti jalan)
 * Laptop       : tidak ada cara resmi untuk "memaksa" aplikasi New Outlook terbuka dari
 *                halaman web, jadi dicoba berurutan sampai ketemu yang jalan, lalu
 *                pemenangnya diingat di perangkat itu (localStorage):
 *                  1) ms-outlook://compose?to=&subject=&body=   (aplikasi New Outlook / olk.exe)
 *                  2) mailto:                                   (aplikasi email default Windows)
 *                  3) https://outlook.office.com/mail/deeplink/compose?...  (Outlook di browser)
 *                Semua tombol tetap <a href="mailto:..."> sehingga tanpa JavaScript pun
 *                cara lama masih bekerja.
 * Cadangan apa pun perangkat: berkas .eml (klik 2x -> Outlook) dan salin-tempel.
 */
(function () {
  'use strict';

  var nav = (typeof navigator !== 'undefined' && navigator) ? navigator : {};
  var KUNCI_ALAT = 'hoPerangkat';   // 'laptop' | 'hp'   (koreksi manual oleh pemakai)
  var KUNCI_RUTE = 'hoRuteLaptop'; // 'msoutlook' | 'mailto' | 'web' (hasil percobaan pertama)

  function simpan(kunci, nilai) {
    try {
      if (window.localStorage) {
        if (nilai) window.localStorage.setItem(kunci, nilai);
        else window.localStorage.removeItem(kunci);
      }
    } catch (e) {}
  }
  function baca(kunci) {
    try { return (window.localStorage && window.localStorage.getItem(kunci)) || ''; } catch (e) { return ''; }
  }

  // "saya pakai laptop / HP" di panel cadangan
  window.hoPilihPerangkat = function (jenis) {
    simpan(KUNCI_ALAT, (jenis === 'laptop' || jenis === 'hp') ? jenis : '');
    var btn = document.querySelector('[data-rute]');
    if (btn) return window.hoLapor(btn);
    try { window.location.reload(); } catch (e) {}
    return false;
  };

  // "lupakan cara yang berhasil tadi" -> cascade diulang dari awal
  window.hoLupaRute = function () {
    simpan(KUNCI_RUTE, '');
    simpan(KUNCI_ALAT, '');
    try { window.location.reload(); } catch (e) {}
    return false;
  };

  function adalahAplikasiTerpasang() {
    if (/; wv\)/.test(nav.userAgent || '')) return true;              // Android TWA/APK
    if (nav.standalone === true) return true;                          // iOS Add to Home Screen
    try {
      if (window.matchMedia) {
        if (window.matchMedia('(display-mode: standalone)').matches) return true;
        if (window.matchMedia('(display-mode: window-controls-overlay)').matches) return true;
      }
    } catch (e) {}
    return false;
  }

  function adalahWindows() { return /Windows NT|Windows 10|Windows 11/i.test(nav.userAgent || ''); }

  function adalahLaptop() {
    var pilih = baca(KUNCI_ALAT);
    if (pilih === 'laptop') return true;
    if (pilih === 'hp') return false;

    var ua = nav.userAgent || '';
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua)) return false;
    if (/Macintosh/.test(ua) && (nav.maxTouchPoints || 0) > 1) return false;  // iPadOS menyamar
    if (!/Windows NT|Mac OS X|X11|Linux|CrOS/i.test(ua)) return false;
    try {
      if (window.matchMedia && window.matchMedia('(pointer: coarse)').matches) return false;
    } catch (e) {}
    return true;
  }

  function panelUntuk(btn) {
    var id = btn.getAttribute('data-panel');
    return id ? document.getElementById(id) : null;
  }

  function catatDiklik(btn) {
    var ping = btn.getAttribute('data-ping');
    if (!ping) return;
    try {
      fetch(ping, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'id=' + encodeURIComponent(btn.getAttribute('data-id') || ''),
        keepalive: true
      });
    } catch (e) { /* pencatatan bukan hal yang boleh menggagalkan email */ }
  }

  // Halaman masih tampak & masih memegang fokus = tidak ada jendela/aplikasi
  // yang terbuka menggantikan browser.
  function masihDilihat() {
    try {
      if (document.hidden) return false;
      if (document.hasFocus && !document.hasFocus()) return false;
    } catch (e) {}
    return true;
  }

  function buka(url, bolehNavigasi) {
    var w = null;
    try { w = window.open(url, '_blank'); } catch (e) { w = null; }
    if (!w && bolehNavigasi) {
      try { window.location.href = url; } catch (e) {}
      return true;
    }
    return !!w;
  }

  // Protokol custom (mailto:, ms-outlook:) harus lewat navigasi jendela ini:
  // lewat window.open sebagian browser membuat tab kosong lalu membuang tautannya.
  function lempar(url, bolehNavigasi, pakaiTab) {
    // pakaiTab = benar di dalam PWA/APK: jendela ini tidak boleh dipakai untuk
    // protokol custom (wrapper menelannya), jadi semuanya dilempar ke tab baru
    if (pakaiTab) return buka(url, true);
    if (/^(mailto:|ms-outlook:)/i.test(url)) {
      try { window.location.href = url; return true; } catch (e) { return false; }
    }
    return buka(url, bolehNavigasi);
  }

  // Semua kandidat cara yang tersedia di tombol ini
  function urlRute(nama, mailto, web, ms) {
    if (nama === 'mailto') return mailto;
    if (nama === 'web') return web;
    if (nama === 'msoutlook') return ms;
    if (nama === 'msoutlook2') return ms ? ms.replace('ms-outlook://', 'ms-outlook:') : '';
    return '';
  }

  function daftarRute(ms, mailto, web, windowsOnly) {
    var urut = [];
    if (ms && (windowsOnly === false || adalahWindows())) { urut.push('msoutlook'); urut.push('msoutlook2'); }
    if (mailto) urut.push('mailto');
    if (web) urut.push('web');
    return urut;
  }

  function tampilkanPanel(panel, mailto, web, msoutlook, sebab) {
    if (!panel) {
      window.alert(
        'Aplikasi email tidak terbuka dari tampilan ini.\n\n' +
        'Caranya:\n' +
        '1) Buka aplikasi ini lewat browser biasa (Chrome/Edge), bukan lewat ikon aplikasi di HP,\n' +
        '2) lalu klik tombol "Lapor ke HO" lagi; ATAU\n' +
        '3) pakai tombol "Unduh file .eml" di sebelahnya - file itu terbuka di Outlook ' +
        'dengan email siap dikirim.\n\n' +
        'Alternatif: klik "Salin isi email" lalu tempel (Ctrl+V) di jendela email baru.'
      );
      return;
    }
    panel.classList.remove('d-none');
    var isian = [
      ['[data-role="buka-manual"]', mailto],
      ['[data-role="buka-outlook"]', web || msoutlook],
      ['[data-role="buka-msoutlook"]', msoutlook]
    ];
    for (var i = 0; i < isian.length; i++) {
      var el = null;
      try { el = panel.querySelector(isian[i][0]); } catch (e) { el = null; }
      if (el && isian[i][1]) el.setAttribute('href', isian[i][1]);
    }
    var ket = null;
    try { ket = panel.querySelector('[data-role="sebab"]'); } catch (e) {}
    if (ket && sebab) ket.textContent = sebab;
    try { panel.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) {}
  }

  var NAMA_RUTE = {
    msoutlook: 'aplikasi Outlook (new) - ms-outlook://compose',
    msoutlook2: 'aplikasi Outlook (new) - ms-outlook:compose',
    mailto: 'email bawaan Windows (mailto:)',
    web: 'Outlook di browser'
  };

  /**
   * Coba daftar cara satu per satu. Setelah tiap percobaan ditunggu 1,4 detik:
   * kalau browser kehilangan fokus/tabnya tertutup -> dianggap berhasil dan
   * cara itu diingat; kalau tidak, pemakai ditanya.
   */
  function cobaBersama(urut, index, panel, mailto, web, msoutlook, pesanHabis, pakaiTab) {
    if (index >= urut.length) {
      simpan(KUNCI_RUTE, '');
      tampilkanPanel(panel, mailto, web, msoutlook, pesanHabis ||
        'Belum ada cara yang membuka Outlook. Pakai tombol "Buka Outlook di browser" / "Unduh berkas .eml" di bawah, ' +
        'atau atur New Outlook sebagai aplikasi email default (tautan pengaturan ada di bawah).');
      return;
    }
    var nama = urut[index], url = urlRute(nama, mailto, web, msoutlook);
    if (!url) { cobaBersama(urut, index + 1, panel, mailto, web, msoutlook, cukupSendiri, pakaiTab); return; }
    lempar(url, true, pakaiTab);

    window.setTimeout(function () {
      if (!masihDilihat()) { simpan(KUNCI_RUTE, nama); return; }   // ada yang terbuka -> selesai
      var tanya = 'Cara "' + NAMA_RUTE[nama] + '" membuka Outlook dengan email terisi?\n\n' +
        'OK       = sudah terbuka, cara ini dipakai terus di komputer ini\n' +
        'Batalkan = belum, coba cara berikutnya';
      var ya = true;
      try { ya = window.confirm(tanya); } catch (e) { ya = true; }
      if (ya) { simpan(KUNCI_RUTE, nama); return; }
      cobaBersama(urut, index + 1, panel, mailto, web, msoutlook, pesanHabis, pakaiTab);
    }, 1400);
  }

  /**
   * Klik tombol utama.
   * rute: 'auto' (bawaan) | 'outlook' | 'web' | 'mailto' | 'pilih'
   */
  window.hoLapor = function (btn) {
    var mailto = btn.getAttribute('data-mailto') || btn.getAttribute('href') || '';
    var web = btn.getAttribute('data-web') || '';
    var msoutlook = btn.getAttribute('data-msoutlook') || '';
    var rute = btn.getAttribute('data-rute') || 'mailto';
    var panel = panelUntuk(btn);
    var aplikasi = adalahAplikasiTerpasang();
    var laptop = adalahLaptop();

    catatDiklik(btn);

    // ---------- LAPTOP (browser biasa atau PWA yang di-install) ----------
    if (laptop) {
      var menang = baca(KUNCI_RUTE);
      var urlMenang = urlRute(menang, mailto, web, msoutlook);
      if (urlMenang) { lempar(urlMenang, menang === 'web', aplikasi); return false; }

      if (rute === 'mailto' || (!web && !msoutlook)) {
        if (aplikasi) { buka(mailto, true); } else { window.location.href = mailto; }
        return false;
      }
      if (rute === 'web' && web) { lempar(web, true, aplikasi); return false; }
      if (rute === 'outlook' && msoutlook) {
        // hanya New Outlook: dua varian ms-outlook, tidak turun ke mailto/browser
        cobaBersama(['msoutlook', 'msoutlook2'], 0, panel, mailto, web, msoutlook,
          'Aplikasi New Outlook tidak menjawab tautan ms-outlook:// (kedua bentuknya). Cara lain masih ada di bawah ' +
          '("Buka Outlook di browser", "Unduh berkas .eml"), atau minta Admin memilih rute lain di ' +
          'Pengaturan Email Laporan; untuk mengulang pemilihan cara: tautan "Ulangi pemilihan cara".', aplikasi);
        return false;
      }
      if (rute === 'pilih' && panel) {
        tampilkanPanel(panel, mailto, web, msoutlook, 'Pilih salah satu cara di bawah ini.');
        return false;
      }

      // 'auto': New Outlook (khusus Windows) -> mailto -> Outlook di browser
      var urut = daftarRute(msoutlook, mailto, web, true);
      if (urut.length) { cobaBersama(urut, 0, panel, mailto, web, msoutlook, false, aplikasi); return false; }

      window.location.href = mailto;
      return false;
    }

    // ---------- PWA / APK di HP: lempar ke tab baru, mailto tidak ditelan wrapper ----------
    if (aplikasi) {
      var dibuka = buka(mailto, true);
      var timer = window.setTimeout(function () {
        if (dibuka && !masihDilihat()) return;
        tampilkanPanel(panel, mailto, web, msoutlook,
          dibuka ? '' : 'Tampilan aplikasi (PWA/APK) tidak membuka email sendiri.');
      }, 1600);
      var batal = function () { window.clearTimeout(timer); };
      try {
        window.addEventListener('blur', batal, { once: true });
        document.addEventListener('visibilitychange', function sekali() {
          if (document.hidden) { batal(); document.removeEventListener('visibilitychange', sekali); }
        });
      } catch (e) {}
      return false;
    }

    // ---------- HP di browser biasa: mailto, seperti semula ----------
    window.location.href = mailto;
    var timer2 = window.setTimeout(function () {
      if (!masihDilihat()) return;
      tampilkanPanel(panel, mailto, web, msoutlook, '');
    }, 1600);
    var batal2 = function () { window.clearTimeout(timer2); };
    try {
      window.addEventListener('blur', batal2, { once: true });
      document.addEventListener('visibilitychange', function sekali2() {
        if (document.hidden) { batal2(); document.removeEventListener('visibilitychange', sekali2); }
      });
    } catch (e) {}
    return false;
  };

  // Dipakai tombol "Kirim lewat server" (kalau Admin mengaktifkan mode itu)
  window.hoKirim = function (btn) {
    var url = btn.getAttribute('data-kirim');
    var id = btn.getAttribute('data-id');
    var panel = panelUntuk(btn);
    var asli = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mengirim...';

    fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'id=' + encodeURIComponent(id)
    })
      .then(function (r) { return r.json().catch(function () { return { ok: false, error: 'Balasan server tidak terbaca (HTTP ' + r.status + ').' }; }); })
      .then(function (res) {
        btn.disabled = false;
        btn.innerHTML = asli;
        var ok = !!(res && res.ok);
        if (ok) {
          btn.classList.remove('btn-primary', 'btn-brand');
          btn.classList.add('btn-success');
          btn.innerHTML = '<i class="bi bi-check2-circle"></i> ' + (res.pesan || 'Terkirim ke HO');
          if (panel) {
            var t = panel.querySelector('[data-role="hasil-server"]');
            if (t) { t.textContent = 'Email laporan sudah terkirim dari server ke ' + (res.kepada || 'HO') + '.'; panel.classList.remove('d-none'); }
          }
        } else {
          var pesan = (res && res.error) ? res.error : 'Pengiriman gagal.';
          window.alert('Email TIDAK terkirim dari server:\n\n' + pesan +
                       '\n\nPakai cara cadangan: tombol "Unduh file .eml" (terbuka di Outlook, tinggal Kirim) ' +
                       'atau "Salin isi email" lalu tempel di jendela email baru.');
          if (panel) panel.classList.remove('d-none');
        }
      })
      .catch(function (err) {
        btn.disabled = false;
        btn.innerHTML = asli;
        window.alert('Tidak bisa menghubungi server (' + err + '). Pakai tombol "Unduh file .eml" atau "Salin isi email".');
        if (panel) panel.classList.remove('d-none');
      });
    return false;
  };

  // Dipakai tombol "Salin isi email"
  window.hoSalin = function (idElemen) {
    var el = document.getElementById(idElemen);
    if (!el) return;
    var teks = el.innerText || el.textContent || '';
    var selesai = function () {
      window.alert('Isi email tersalin. Tempel (Ctrl+V) di jendela email baru untuk Pak Arnold.');
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(teks).then(selesai, function () { hoCaraLama(teks, selesai); });
      return;
    }
    hoCaraLama(teks, selesai);
  };

  function hoCaraLama(teks, selesai) {
    var ta = document.createElement('textarea');
    if (!ta || !ta.style) return;
    ta.value = teks;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); selesai(); }
    catch (e) { window.alert('Browser memblokir penyalinan otomatis - silakan blok tulisan email di atas, klik kanan, lalu Copy.'); }
    document.body.removeChild(ta);
  }
})();
