/**
 * Mobile Tables - Purchasing Management System
 * -----------------------------------------------------
 * Semua tabel data (daftar pembelian, approval, dsb) otomatis diubah jadi
 * tampilan kartu bertumpuk di layar HP, supaya tidak perlu geser ke samping
 * atau baca tulisan yang terlalu kecil. Di layar besar (laptop/tablet),
 * tabel tetap tampil normal seperti biasa.
 *
 * Caranya: label kolom (dari <thead>) disalin ke setiap sel <td> lewat
 * atribut data-label, lalu CSS di style.css yang mengatur tampilan
 * kartunya lewat class .table-mobile-cards.
 */
(function () {
  function enhanceTable(table) {
    if (table.dataset.mobileEnhanced === '1') return;
    table.dataset.mobileEnhanced = '1';
    table.classList.add('table-mobile-cards');

    const headerCells = table.querySelectorAll('thead th');
    const labels = Array.from(headerCells).map((th) => th.textContent.trim());
    if (!labels.length) return;

    table.querySelectorAll('tbody tr').forEach((row) => {
      const cells = row.querySelectorAll('td');
      // Baris "belum ada data" (satu sel colspan) - jangan diberi label
      if (cells.length === 1 && cells[0].hasAttribute('colspan')) return;

      cells.forEach((cell, i) => {
        const label = labels[i] || '';
        if (label === '' || label === '\u00A0') {
          // Kolom tanpa judul (biasanya tombol aksi) -> pusatkan tanpa label
          cell.classList.add('mobile-action-cell');
        } else {
          cell.setAttribute('data-label', label);
        }
      });
    });
  }

  function run() {
    document.querySelectorAll('.table-responsive table, table.table').forEach(enhanceTable);
  }

  document.addEventListener('DOMContentLoaded', run);
  // Beberapa halaman memuat baris tabel lewat JS setelahnya (mis. hasil pencarian) -
  // beri sedikit jeda supaya tetap ke-enhance.
  window.addEventListener('load', run);
})();
