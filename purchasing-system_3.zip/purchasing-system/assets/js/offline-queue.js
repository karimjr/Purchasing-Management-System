/**
 * Offline Queue Engine - Purchasing Management System
 * -----------------------------------------------------
 * Dipakai di halaman Tambah Pembelian (PIC) dan Tetapkan Harga Harian
 * (Petugas) supaya data tetap bisa diisi & disimpan walau HP tidak ada
 * sinyal internet. Data yang disimpan offline akan otomatis dikirim ke
 * server begitu koneksi kembali tersedia.
 *
 * Cara kerja singkat:
 *  - Data (+ foto, untuk pembelian) disimpan dulu di IndexedDB (penyimpanan
 *    lokal di HP/browser)
 *  - Setiap ada koneksi lagi (event 'online', buka ulang halaman, atau tiap
 *    30 detik saat halaman terbuka), semua data yang masih "menunggu"
 *    otomatis dicoba dikirim ke server
 *  - Data referensi (supplier, harga harian) juga di-cache supaya PIC tetap
 *    bisa lihat harga terakhir walau offline, dan otomatis ter-refresh
 *    begitu online lagi (event 'offlinequeue:referencedata')
 */
(function (window) {
  const DB_NAME = 'purchasing_offline';
  const DB_VERSION = 1;
  const STORE_PEMBELIAN = 'pending_pembelian';
  const STORE_HARGA = 'pending_harga_harian';
  const STORE_REF = 'reference_cache';

  function getBaseUrl() {
    const meta = document.querySelector('meta[name="app-base-url"]');
    return meta ? meta.content : '';
  }

  function getDeviceToken() {
    const match = document.cookie.match(/(?:^|; )device_token=([^;]*)/);
    return match ? decodeURIComponent(match[1]) : '';
  }

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_PEMBELIAN)) {
          db.createObjectStore(STORE_PEMBELIAN, { keyPath: 'client_uuid' });
        }
        if (!db.objectStoreNames.contains(STORE_HARGA)) {
          db.createObjectStore(STORE_HARGA, { keyPath: 'tanggal' });
        }
        if (!db.objectStoreNames.contains(STORE_REF)) {
          db.createObjectStore(STORE_REF, { keyPath: 'key' });
        }
      };
      req.onsuccess = (e) => resolve(e.target.result);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  async function withStore(storeName, mode, fn) {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      const result = fn(store);
      tx.oncomplete = () => resolve(result);
      tx.onerror = (e) => reject(e.target.error);
    });
  }

  function reqToPromise(req) {
    return new Promise((resolve, reject) => {
      req.onsuccess = () => resolve(req.result);
      req.onerror = (e) => reject(e.target.error);
    });
  }

  function emit(name, detail) {
    window.dispatchEvent(new CustomEvent(name, { detail }));
  }

  // =========================================================
  // Data referensi (supplier + harga harian) - dipakai PIC untuk lihat/validasi
  // harga terbaru, termasuk saat offline.
  // =========================================================
  async function cacheReferenceData(data) {
    return withStore(STORE_REF, 'readwrite', (store) => {
      store.put({ key: 'data', value: data, cached_at: Date.now() });
    });
  }

  async function getReferenceData() {
    const db = await openDB();
    const tx = db.transaction(STORE_REF, 'readonly');
    const store = tx.objectStore(STORE_REF);
    const result = await reqToPromise(store.get('data'));
    return result ? result.value : null;
  }

  async function refreshReferenceData() {
    try {
      const res = await fetch(getBaseUrl() + '/api/reference_data.php', {
        credentials: 'same-origin',
        headers: { 'X-Device-Token': getDeviceToken() },
      });
      const json = await res.json();
      if (json.success) {
        await cacheReferenceData(json);
        emit('offlinequeue:referencedata', json);
        return json;
      }
    } catch (err) {
      // offline atau gagal fetch - biarkan, nanti pakai cache lama
    }
    return getReferenceData();
  }

  // =========================================================
  // Antrian: Pembelian (PIC)
  // =========================================================
  async function enqueuePembelian(record) {
    record.status = 'pending';
    record.created_at = Date.now();
    return withStore(STORE_PEMBELIAN, 'readwrite', (store) => {
      store.put(record);
    });
  }

  async function getAllPendingPembelian() {
    const db = await openDB();
    const tx = db.transaction(STORE_PEMBELIAN, 'readonly');
    const store = tx.objectStore(STORE_PEMBELIAN);
    const daftar = (await reqToPromise(store.getAll())) || [];
    // Safari/iOS bisa membersihkan penyimpanan situs yang lama tidak dibuka (praktisnya
    // sekitar 7 hari), jadi antrian yang menganggur lama ikut hilang tanpa pemberitahuan.
    // Umurnya dihitung di sini supaya halaman bisa mengingatkan sebelum keduluan.
    daftar.forEach(function (item) {
      item.usia_hari = item.created_at ? Math.floor((Date.now() - item.created_at) / 86400000) : 0;
    });
    return daftar;
  }

  async function updatePembelianRecord(clientUuid, patch) {
    return withStore(STORE_PEMBELIAN, 'readwrite', async (store) => {
      const existing = await reqToPromise(store.get(clientUuid));
      if (existing) { Object.assign(existing, patch); store.put(existing); }
    });
  }

  async function removePembelianRecord(clientUuid) {
    return withStore(STORE_PEMBELIAN, 'readwrite', (store) => store.delete(clientUuid));
  }

  async function syncPembelian(onProgress) {
    let synced = 0, failed = 0, authError = false;
    const items = await getAllPendingPembelian();
    for (const item of items) {
      if (item.status === 'synced') continue;
      await updatePembelianRecord(item.client_uuid, { status: 'syncing' });
      if (onProgress) onProgress('pembelian', item, 'syncing');
      try {
        const fd = new FormData();
        fd.append('client_uuid', item.client_uuid);
        fd.append('tanggal', item.tanggal);
        fd.append('vendor_id', item.vendor_id);
        fd.append('daerah', item.daerah || 'Umum');
        fd.append('punya_npwp', item.punya_npwp || '0');
        fd.append('berat_basah', item.berat_basah);
        fd.append('harga_basah', item.harga_basah);
        // Berkas: versi lama cuma punya foto_blob (1 berkas, field "foto").
        // v12 menyimpan juga sisa berkas di fotos_blobs -> semuanya dikirim lewat
        // field fotos[] supaya urutan "foto utama + dokumen pendukung" sama seperti
        // saat PIC memilihnya di HP.
        const kiriman = [];
        if (item.foto_blob) kiriman.push({ blob: item.foto_blob, name: item.foto_name || 'foto.jpg' });
        (item.fotos_blobs || []).forEach(function (b, i) {
          if (b) kiriman.push({ blob: b, name: (item.fotos_names && item.fotos_names[i]) || ('dokumen-' + (i + 2) + '.jpg') });
        });
        if (kiriman.length > 1) {
          kiriman.forEach(function (k) { fd.append('fotos[]', k.blob, k.name); });
        } else if (kiriman.length === 1) {
          fd.append('foto', kiriman[0].blob, kiriman[0].name);
        }

        const res = await fetch(getBaseUrl() + '/api/pembelian_create.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'X-Device-Token': getDeviceToken() }, body: fd,
        });
        const json = await res.json();

        if (json.success) {
          if (json.foto_peringatan && json.foto_peringatan.length) {
            console.warn('Sebagian foto dokumen tidak tersimpan:', json.foto_peringatan);
          }
          await removePembelianRecord(item.client_uuid);
          synced++;
          if (onProgress) onProgress('pembelian', item, 'synced', json);
        } else if (res.status === 401) {
          await updatePembelianRecord(item.client_uuid, { status: 'pending', error_message: json.message });
          failed++; authError = true;
          if (onProgress) onProgress('pembelian', item, 'auth_error', json);
          break;
        } else {
          await updatePembelianRecord(item.client_uuid, { status: 'error', error_message: json.message || 'Gagal sinkronisasi.' });
          failed++;
          if (onProgress) onProgress('pembelian', item, 'error', json);
        }
      } catch (err) {
        await updatePembelianRecord(item.client_uuid, { status: 'pending' });
        failed++;
        if (onProgress) onProgress('pembelian', item, 'network_error');
        break;
      }
    }
    return { synced, failed, authError };
  }

  // =========================================================
  // Antrian: Harga Harian (Petugas). Kunci = tanggal (upsert, tidak perlu uuid)
  // =========================================================
  async function enqueueHargaHarian(record) {
    record.status = 'pending';
    record.created_at = Date.now();
    return withStore(STORE_HARGA, 'readwrite', (store) => {
      store.put(record);
    });
  }

  async function getAllPendingHargaHarian() {
    const db = await openDB();
    const tx = db.transaction(STORE_HARGA, 'readonly');
    const store = tx.objectStore(STORE_HARGA);
    return (await reqToPromise(store.getAll())) || [];
  }

  async function updateHargaHarianRecord(tanggal, patch) {
    return withStore(STORE_HARGA, 'readwrite', async (store) => {
      const existing = await reqToPromise(store.get(tanggal));
      if (existing) { Object.assign(existing, patch); store.put(existing); }
    });
  }

  async function removeHargaHarianRecord(tanggal) {
    return withStore(STORE_HARGA, 'readwrite', (store) => store.delete(tanggal));
  }

  async function syncHargaHarian(onProgress) {
    let synced = 0, failed = 0, authError = false;
    const items = await getAllPendingHargaHarian();
    for (const item of items) {
      if (item.status === 'synced') continue;
      await updateHargaHarianRecord(item.tanggal, { status: 'syncing' });
      if (onProgress) onProgress('harga_harian', item, 'syncing');
      try {
        const fd = new FormData();
        fd.append('tanggal', item.tanggal);
        fd.append('daerah', item.daerah || 'Umum');
        fd.append('harga', item.harga);
        fd.append('catatan', item.catatan || '');

        const res = await fetch(getBaseUrl() + '/api/harga_harian_create.php', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'X-Device-Token': getDeviceToken() }, body: fd,
        });
        const json = await res.json();

        if (json.success) {
          await removeHargaHarianRecord(item.tanggal);
          synced++;
          if (onProgress) onProgress('harga_harian', item, 'synced', json);
        } else if (res.status === 401) {
          await updateHargaHarianRecord(item.tanggal, { status: 'pending', error_message: json.message });
          failed++; authError = true;
          if (onProgress) onProgress('harga_harian', item, 'auth_error', json);
          break;
        } else {
          await updateHargaHarianRecord(item.tanggal, { status: 'error', error_message: json.message || 'Gagal sinkronisasi.' });
          failed++;
          if (onProgress) onProgress('harga_harian', item, 'error', json);
        }
      } catch (err) {
        await updateHargaHarianRecord(item.tanggal, { status: 'pending' });
        failed++;
        if (onProgress) onProgress('harga_harian', item, 'network_error');
        break;
      }
    }
    return { synced, failed, authError };
  }

  // =========================================================
  // Sync gabungan
  // =========================================================
  let syncing = false;
  async function syncAll(onProgress) {
    if (syncing) return { synced: 0, failed: 0 };
    if (!navigator.onLine) return { synced: 0, failed: 0, offline: true };
    syncing = true;
    let result = { synced: 0, failed: 0, authError: false };
    try {
      const r1 = await syncPembelian(onProgress);
      const r2 = await syncHargaHarian(onProgress);
      result = {
        synced: r1.synced + r2.synced,
        failed: r1.failed + r2.failed,
        authError: r1.authError || r2.authError,
      };
      if (result.synced > 0) {
        await refreshReferenceData();
        emit('offlinequeue:synced', result);
      }
    } finally {
      syncing = false;
    }
    return result;
  }

  function uuid() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0, v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  window.OfflineQueue = {
    uuid,
    // pembelian
    enqueuePembelian,
    getAllPendingPembelian,
    updatePembelianRecord,
    removePembelianRecord,
    // alias lama (kompatibilitas kalau ada cache halaman lama)
    enqueue: enqueuePembelian,
    getAllPending: getAllPendingPembelian,
    updateRecord: updatePembelianRecord,
    removeRecord: removePembelianRecord,
    // harga harian
    enqueueHargaHarian,
    getAllPendingHargaHarian,
    updateHargaHarianRecord,
    removeHargaHarianRecord,
    // referensi & sync
    syncAll,
    cacheReferenceData,
    getReferenceData,
    refreshReferenceData,
  };

  // Auto-sync saat koneksi kembali, saat halaman dibuka, dan tiap 30 detik
  window.addEventListener('online', () => window.OfflineQueue.syncAll());
  document.addEventListener('DOMContentLoaded', () => {
    window.OfflineQueue.refreshReferenceData();
    window.OfflineQueue.syncAll();
  });
  setInterval(() => window.OfflineQueue.syncAll(), 30000);
})(window);
