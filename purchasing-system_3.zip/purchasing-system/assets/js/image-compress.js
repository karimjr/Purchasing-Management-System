/**
 * Image Compress - Purchasing Management System
 * -----------------------------------------------------
 * Foto dari kamera HP sering berukuran besar (4-8MB+), sementara hosting
 * biasanya cuma izinkan upload 2MB (php.ini: upload_max_filesize) -> gagal
 * dengan "kode error 1". Supaya tidak tergantung setting hosting, foto
 * dikompres dulu di HP (diperkecil dimensinya + dipadatkan kualitasnya)
 * SEBELUM dikirim, baik untuk submit normal maupun disimpan ke antrian
 * offline.
 */
(function (window) {
  function compressImage(file, maxDimension, quality) {
    maxDimension = maxDimension || 1600;
    quality = quality || 0.75;

    return new Promise((resolve, reject) => {
      if (!file || !file.type || !file.type.startsWith('image/')) {
        resolve(file); // bukan gambar (jarang terjadi karena input accept="image/*") - biarkan apa adanya
        return;
      }
      // HEIC/HEIF dari iPhone tidak bisa dibaca <img>/canvas browser - biarkan lolos apa adanya,
      // server akan menolak dengan pesan format yang jelas kalau memang bermasalah.
      if (/heic|heif/i.test(file.type) || /\.(heic|heif)$/i.test(file.name || '')) {
        resolve(file);
        return;
      }

      const reader = new FileReader();
      reader.onerror = () => resolve(file); // gagal baca - fallback pakai file asli
      reader.onload = (e) => {
        const img = new Image();
        img.onerror = () => resolve(file); // gagal decode - fallback pakai file asli
        img.onload = () => {
          let { width, height } = img;
          if (width > maxDimension || height > maxDimension) {
            if (width > height) {
              height = Math.round(height * (maxDimension / width));
              width = maxDimension;
            } else {
              width = Math.round(width * (maxDimension / height));
              height = maxDimension;
            }
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx.drawImage(img, 0, 0, width, height);
          canvas.toBlob((blob) => {
            if (!blob) { resolve(file); return; }
            // Kalau hasil kompresnya malah lebih besar dari aslinya (jarang, file kecil), pakai yang asli
            if (blob.size >= file.size) { resolve(file); return; }
            const newName = (file.name || 'foto').replace(/\.[^.]+$/, '') + '.jpg';
            const compressedFile = new File([blob], newName, { type: 'image/jpeg', lastModified: Date.now() });
            resolve(compressedFile);
          }, 'image/jpeg', quality);
        };
        img.src = e.target.result;
      };
      reader.readAsDataURL(file);
    });
  }

  // Pasang otomatis ke sebuah <input type="file">: begitu user pilih foto,
  // langsung dikompres dan menggantikan isi input tersebut.
  // Sejak v12 input ini boleh berisi BANYAK berkas (field "Foto Bokar & Dokumen
  // Pendukung"), jadi semua berkas di dalam input diproses satu per satu - bukan
  // cuma berkas pertama. Callback lama (onDone untuk 1 berkas) tetap dipanggil
  // supaya halaman edit yang memakai satu foto tidak perlu diubah.
  // Sebagian browser (Safari/iOS versi lama dan beberapa WebView) menolak pengisian
  // ulang input[type=file] dari DataTransfer. Mengompres lalu gagal memasang hasilnya
  // sama dengan tidak mengompres sama sekali - dan user mengira fotonya sudah kecil.
  // Karena itu penggantian isi input SELALU diverifikasi, dan tiap unsur hasil
  // membawa flag `diterima` supaya halaman bisa memperingatkan pemakai.
  function pasangUlang(inputEl, dt, jumlah) {
    if (!dt || !jumlah) return false;
    try {
      inputEl.files = dt.files;
    } catch (err) {
      return false;   // beberapa browser melempar saat input.files diisi ulang
    }
    return !!(inputEl.files && inputEl.files.length === jumlah);
  }

  function attachAutoCompress(inputEl, opts) {
    if (!inputEl) return;
    inputEl.addEventListener('change', async function () {
      const awal = Array.from(inputEl.files || []);
      if (!awal.length) return;
      const hasil = [];
      const dt = window.DataTransfer ? new DataTransfer() : null;
      for (let i = 0; i < awal.length; i++) {
        const file = awal[i];
        const originalKB = Math.round(file.size / 1024);
        try {
          const compressed = (file.size < 300 * 1024)
            ? file                                  // sudah kecil: lewati canvas (hemat memori di iOS)
            : await compressImage(file, (opts && opts.maxDimension), (opts && opts.quality));
          if (dt) dt.items.add(compressed || file);
          hasil.push({ originalKB, finalKB: Math.round(((compressed || file).size) / 1024), file: compressed || file });
        } catch (err) {
          if (dt) dt.items.add(file);
          hasil.push({ originalKB, finalKB: originalKB, file: file, error: err });
        }
      }
      const diterima = (dt && hasil.length === awal.length) ? pasangUlang(inputEl, dt, awal.length) : false;
      hasil.forEach(function (r) {
        r.diterima = diterima;
        if (!diterima) { r.finalKB = r.originalKB; }  // yang tersisa di input tetap berkas asli
      });
      if (opts && typeof opts.onMany === 'function') opts.onMany(hasil, diterima);
      if (opts && typeof opts.onDone === 'function' && hasil.length === 1) {
        const tersimpan = inputEl.files[0] || awal[0];
        opts.onDone({
          originalKB: hasil[0].originalKB,
          finalKB: diterima ? Math.round(tersimpan.size / 1024) : hasil[0].originalKB,
          file: diterima ? tersimpan : awal[0],
          diterima: diterima,
          error: hasil[0].error,
        });
      }
    });
  }

  window.ImageCompress = { compressImage, attachAutoCompress };
})(window);
