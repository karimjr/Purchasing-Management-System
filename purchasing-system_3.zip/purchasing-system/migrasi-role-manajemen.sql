-- =========================================================
-- MIGRASI: ROLE BARU "MANAJEMEN" (view only)
-- =========================================================
-- Role manajemen untuk Arnold, Tomo, Dewi, Ayu, Martha:
--   BISA   : lihat Dashboard, Daftar Pembelian (tanpa tombol
--            tambah/edit), Harga Harian, Data Supplier,
--            Rekapitulasi, Rekap Beres, Notifikasi, Export.
--   TIDAK  : tambah/edit/hapus pembelian, approval, pembayaran
--            finance, voucher, atur harga, kelola supplier,
--            manajemen user/pengaturan, dan semua API tulis.
--
-- Cara pakai (phpMyAdmin):
--   1. Pilih database potensib_purchasing_db
--   2. Tab Import -> pilih file ini -> Go
--
-- Aman dijalankan berulang (idempotent).
-- =========================================================

-- 1) Tambah nilai 'manajemen' ke kolom enum role.
--    (Kalau sudah pernah dijalankan, perintah ini aman diulang.)
ALTER TABLE users
  MODIFY role enum('admin','petugas','pic','finance','dirops','manajemen') NOT NULL;

-- 2) Ubah 5 akun (yang tadinya dibuat role pic) menjadi manajemen.
UPDATE users
   SET role = 'manajemen'
 WHERE username IN ('arnold','tomo','dewi','ayu','martha')
   AND role = 'pic';

-- 3) Verifikasi (opsional):
SELECT id, name, username, role, is_active
  FROM users
 WHERE role = 'manajemen'
 ORDER BY id;
