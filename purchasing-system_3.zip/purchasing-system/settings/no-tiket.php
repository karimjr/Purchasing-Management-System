<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);
$pageTitle = 'Pengaturan No Tiket';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'simpan') {
        $mode = ($_POST['mode'] ?? 'lanjut') === 'harian' ? 'harian' : 'lanjut';
        $pola = trim($_POST['pola'] ?? '');
        if (!no_ticket_pola_valid($pola)) {
            set_flash('danger', 'Pola No Tiket tidak boleh kosong, wajib memuat {NNNN}, dan hanya boleh berisi huruf, angka, spasi, serta tanda - _ / . (maks. 60 karakter).');
        } else {
            set_app_setting($pdo, 'no_ticket_mode', $mode);
            set_app_setting($pdo, 'no_ticket_pola', $pola);
            set_flash('success', 'Pengaturan No Tiket disimpan. Contoh nomor berikutnya: ' . no_ticket_info($pdo)['contoh'] . '.');
        }
        redirect('/settings/no-tiket.php');
    }

    if ($action === 'set') {
        $nomor = (int)($_POST['nomor'] ?? 0);
        if ($nomor < 1) {
            set_flash('danger', 'Nomor berikutnya minimal 1.');
        } elseif (no_ticket_set_berikutnya($pdo, $nomor)) {
            set_flash('success', 'Nomor tiket berikutnya ditetapkan. Tiket baru akan bernomor ' . no_ticket_info($pdo)['contoh'] . '.');
        } else {
            set_flash('danger', 'Gagal menyimpan. Tabel number_sequences belum ada - jalankan migration_v14_nomor_otomatis.sql dulu.');
        }
        redirect('/settings/no-tiket.php');
    }

    if ($action === 'reset') {
        if (no_ticket_reset_counter($pdo)) {
            set_flash('success', 'Counter No Tiket direset. Tiket berikutnya akan bernomor ' . no_ticket_info($pdo)['contoh'] . '.');
        } else {
            set_flash('danger', 'Gagal reset. Tabel number_sequences belum ada - jalankan migration_v14_nomor_otomatis.sql dulu.');
        }
        redirect('/settings/no-tiket.php');
    }
}

$info  = no_ticket_info($pdo);
$dipakai = 0;
try {
    $dipakai = (int)$pdo->query("SELECT COUNT(*) FROM number_sequences")->fetchColumn();
} catch (Exception $e) {
    $dipakai = 0;
}
$terakhirTiket = $pdo->query("SELECT id, no_ticket, no_nota, tanggal, created_at FROM purchases ORDER BY id DESC LIMIT 8")->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-123"></i> Pengaturan No Tiket</h4>
<p class="text-muted small mt-n2">
  No Tiket dibuat otomatis oleh sistem. Dengan pengaturan <strong>Lanjut terus</strong>,
  angka di ujung nomor <strong>terus naik</strong> (0001, 0002, 0003, ...) dan tidak kembali
  ke 0001 walau berganti hari/bulan. Nomor bisa ditentukan ulang kapan saja oleh Admin.
</p>

<?php if (!$info['tersedia']): ?>
  <div class="alert alert-warning">
    <strong>Tabel <code>number_sequences</code> belum ada.</strong>
    Jalankan berkas <code>migration_v14_nomor_otomatis.sql</code> sekali di phpMyAdmin
    (database &rarr; tab SQL). Sebelum itu, aplikasi tetap jalan dengan cara lama
    (nomor terbesar hari itu + 1).
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Status Saat Ini</div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr>
            <td class="text-success fw-semibold" style="width:55%">Mode penomoran</td>
            <td class="fw-bold"><?= $info['mode'] === 'harian' ? 'Reset tiap hari' : 'Lanjut terus' ?></td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">Pola nomor</td>
            <td class="fw-bold"><code><?= e($info['pola']) ?></code></td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">Nomor terakhir dipakai</td>
            <td class="fs-5 fw-bold"><?= $info['terakhir'] > 0 ? str_pad((string)$info['terakhir'], 4, '0', STR_PAD_LEFT) : '-' ?></td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">Nomor berikutnya</td>
            <td class="fs-4 fw-bold text-success"><?= e($info['contoh']) ?></td>
          </tr>
        </table>
      </div>
    </div>

    <div class="card">
      <div class="card-header bg-white fw-bold">Tentukan / Reset Nomor</div>
      <div class="card-body">
        <form method="POST" class="mb-3">
          <input type="hidden" name="action" value="set">
          <label class="form-label">Nomor tiket berikutnya</label>
          <div class="input-group" style="max-width:280px">
            <input type="number" min="1" name="nomor" class="form-control" value="<?= (int)$info['berikutnya'] ?>">
            <button class="btn btn-brand"><i class="bi bi-check2"></i> Simpan</button>
          </div>
          <div class="form-text">
            Isi angka urut yang diinginkan (mis. <strong>1</strong> untuk memulai lagi dari
            <?= e(no_ticket_format($info['pola'], time(), 1)) ?>, atau <strong>100</strong> agar
            tiket berikutnya menjadi <?= e(no_ticket_format($info['pola'], time(), 100)) ?>).
            Nomor yang sudah terpakai otomatis dilewati.
          </div>
        </form>
        <form method="POST" onsubmit="return confirm('Yakin ingin mereset counter No Tiket? Tiket berikutnya akan mulai dari 1 lagi.');">
          <input type="hidden" name="action" value="reset">
          <button class="btn btn-outline-danger"><i class="bi bi-arrow-counterclockwise"></i> Reset ke 0 (mulai dari 1 lagi)</button>
        </form>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Pola &amp; Mode Penomoran</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="action" value="simpan">
          <div class="mb-3">
            <label class="form-label">Mode penomoran</label>
            <select name="mode" class="form-select" style="max-width:360px">
              <option value="lanjut" <?= $info['mode'] === 'lanjut' ? 'selected' : '' ?>>Lanjut terus (tidak reset sendiri)</option>
              <option value="harian" <?= $info['mode'] === 'harian' ? 'selected' : '' ?>>Reset tiap hari (mulai 1 lagi besok)</option>
            </select>
            <div class="form-text">Pilihan <strong>Lanjut terus</strong> yang disarankan: angka ujung nomor tidak akan berhenti di 0001.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">Pola No Tiket</label>
            <input type="text" name="pola" class="form-control" maxlength="60" value="<?= e($info['pola']) ?>" style="max-width:360px">
            <div class="form-text">
              Kode yang bisa dipakai: <code>{YYYYMMDD}</code> tanggal, <code>{YYYY}</code> tahun,
              <code>{MM}</code> bulan, <code>{DD}</code> hari, dan <code>{NNNN}</code> nomor urut
              (jumlah N = jumlah digit, mis. <code>{NNNNN}</code> = 5 digit).<br>
              Contoh: <code>Ranger-{NNNN}</code> &rarr; <?= e(no_ticket_format('Ranger-{NNNN}', time(), 5)) ?> &middot;
              <code>Ranger-{NNNNN}</code> &rarr; <?= e(no_ticket_format('Ranger-{NNNNN}', time(), 1234)) ?> &middot;
              <code>TCK-{YYYYMMDD}-{NNNN}</code> &rarr; <?= e(no_ticket_format('TCK-{YYYYMMDD}-{NNNN}', time(), 12)) ?> (pola lama)
            </div>
          </div>
          <button class="btn btn-brand"><i class="bi bi-save"></i> Simpan Pengaturan</button>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header bg-white fw-bold">8 Tiket Terakhir</div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-sm table-hover mb-0">
            <thead class="table-light"><tr><th>No Tiket</th><th>No Nota</th><th>Tanggal</th><th>Dibuat</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($terakhirTiket as $t): ?>
                <tr>
                  <td class="fw-semibold"><?= e($t['no_ticket']) ?></td>
                  <td><?= e($t['no_nota']) ?></td>
                  <td><?= e(format_tanggal($t['tanggal'])) ?></td>
                  <td class="text-muted small"><?= e(format_tanggal_waktu($t['created_at'])) ?></td>
                  <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= (int)$t['id'] ?>" target="_blank" rel="noopener">Lihat</a></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$terakhirTiket): ?><tr><td colspan="5" class="text-muted text-center py-3">Belum ada tiket.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-footer bg-white small text-muted">
        Nomor tiket yang sudah terbit bisa dikoreksi satu per satu lewat menu
        Edit Pembelian (hanya Admin, selama tiket belum diproses approval).
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
