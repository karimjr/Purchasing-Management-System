<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);
$user = current_user();
$pageTitle = 'Pengaturan WhatsApp';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';

    if ($action === 'save') {
        $enabled = isset($_POST['wa_enabled']) ? '1' : '0';
        $apiUrl = trim($_POST['wa_api_url'] ?? '');
        $apiToken = trim($_POST['wa_api_token'] ?? '');
        $senderName = trim($_POST['wa_sender_name'] ?? '');
        $reminderHours = (int)($_POST['wa_reminder_hours'] ?? 4);
        if ($reminderHours < 1) $reminderHours = 1;

        set_app_setting($pdo, 'wa_enabled', $enabled);
        set_app_setting($pdo, 'wa_api_url', $apiUrl);
        set_app_setting($pdo, 'wa_api_token', $apiToken);
        set_app_setting($pdo, 'wa_sender_name', $senderName);
        set_app_setting($pdo, 'wa_reminder_hours', (string)$reminderHours);

        set_flash('success', 'Pengaturan WhatsApp berhasil disimpan.');
        redirect('/settings/whatsapp.php');

    } elseif ($action === 'test') {
        $testPhone = trim($_POST['test_phone'] ?? '');
        $testMessage = trim($_POST['test_message'] ?? '') ?: 'Ini adalah pesan uji coba dari Purchasing System.';
        if ($testPhone === '') {
            set_flash('danger', 'Nomor WhatsApp tujuan uji coba wajib diisi.');
        } else {
            $ok = send_whatsapp($pdo, $testPhone, $testMessage);
            if ($ok) {
                set_flash('success', 'Pesan uji coba berhasil dikirim. Cek WhatsApp tujuan.');
            } else {
                set_flash('danger', 'Pesan uji coba GAGAL dikirim. Cek Log Pengiriman di bawah untuk detail responsnya, atau pastikan notifikasi WA sudah diaktifkan & API URL/Token sudah benar.');
            }
        }
        redirect('/settings/whatsapp.php');

    } elseif ($action === 'run_reminder') {
        $result = run_wa_reminders($pdo);
        set_flash('success', "Reminder dijalankan. Petugas: {$result['petugas']}, Dirops: {$result['dirops']}, Finance: {$result['finance']} pesan terkirim.");
        redirect('/settings/whatsapp.php');
    }
}

$settings = get_app_settings($pdo);
$waLogs = [];
try {
    $waLogs = $pdo->query("SELECT * FROM wa_logs ORDER BY created_at DESC LIMIT 20")->fetchAll();
} catch (Exception $e) {
    // tabel belum ada
}

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-whatsapp"></i> Pengaturan WhatsApp</h4>
<p class="text-muted small mt-n2">
  Atur gateway WhatsApp untuk mengirim notifikasi &amp; reminder approval otomatis ke Petugas, Dirops, Finance, dan PIC.
  Kompatibel dengan gateway WA gaya Fonnte/Wablas (kirim <code>target</code> &amp; <code>message</code>, header <code>Authorization: &lt;token&gt;</code>).
</p>

<div class="row g-4">
  <div class="col-lg-7">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Konfigurasi Gateway</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="action" value="save">
          <div class="form-check form-switch mb-3">
            <input type="checkbox" class="form-check-input" role="switch" id="waEnabled" name="wa_enabled" <?= ($settings['wa_enabled'] ?? '0') === '1' ? 'checked' : '' ?>>
            <label class="form-check-label" for="waEnabled">Aktifkan notifikasi WhatsApp</label>
          </div>
          <div class="mb-3">
            <label class="form-label">API URL Gateway</label>
            <input type="text" name="wa_api_url" class="form-control" value="<?= e($settings['wa_api_url'] ?? '') ?>" placeholder="https://api.fonnte.com/send">
            <div class="form-text">Untuk Fonnte gunakan <code>https://api.fonnte.com/send</code>. Untuk Wablas/gateway lain, sesuaikan dengan endpoint kirim pesan masing-masing.</div>
          </div>
          <div class="mb-3">
            <label class="form-label">API Token / Device Token</label>
            <input type="text" name="wa_api_token" class="form-control" value="<?= e($settings['wa_api_token'] ?? '') ?>" placeholder="Token dari dashboard gateway WA Anda">
          </div>
          <div class="mb-3">
            <label class="form-label">Nama Pengirim (opsional, ditampilkan di log)</label>
            <input type="text" name="wa_sender_name" class="form-control" value="<?= e($settings['wa_sender_name'] ?? '') ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Interval Reminder (jam)</label>
            <input type="number" min="1" name="wa_reminder_hours" class="form-control" style="max-width:150px" value="<?= e($settings['wa_reminder_hours'] ?? 4) ?>">
            <div class="form-text">Kalau sebuah tiket belum diproses sebanyak sekian jam sejak tahap sebelumnya selesai, sistem akan mengirim ulang reminder WA ke pihak yang belum bertindak (Petugas/Dirops/Finance).</div>
          </div>
          <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan Pengaturan</button>
        </form>
      </div>
    </div>

    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Kirim Pesan Uji Coba</div>
      <div class="card-body">
        <form method="POST" class="row g-3">
          <input type="hidden" name="action" value="test">
          <div class="col-md-5">
            <label class="form-label">No. WhatsApp Tujuan</label>
            <input type="text" name="test_phone" class="form-control" placeholder="08xxxxxxxxxx">
          </div>
          <div class="col-md-7">
            <label class="form-label">Pesan</label>
            <input type="text" name="test_message" class="form-control" placeholder="Ini adalah pesan uji coba dari Purchasing System.">
          </div>
          <div class="col-12">
            <button type="submit" class="btn btn-outline-success"><i class="bi bi-send"></i> Kirim Uji Coba</button>
          </div>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        <span>Reminder Manual</span>
        <form method="POST" class="mb-0">
          <input type="hidden" name="action" value="run_reminder">
          <button type="submit" class="btn btn-sm btn-outline-success"><i class="bi bi-bell"></i> Kirim Reminder Sekarang</button>
        </form>
      </div>
      <div class="card-body">
        <p class="text-muted small mb-0">
          Reminder otomatis idealnya dijadwalkan lewat <strong>Cron Job</strong> di hosting supaya berjalan sendiri
          (lihat file <code>cron/wa_reminder.php</code> &amp; petunjuk di README). Tombol di atas berguna untuk
          menjalankan pengecekan reminder secara manual/uji coba kapan saja tanpa menunggu jadwal cron.
        </p>
      </div>
    </div>
  </div>

  <div class="col-lg-5">
    <div class="card">
      <div class="card-header bg-white fw-bold">Log Pengiriman WhatsApp Terbaru</div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-sm mb-0 align-middle">
            <thead class="table-light">
              <tr><th>Waktu</th><th>No. HP</th><th>Status</th></tr>
            </thead>
            <tbody>
              <?php if (empty($waLogs)): ?>
                <tr><td colspan="3" class="text-center text-muted py-4">Belum ada log pengiriman.</td></tr>
              <?php else: foreach ($waLogs as $log): ?>
                <tr>
                  <td class="small"><?= format_tanggal_waktu($log['created_at']) ?></td>
                  <td class="small"><?= e($log['phone']) ?></td>
                  <td>
                    <?php
                      $badgeColor = ['sukses' => 'success', 'gagal' => 'danger', 'nonaktif' => 'secondary'][$log['status']] ?? 'secondary';
                    ?>
                    <span class="badge text-bg-<?= $badgeColor ?>" title="<?= e($log['response']) ?>"><?= e($log['status']) ?></span>
                  </td>
                </tr>
              <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
