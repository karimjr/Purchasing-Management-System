<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/voucher.php';
require_role(['admin']);
$pageTitle = 'Pengaturan No Voucher';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $bulan  = preg_replace('/[^0-9]/', '', $_POST['bulan'] ?? date('Ym'));
    if (strlen((string)$bulan) !== 6) $bulan = date('Ym');

    if ($action === 'set') {
        $nomor = (int)($_POST['nomor'] ?? 0);
        if ($nomor < 1) {
            set_flash('danger', 'Nomor voucher berikutnya minimal 1.');
        } elseif (voucher_set_berikutnya($pdo, $nomor, $bulan)) {
            set_flash('success', 'Nomor voucher berikutnya untuk bulan ini ditetapkan: ' . voucher_counter_info($pdo, $bulan)['contoh'] . '.');
        } else {
            set_flash('danger', 'Gagal menyimpan. Tabel number_sequences belum ada - jalankan migration_v14_nomor_otomatis.sql dulu.');
        }
        redirect('/settings/voucher.php?bulan=' . $bulan);
    }

    if ($action === 'reset') {
        if (voucher_reset_counter($pdo, $bulan)) {
            set_flash('success', 'Counter voucher direset. Nomor berikutnya: ' . voucher_counter_info($pdo, $bulan)['contoh'] . '. (Nomor yang sudah terpakai otomatis dilewati.)');
        } else {
            set_flash('danger', 'Gagal reset. Tabel number_sequences belum ada - jalankan migration_v14_nomor_otomatis.sql dulu.');
        }
        redirect('/settings/voucher.php?bulan=' . $bulan);
    }
}

$tersedia = voucher_tersedia($pdo);
$bulan    = preg_replace('/[^0-9]/', '', $_GET['bulan'] ?? date('Ym'));
if (strlen((string)$bulan) !== 6) $bulan = date('Ym');
$info     = voucher_counter_info($pdo, $bulan);

$daftarVoucher = [];
if ($tersedia) {
    $stmt = $pdo->prepare("SELECT pv.id, pv.voucher_no, pv.voucher_date, pv.total_bersih, p.no_ticket, v.name AS vendor_name
                           FROM payment_vouchers pv
                           JOIN purchases p ON p.id = pv.purchase_id
                           JOIN vendors v ON v.id = p.vendor_id
                           WHERE pv.voucher_no LIKE ?
                           ORDER BY pv.id DESC LIMIT 10");
    $stmt->execute([VOUCHER_PREFIX . '-' . $bulan . '-%']);
    $daftarVoucher = $stmt->fetchAll();
}

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-receipt"></i> Pengaturan No Voucher</h4>
<p class="text-muted small mt-n2">
  No Voucher dibuat <strong>otomatis</strong> saat Finance/Admin menekan
  <em>Buat Voucher</em>. Formatnya <code>PV-BULANTAHUN-NOMOR</code> dan
  <strong>angkanya mengikuti nomor tiket</strong> &mdash; tiket
  <code>Ranger-0005</code> otomatis menjadi voucher
  <code>PV-<?= date('Ym') ?>-0005</code>, jadi No Tiket dan No Voucher selalu sejajar.
  Halaman ini hanya untuk melihat / mengoreksi counter cadangan apabila ada
  penomoran yang perlu dirapikan.
</p>

<?php if (!$tersedia): ?>
  <div class="alert alert-warning">
    <strong>Tabel voucher belum ada.</strong> Jalankan <code>migration_v13_voucher.sql</code>
    sekali di phpMyAdmin dulu.
  </div>
<?php endif; ?>
<?php if (!$info['tersedia']): ?>
  <div class="alert alert-warning">
    <strong>Tabel <code>number_sequences</code> belum ada.</strong> Jalankan berkas
    <code>migration_v14_nomor_otomatis.sql</code> di phpMyAdmin supaya counter voucher bisa
    diatur dari halaman ini.
  </div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        <span>Status Bulan <?= e($info['label']) ?></span>
        <form method="GET" class="d-flex gap-2">
          <input type="month" name="bulan" class="form-control form-control-sm"
                 value="<?= e(substr($bulan, 0, 4) . '-' . substr($bulan, 4, 2)) ?>">
          <button class="btn btn-sm btn-outline-secondary">Lihat</button>
        </form>
      </div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr>
            <td class="text-success fw-semibold" style="width:55%">Voucher diterbitkan bulan ini</td>
            <td class="fw-bold"><?= (int)$info['jumlah'] ?> lembar</td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">Nomor terakhir dipakai</td>
            <td class="fs-5 fw-bold"><?= $info['terakhir'] > 0 ? voucher_format_nomor(substr($bulan, 0, 4) . '-' . substr($bulan, 4, 2) . '-01', $info['terakhir']) : '-' ?></td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">Nomor berikutnya</td>
            <td class="fs-4 fw-bold text-success"><?= e($info['contoh']) ?></td>
          </tr>
        </table>
      </div>
    </div>

    <div class="card">
      <div class="card-header bg-white fw-bold">Tentukan / Reset Nomor</div>
      <div class="card-body">
        <form method="POST" class="mb-3">
          <input type="hidden" name="action" value="set">
          <input type="hidden" name="bulan" value="<?= e($bulan) ?>">
          <label class="form-label">Nomor voucher berikutnya</label>
          <div class="input-group" style="max-width:280px">
            <input type="number" min="1" name="nomor" class="form-control" value="<?= (int)$info['berikutnya'] ?>">
            <button class="btn btn-brand"><i class="bi bi-check2"></i> Simpan</button>
          </div>
          <div class="form-text">Isi angka urut yang diinginkan untuk bulan <?= e($info['label']) ?>.</div>
        </form>
        <form method="POST" onsubmit="return confirm('Yakin ingin mereset counter voucher bulan ini?');">
          <input type="hidden" name="action" value="reset">
          <input type="hidden" name="bulan" value="<?= e($bulan) ?>">
          <button class="btn btn-outline-danger"><i class="bi bi-arrow-counterclockwise"></i> Reset ke 0 (mulai dari 1 lagi)</button>
        </form>
        <div class="form-text mt-2">
          Aman: kalau nomor hasil reset sudah pernah dipakai, sistem otomatis
          melompatinya supaya tidak ada nomor kembar.
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card">
      <div class="card-header bg-white fw-bold">10 Voucher Terakhir - Bulan <?= e($info['label']) ?></div>
      <div class="card-body p-0">
        <div class="table-responsive">
          <table class="table table-sm table-hover mb-0">
            <thead class="table-light"><tr><th>No Voucher</th><th>Tanggal</th><th>No Tiket</th><th>Supplier</th><th class="text-end">Total</th><th></th></tr></thead>
            <tbody>
              <?php foreach ($daftarVoucher as $v): ?>
                <tr>
                  <td class="fw-semibold"><?= e($v['voucher_no']) ?></td>
                  <td><?= e(format_tanggal($v['voucher_date'])) ?></td>
                  <td class="small"><?= e($v['no_ticket']) ?></td>
                  <td class="small"><?= e($v['vendor_name']) ?></td>
                  <td class="text-end"><?= e(format_rupiah($v['total_bersih'])) ?></td>
                  <td><a class="btn btn-sm btn-outline-secondary" href="<?= BASE_URL ?>/voucher/lihat.php?id=<?= (int)$v['id'] ?>" target="_blank" rel="noopener">Lihat</a></td>
                </tr>
              <?php endforeach; ?>
              <?php if (!$daftarVoucher): ?>
                <tr><td colspan="6" class="text-muted text-center py-3">Belum ada voucher pada bulan ini.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
