<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);
$pageTitle = 'Pengaturan No Nota';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'reset') {
        $startAt = (int)($_POST['start_at'] ?? 0);
        if ($startAt < 0) $startAt = 0;
        reset_no_nota_counter($pdo, $startAt);
        set_flash('success', $startAt > 0
            ? "Counter No Nota berhasil direset. No Nota berikutnya akan mulai dari " . ($startAt + 1) . "."
            : "Counter No Nota berhasil direset ke 0. No Nota berikutnya akan mulai dari 1.");
        redirect('/settings/no-nota.php');
    }
}

$info = get_no_nota_counter_info($pdo);

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-123"></i> Pengaturan No Nota</h4>
<p class="text-muted small mt-n2">
  No Nota dibuat otomatis oleh sistem secara berurutan (1, 2, 3, ...) setiap
  kali PIC menambah pembelian baru, supaya tidak perlu diketik manual dan
  tidak ada nomor yang bentrok.
</p>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card mb-4">
      <div class="card-header bg-white fw-bold">Status Saat Ini</div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr>
            <td class="text-success fw-semibold" style="width:55%">No Nota terakhir dipakai</td>
            <td class="fs-4 fw-bold"><?= $info['last'] > 0 ? $info['last'] : '-' ?></td>
          </tr>
          <tr>
            <td class="text-success fw-semibold">No Nota berikutnya</td>
            <td class="fs-4 fw-bold text-success"><?= $info['next'] ?></td>
          </tr>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Reset Counter</div>
      <div class="card-body">
        <p class="small text-muted">
          Gunakan ini untuk mengembalikan No Nota ke 0 (misal pergantian
          tahun/periode baru). Setelah reset, pembelian berikutnya akan
          mendapat No Nota mulai dari nomor yang Anda tentukan di bawah + 1.
        </p>
        <form method="POST" onsubmit="return confirm('Yakin ingin mereset counter No Nota? Aksi ini tidak bisa dibatalkan.');">
          <input type="hidden" name="action" value="reset">
          <div class="mb-3">
            <label class="form-label">Mulai dari nomor</label>
            <input type="number" min="0" name="start_at" class="form-control" style="max-width:180px" value="0">
            <div class="form-text">Kosongkan/isi 0 supaya No Nota berikutnya mulai dari 1. Isi angka lain (misal 100) supaya No Nota berikutnya mulai dari 101.</div>
          </div>
          <button type="submit" class="btn btn-danger"><i class="bi bi-arrow-counterclockwise"></i> Reset Counter</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
