<?php
// =========================================================
// Pengaturan Email Laporan ke HO
// ---------------------------------------------------------
// Mengatur ke siapa tombol "Lapor ke HO (Email)" mengirim laporan,
// dan bagaimana bunyi subjek & isinya. Yang dikirim tetap lewat
// mailto: (Outlook si pemakai yang membuka), jadi tidak ada
// konfigurasi SMTP sama sekali.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';
require_role(['admin']);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Uji kirim sekarang - dikerjakan lebih dulu supaya tidak kena validasi
    // field form (form uji hanya mengirim action + contoh_id).
    if (($_POST['action'] ?? '') === 'uji') {
        $contohId = (int)($_POST['contoh_id'] ?? 0);
        $st = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name FROM purchases p
                             JOIN vendors v ON v.id=p.vendor_id JOIN users u ON u.id=p.pic_id WHERE p.id=?");
        $st->execute([$contohId]);
        $c = $st->fetch();
        if (!$c) {
            set_flash('danger', 'Uji kirim butuh satu tiket yang sudah Selesai / Done.');
        } else {
            $hasil = ho_kirim_server($pdo, $c);
            set_flash($hasil['ok'] ? 'success' : 'danger', $hasil['ok']
                ? 'Uji kirim BERHASIL: email terkirim dari server ke ' . $hasil['kepada']
                  . '. Cek kotak masuk ' . $hasil['kepada'] . ' (kalau tidak ada, lihat folder spam / SPF domain).'
                : 'Uji kirim GAGAL: ' . $hasil['pesan']);
        }
        redirect('/settings/email-laporan.php');
    }

    $to  = strtolower(trim($_POST['ho_email_to'] ?? ''));
    $cc  = strtolower(trim($_POST['ho_email_cc'] ?? ''));
    $nama = trim($_POST['ho_email_nama'] ?? '');
    $subjek = trim($_POST['ho_email_subjek'] ?? '');
    $badan  = trim($_POST['ho_email_badan'] ?? '');
    $skema = in_array($_POST['ho_email_scheme'] ?? '', ['mailto', 'outlook'], true) ? $_POST['ho_email_scheme'] : 'mailto';
    $ruteLaptop = ho_rute_laptop(['ho_email_laptop' => $_POST['ho_email_laptop'] ?? '']);
    $webHost = in_array($_POST['ho_email_web_host'] ?? '', ['outlook.office.com', 'outlook.live.com'], true)
        ? $_POST['ho_email_web_host'] : 'outlook.office.com';
    $kirimServer = isset($_POST['ho_email_kirim_server']) ? '1' : '0';
    $dari = strtolower(trim($_POST['ho_email_dari'] ?? ''));
    $enabled = isset($_POST['ho_email_enabled']) ? '1' : '0';

    if ($to !== '' && !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Alamat email tujuan tidak valid (contoh: nama@perusahaan.co.id).';
    }
    if ($cc !== '' && !filter_var($cc, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Alamat CC tidak valid. Kosongkan saja kalau tidak dipakai.';
    }
    if ($subjek === '') {
        $errors[] = 'Subjek email tidak boleh kosong.';
    }
    if (strlen($subjek) + strlen($badan) > 1700) {
        $errors[] = 'Subjek + isi email terlalu panjang (maks ± 1700 karakter). '
                  . 'Mailto punya batas panjang; ringkas kalimatnya atau hilangkan sebagian baris.';
    }

    if ($kirimServer === '1' && $dari !== '' && !filter_var($dari, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Alamat pengirim (From) tidak valid.';
    }

    if (!$errors) {
        set_app_setting($pdo, 'ho_email_enabled', $enabled);
        set_app_setting($pdo, 'ho_email_to', $to);
        set_app_setting($pdo, 'ho_email_cc', $cc);
        set_app_setting($pdo, 'ho_email_nama', $nama);
        set_app_setting($pdo, 'ho_email_scheme', $skema);
        set_app_setting($pdo, 'ho_email_laptop', $ruteLaptop);
        set_app_setting($pdo, 'ho_email_web_host', $webHost);
        set_app_setting($pdo, 'ho_email_kirim_server', $kirimServer);
        set_app_setting($pdo, 'ho_email_dari', $dari);
        set_app_setting($pdo, 'ho_email_subjek', $subjek);
        set_app_setting($pdo, 'ho_email_badan', str_replace(["\r\n", "\r"], "\n", $badan));
        set_flash('success', 'Pengaturan email laporan tersimpan.');
        redirect('/settings/email-laporan.php');
    }
    foreach (['to', 'cc', 'nama', 'subjek', 'badan', 'scheme', 'kirim_server', 'dari', 'laptop', 'web_host'] as $k) {
        $posted['ho_email_' . $k] = $_POST['ho_email_' . $k] ?? '';
    }
    $posted['ho_email_enabled'] = $enabled;
}

$set = ho_settings($pdo);
if (isset($posted)) {
    foreach ($set as $k => $v) {
        if (isset($posted[$k])) $set[$k] = $posted[$k];
    }
}

// Contoh pratinjau: pakai tiket selesai terbaru (kalau ada) supaya Admin melihat hasilnya
$contoh = $pdo->query("SELECT p.*, v.name AS vendor_name, u.name AS pic_name,
                              ap.name AS petugas_name, fa.name AS finance_appr_name,
                              dr.name AS dirops_by_name, fi.name AS finance_name
                       FROM purchases p
                       JOIN vendors v ON v.id = p.vendor_id
                       JOIN users u ON u.id = p.pic_id
                       LEFT JOIN users ap ON ap.id = p.approved_by
                       LEFT JOIN users fa ON fa.id = p.finance_approval_by
                       LEFT JOIN users dr ON dr.id = p.dirops_by
                       LEFT JOIN users fi ON fi.id = p.processed_by
                       WHERE p.status_pembayaran = 'selesai' ORDER BY p.processed_at DESC LIMIT 1")->fetch();
$pratinjau = null;
if ($contoh) {
    $vars = ho_vars($contoh, $set);
    $pratinjau = [
        'subjek' => ho_fill($set['ho_email_subjek'], $vars),
        'isi'    => ho_fill($set['ho_email_badan'], $vars),
    ];
}

$placeholderDaftar = [
    '{no_ticket}' => 'Nomor tiket', '{no_nota}' => 'Nomor nota',
    '{tanggal}' => 'Tanggal transaksi', '{daerah}' => 'Daerah',
    '{pic}' => 'Nama PIC', '{vendor}' => 'Nama supplier',
    '{berat}' => 'Berat basah (KG)', '{harga_basah}' => 'Harga basah (Rp)',
    '{harga_notaring}' => 'Harga harian notaring (Rp)', '{drc}' => 'DRC (%)',
    '{bruto}' => 'Total sebelum pajak (Rp)', '{pajak}' => 'Persentase pajak + status NPWP',
    '{potongan}' => 'Nilai potongan pajak (Rp)', '{netto}' => 'Total dibayarkan (Rp)',
    '{netto_terbilang}' => 'Netto dalam kata (terbilang)', '{status}' => 'Status akhir',
    '{dibayar_pada}' => 'Tanggal & jam pembayaran', '{finance}' => 'Nama Finance',
    '{petugas}' => 'Nama Petugas yang menyetujui', '{finance_appr}' => 'Nama Finance yang menyetujui',
    '{dirops}' => 'Nama Dirops', '{catatan_dirops}' => 'Catatan Dirops',
    '{catatan_finance}' => 'Catatan Finance', '{ho_nama}' => 'Nama tujuan (di atas)',
];

$pageTitle = 'Pengaturan Email Laporan';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-1"><i class="bi bi-envelope-paper"></i> Pengaturan Email Laporan ke HO</h4>
<p class="text-muted small mt-1">
  Setelah tiket selesai dibayar, Finance tinggal menekan tombol <strong>Lapor ke HO (Email)</strong> di
  Daftar Pembelian / Detail Pembelian. Tombol itu membuka aplikasi email komputer pemakai
  (Outlook, selama Outlook diatur sebagai aplikasi email bawaan) dengan pesan yang sudah terisi otomatis.
</p>

<?php if ($errors): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $er): ?><li><?= e($er) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="row g-4">
  <div class="col-lg-7">
    <form method="post" class="card border-0 shadow-sm">
      <div class="card-body">
        <div class="form-check form-switch mb-3">
          <input class="form-check-input" type="checkbox" role="switch" name="ho_email_enabled" value="1" id="aktif" <?= $set['ho_email_enabled'] === '1' ? 'checked' : '' ?>>
          <label class="form-check-label fw-semibold" for="aktif">Aktifkan tombol email laporan ke HO</label>
          <div class="form-text">Kalau dimatikan, tombolnya hilang dari semua halaman (data lain tidak terpengaruh).</div>
        </div>

        <div class="row g-3">
          <div class="col-md-8">
            <label class="form-label">Email tujuan <span class="text-danger">*</span></label>
            <input type="email" name="ho_email_to" class="form-control" value="<?= e($set['ho_email_to']) ?>" placeholder="arnold.parulian@arsari.co.id" required>
            <div class="form-text">Alamat HO yang menerima laporan (bawaan: arnold.parulian@arsari.co.id).</div>
          </div>
          <div class="col-md-4">
            <label class="form-label">Sapaan tujuan</label>
            <input type="text" name="ho_email_nama" class="form-control" value="<?= e($set['ho_email_nama']) ?>" placeholder="Pak Arnold">
            <div class="form-text">Pakai di <code>{ho_nama}</code>.</div>
          </div>
          <div class="col-md-8">
            <label class="form-label">CC (opsional)</label>
            <input type="email" name="ho_email_cc" class="form-control" value="<?= e($set['ho_email_cc']) ?>" placeholder="kosongkan bila tidak ada">
          </div>
          <div class="col-md-6">
            <label class="form-label">Kalau dibuka dari laptop/komputer</label>
            <select name="ho_email_laptop" class="form-select">
              <?php $rl = ho_rute_laptop($set); ?>
              <option value="auto"    <?= $rl === 'auto' ? 'selected' : '' ?>>Coba New Outlook dulu, lalu mailto:, lalu Outlook di browser (dianjurkan)</option>
              <option value="outlook" <?= $rl === 'outlook' ? 'selected' : '' ?>>Hanya aplikasi New Outlook (ms-outlook://compose)</option>
              <option value="web"     <?= $rl === 'web' ? 'selected' : '' ?>>Langsung Outlook di browser (deep link compose)</option>
              <option value="mailto"  <?= $rl === 'mailto' ? 'selected' : '' ?>>Langsung mailto: saja (perilaku paling awal)</option>
              <option value="pilih"   <?= $rl === 'pilih' ? 'selected' : '' ?>>Tawarkan pilihan tiap kali tombol ditekan</option>
            </select>
            <div class="form-text">
              "Coba New Outlook dulu" = tombol menekan <code>ms-outlook://compose?to=&amp;subject=&amp;body=</code>,
              handler URI aplikasi New Outlook (<code>olk.exe</code>). Kalau aplikasi tidak menjawab, tombol yang sama
              mencoba <code>mailto:</code>, lalu <code><?= e($set['ho_email_web_host'] ?? 'outlook.office.com') ?>/mail/deeplink/compose</code>
              (Outlook di browser). Cara yang pertama berhasil <strong>diingat di komputer itu</strong>, jadi klik
              berikutnya langsung memakai jalan yang sama; panel pertolongan punya tautan "Ulangi pemilihan cara".
              Catatan penting: New Outlook <em>tidak</em> mendukung protokol <code>outlook:</code> dan tidak menerima
              argumen <code>/c ipm.note /m</code> seperti Outlook klasik, dan sebuah halaman web tidak bisa menyetel
              <em>Default apps</em> Windows - karena itu dipakai urutan coba + ingat.
              Di HP/tablet selalu <code>mailto:</code> seperti biasa.
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label">Alamat Outlook untuk tautan laptop</label>
            <select name="ho_email_web_host" class="form-select">
              <?php $wh = $set['ho_email_web_host'] ?? 'outlook.office.com'; ?>
              <option value="outlook.office.com" <?= $wh === 'outlook.office.com' ? 'selected' : '' ?>>outlook.office.com &mdash; akun kantor / Microsoft 365</option>
              <option value="outlook.live.com" <?= $wh === 'outlook.live.com' ? 'selected' : '' ?>>outlook.live.com &mdash; akun pribadi (hotmail/outlook.com)</option>
            </select>
            <div class="form-text">Pakai yang kantor, kecuali email Pak Arnold memang akun pribadi.</div>
          </div>
          <div class="col-12">
            <div class="form-check form-switch">
              <input class="form-check-input" type="checkbox" role="switch" name="ho_email_kirim_server" value="1" id="kirimServer"
                     <?= ($set['ho_email_kirim_server'] ?? '0') === '1' ? 'checked' : '' ?>>
              <label class="form-check-label fw-semibold" for="kirimServer">Kirim email langsung dari server (tanpa Outlook)</label>
              <div class="form-text">
                Dengan ini menyala, tombol <strong>Lapor HO</strong> mengirim sendiri lewat <code>mail()</code> hosting
                (tidak butuh aplikasi email di komputer). Matikan untuk memakai cara Outlook/mailto seperti biasa.
                Perlu domain hosting sudah punya SPF yang benar, kalau tidak email bisa masuk spam.
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <label class="form-label">Alamat pengirim (From)</label>
            <input type="email" name="ho_email_dari" class="form-control" value="<?= e($set['ho_email_dari'] ?? '') ?>" placeholder="purchasing@domain-anda.com">
            <div class="form-text">Kosongkan = otomatis <code>purchasing@domain situs</code>.</div>
          </div>
          <div class="col-md-4">
            <label class="form-label">Aplikasi email yang dibuka</label>
            <select name="ho_email_scheme" class="form-select">
              <option value="mailto" <?= ($set['ho_email_scheme'] ?? 'mailto') !== 'outlook' ? 'selected' : '' ?>>Bawaan (mailto)</option>
              <option value="outlook" <?= ($set['ho_email_scheme'] ?? '') === 'outlook' ? 'selected' : '' ?>>Paksa Outlook desktop (klasik saja)</option>
            </select>
            <div class="form-text">
              "Bawaan" memakai aplikasi email default Windows/Mac.
              "Paksa Outlook" memakai protokol <code>outlook:</code> sehingga membuka aplikasi
              Outlook <strong>klasik</strong>. New Outlook mengabaikan protokol ini - untuk New Outlook
              pakai pilihan <em>Kalau dibuka dari laptop/komputer</em> di atas (atau cukup biarkan
              <em>Bawaan</em> + set default apps).
              Kalau keduanya tidak mempan (biasanya di PWA/APK atau "New Outlook"),
              biarkan saja — pemakai tetap bisa pakai tombol <strong>Unduh berkas .eml</strong>
              atau nyalakan <strong>kirim dari server</strong> di atas.
              <?= ($set['ho_email_kirim_server'] ?? '0') === '1' ? '<span class="text-muted">(tidak dipakai saat kirim dari server aktif)</span>' : '' ?>
            </div>
          </div>
          <div class="col-12">
            <label class="form-label">Subjek email</label>
            <input type="text" name="ho_email_subjek" class="form-control" value="<?= e($set['ho_email_subjek']) ?>">
          </div>
          <div class="col-12">
            <label class="form-label">Isi email</label>
            <textarea name="ho_email_badan" rows="16" class="form-control font-monospace" style="font-size:.82rem"><?= e($set['ho_email_badan']) ?></textarea>
            <div class="form-text">
              Baris <code>Catatan : -</code> otomatis dihilangkan bila kosong.
              Panjang subjek + isi saat ini: <span id="hitungPx">0</span> / 1700 karakter.
            </div>
          </div>
        </div>

        <div class="mt-3 d-flex gap-2">
          <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan</button>
          <a href="<?= BASE_URL ?>/settings/email-laporan.php" class="btn btn-outline-secondary">Batal</a>
        </div>
      </div>
    </form>
  </div>

  <div class="col-lg-5">
    <div class="card border-0 shadow-sm mb-4">
      <div class="card-header bg-white fw-bold">Placeholder yang tersedia</div>
      <div class="card-body py-2">
        <div class="row small">
          <?php foreach ($placeholderDaftar as $ph => $ket): ?>
            <div class="col-12 py-1"><code><?= e($ph) ?></code> <span class="text-muted">&mdash; <?= e($ket) ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <div class="card border-0 shadow-sm mb-4">
      <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        <span>Uji kirim</span>
        <?php if ($contoh): ?>
        <form method="post" class="d-inline">
          <input type="hidden" name="action" value="uji">
          <input type="hidden" name="contoh_id" value="<?= (int)$contoh['id'] ?>">
          <button type="submit" class="btn btn-sm btn-outline-primary"><i class="bi bi-send"></i> Kirim tes sekarang</button>
        </form>
        <?php endif; ?>
      </div>
      <div class="card-body py-3 small">
        <?php if (!$contoh): ?>
          <span class="text-muted">Butuh satu tiket berstatus <em>Selesai / Done</em> untuk dicontohkan.</span>
        <?php else: ?>
          Menguji dengan tiket <strong><?= e($contoh['no_ticket']) ?></strong> memakai pengaturan yang <strong>tersimpan sekarang</strong>
          (perubahan di form yang belum disimpan belum ikut terkirim).
        <?php endif; ?>
      </div>
    </div>

    <div class="card border-0 shadow-sm">
      <div class="card-header bg-white fw-bold">Pratinjau email</div>
      <div class="card-body">
        <?php if (!$pratinjau): ?>
          <p class="text-muted small mb-0">Belum ada tiket berstatus <em>Selesai / Done</em>, jadi pratinjau belum bisa ditampilkan.
          Angka di bawah baru muncul setelah ada satu tiket selesai dibayar oleh Finance.</p>
        <?php else: ?>
          <div class="small text-muted">Kepada: <strong><?= e($set['ho_email_to']) ?></strong><?= $set['ho_email_cc'] ? ' &middot; CC: ' . e($set['ho_email_cc']) : '' ?></div>
          <div class="small text-muted mb-2">Subjek: <strong><?= e($pratinjau['subjek']) ?></strong></div>
          <pre class="bg-light border rounded p-3 small mb-0" style="white-space:pre-wrap"><?= e($pratinjau['isi']) ?></pre>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  var f = document.querySelector('form');
  var out = document.getElementById('hitungPx');
  function hitung() {
    var s = f.querySelector('[name=ho_email_subjek]').value.length;
    var b = f.querySelector('[name=ho_email_badan]').value.length;
    out.textContent = (s + b);
    out.className = (s + b) > 1700 ? 'text-danger fw-bold' : 'text-success fw-bold';
  }
  f.addEventListener('input', hitung);
  hitung();
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
