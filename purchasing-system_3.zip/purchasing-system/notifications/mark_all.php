<?php
require_once __DIR__ . '/../includes/init.php';
require_login();
$user = current_user();

$stmt = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0");
$stmt->execute([$user['id']]);

set_flash('success', 'Semua notifikasi ditandai sudah dibaca.');
redirect('/notifications/list.php');
