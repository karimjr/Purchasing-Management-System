<?php
require_once __DIR__ . '/../includes/init.php';
require_login();
$user = current_user();
$pageTitle = 'Notifikasi';

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 100");
$stmt->execute([$user['id']]);
$notifications = $stmt->fetchAll();

$unreadCount = count_unread_notifications($pdo, $user['id']);

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-bell"></i> Notifikasi</h4>
  <?php if ($unreadCount > 0): ?>
    <a href="<?= BASE_URL ?>/notifications/mark_all.php" class="btn btn-outline-secondary btn-sm">
      <i class="bi bi-check2-all"></i> Tandai semua sudah dibaca
    </a>
  <?php endif; ?>
</div>

<div class="card">
  <div class="list-group list-group-flush">
    <?php if (!$notifications): ?>
      <div class="list-group-item text-center text-muted py-5">
        <i class="bi bi-bell-slash fs-2 d-block mb-2"></i>
        Belum ada notifikasi.
      </div>
    <?php endif; ?>
    <?php foreach ($notifications as $n): ?>
      <a href="<?= BASE_URL ?>/notifications/read.php?id=<?= $n['id'] ?>"
         class="list-group-item list-group-item-action d-flex justify-content-between align-items-start <?= $n['is_read'] ? '' : 'bg-light' ?>">
        <div class="me-3">
          <?php if (!$n['is_read']): ?><span class="badge bg-brand me-1">Baru</span><?php endif; ?>
          <span class="<?= $n['is_read'] ? '' : 'fw-semibold' ?>"><?= e($n['message']) ?></span>
        </div>
        <small class="text-muted text-nowrap"><?= time_ago($n['created_at']) ?></small>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
