<?php
require_once __DIR__ . '/../includes/init.php';
require_login();
$user = current_user();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user['id']]);
$notif = $stmt->fetch();

if ($notif) {
    $upd = $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    $upd->execute([$id]);
    if (!empty($notif['url'])) {
        redirect($notif['url']);
    }
}

redirect('/notifications/list.php');
