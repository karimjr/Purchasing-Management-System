<?php
require_once __DIR__ . '/includes/init.php';
if (current_user()) {
    redirect('/dashboard.php');
} else {
    redirect('/auth/login.php');
}
