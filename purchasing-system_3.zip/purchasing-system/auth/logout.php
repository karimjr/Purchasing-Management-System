<?php
require_once __DIR__ . '/../includes/init.php';

// Cabut device token (mode offline PWA) supaya tidak bisa dipakai sync lagi
$deviceToken = $_COOKIE['device_token'] ?? null;
if ($deviceToken) {
    revoke_device_token($pdo, $deviceToken);
    $cookiePath = defined('BASE_URL') && BASE_URL !== '' ? BASE_URL . '/' : '/';
    setcookie('device_token', '', ['expires' => time() - 3600, 'path' => $cookiePath]);
}

session_destroy();
session_start();
set_flash('success', 'Anda telah keluar.');
redirect('/auth/login.php');
