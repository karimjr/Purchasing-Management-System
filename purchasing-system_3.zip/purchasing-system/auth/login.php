<?php
require_once __DIR__ . '/../includes/init.php';

if (current_user()) {
    redirect('/dashboard.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        set_flash('danger', 'Username dan password wajib diisi.');
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1 LIMIT 1");
        $stmt->execute([$username]);
        $userRow = $stmt->fetch();

        if ($userRow && password_verify($password, $userRow['password'])) {
            $_SESSION['user'] = [
                'id'   => $userRow['id'],
                'name' => $userRow['name'],
                'username' => $userRow['username'],
                'role' => $userRow['role'],
            ];
            // Token tahan-lama (sliding session) untuk mode offline (PWA) &
            // supaya PIC/Petugas tidak pernah ke-logout paksa
            issue_device_token($pdo, $userRow['id']);
            redirect('/dashboard.php');
        } else {
            set_flash('danger', 'Username atau password salah.');
        }
    }
}

$pageTitle = 'Masuk';
$loginFlash = get_flash();
include __DIR__ . '/../includes/header.php';
?>

<div class="login-wrapper">
  <div class="card login-card p-4">
    <div class="card-body">
      <div class="text-center mb-4">
        <i class="bi bi-truck" style="font-size:2.5rem;color:#1e8449;"></i>
        <h4 class="mt-2 mb-0 fw-bold">Purchasing Management System</h4>
        <p class="text-muted small">Silakan masuk untuk melanjutkan</p>
      </div>

      <?php if ($loginFlash): ?>
        <div class="alert alert-<?= e($loginFlash['type']) ?> alert-dismissible fade show py-2" role="alert">
          <?= e($loginFlash['message']) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required autofocus>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-brand w-100 py-2">Masuk</button>
      </form>
      <hr>

    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
