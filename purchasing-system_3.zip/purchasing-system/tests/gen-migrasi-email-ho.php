<?php
chdir(dirname(__DIR__));
require 'includes/laporan_ho.php';
$sql  = "-- =========================================================\n";
$sql .= "-- Migrasi v11 - Pengaturan Email Laporan ke HO\n";
$sql .= "-- (fitur Rekapitulasi + ekspor Excel/PDF tidak mengubah struktur tabel apa pun,\n";
$sql .= "--  jadi file ini hanya menambahkan nilai bawaan pengaturan)\n";
$sql .= "-- Jalankan di phpMyAdmin pada database aplikasi. Aman dijalankan dua kali.\n";
$sql .= "-- =========================================================\n\n";
$sql .= "START TRANSACTION;\n\n";
$sql .= "-- Nilai yang sudah diubah Admin tidak ditimpa saat migrasi dijalankan ulang\n";
$sql .= "INSERT INTO `app_settings` (`setting_key`, `setting_value`) VALUES\n";
$rows = [];
foreach (HO_EMAIL_DEFAULTS as $k => $v) {
    $esc = str_replace(['\\', "'", "\r\n", "\n"], ['\\\\', "''", '\\r\\n', '\\n'], $v);
    $rows[] = "  ('$k', '$esc')";
}
$sql .= implode(",\n", $rows) . "\n";
$sql .= "ON DUPLICATE KEY UPDATE `setting_value` = `app_settings`.`setting_value`;\n\n";
$sql .= "COMMIT;\n";
file_put_contents('migration_v11_rekap_laporan_ho.sql', $sql);
echo $sql;
