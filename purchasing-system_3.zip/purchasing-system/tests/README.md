# tests/ — perkakas pengembang (tidak perlu di-upload ke hosting)

| Berkas | Guna |
|---|---|
| `lapor-ho.test.js` | Menguji `assets/js/lapor-ho.js` (26 skenario: HP, laptop Windows/macOS, PWA/APK, cascade New Outlook, rute kirim-server, salin isi). Jalankan: `node tests/lapor-ho.test.js` dari folder aplikasi. Tidak butuh database. |
| `gen-migrasi-email-ho.php` | Menulis ulang `migration_v11_rekap_laporan_ho.sql` supaya nilai bawaannya selalu sama dengan `HO_EMAIL_DEFAULTS` di `includes/laporan_ho.php`. Jalankan: `php tests/gen-migrasi-email-ho.php`. |

Keduanya hanya untuk pengembangan; aplikasi aslinya tidak memanggil apa pun di folder ini.
