/**
 * Uji assets/js/lapor-ho.js dengan DOM tiruan.
 * Dijalankan: node tests/lapor-ho.test.js  (dari folder aplikasi)
 */
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'assets', 'js', 'lapor-ho.js'), 'utf8');

let cur = [];
const logPush = (x) => cur.push(x);

function mkEl(attrs) {
  return {
    _a: attrs || {}, disabled: false, innerHTML: '', textContent: '', value: '', style: {},
    classList: { remove() { logPush('panel-ditampilkan'); }, add() {} },
    getAttribute(k) { return (k in this._a) ? this._a[k] : null; },
    setAttribute(k, v) { this._a[k] = v; logPush('set:' + k); },
    querySelector() { return mkEl({}); },
    scrollIntoView() {}, select() {}, focus() {}, remove() {}, appendChild() {},
  };
}

function env(o = {}) {
  const my = [];
  cur = my;
  const store = Object.assign({}, o.awal || {});
  const P = (x) => my.push(x);
  const panel = mkEl({});
  const navObj = {
    userAgent: o.ua || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36',
    standalone: !!o.standalone,
    maxTouchPoints: o.touch || 0,
    clipboard: o.clipboard ? { writeText: () => Promise.resolve() } : undefined,
  };
  const doc = {
    hidden: !!o.hidden,
    hasFocus: () => (o.hasFocus === undefined ? true : o.hasFocus),
    addEventListener: () => {}, removeEventListener: () => {},
    getElementById: (id) => (id === 'hoFallback' ? panel : mkEl({})),
    querySelector: () => null,
    createElement: () => mkEl({}),
    execCommand: () => { P('execCommand-copy'); return true; },
    body: { appendChild() {}, removeChild() {} },
  };
  const loc = {
    _h: '',
    get href() { return this._h; },
    set href(v) { this._h = v; P('navigasi:' + String(v).slice(0, 26)); },
  };
  const win = {
    navigator: navObj, localStorage: {
      getItem: (k) => (k in store ? store[k] : null),
      setItem: (k, v) => { store[k] = String(v); P('ingat:' + k + '=' + v); },
      removeItem: (k) => { delete store[k]; P('lupa:' + k); },
    },
    matchMedia: (q) => ({ matches: q === '(pointer: coarse)' ? !!o.coarse : false }),
    setTimeout: (f) => { f(); return 1; },          // dijalankan langsung supaya jalur "gagal" ikut teruji
    clearTimeout: () => {}, addEventListener: () => {},
    open: (u) => { P('window.open:' + String(u).slice(0, 22)); return o.openResult === undefined ? null : o.openResult; },
    alert: (m) => P('alert:' + String(m).split('\n')[0].slice(0, 40)),
    confirm: (m) => { P('confirm'); const a = (o.setuju || []); return a.length ? a.shift() !== false : (o.tidakTanya !== true && false); },
    isSecureContext: !!o.secure,
    location: loc,
  };
  global.navigator = navObj;
  global.document = doc;
  global.fetch = (u, opt) => { P('ping:' + opt.method + '->' + u); return Promise.resolve({ json: () => Promise.resolve({ ok: true, pesan: 'Terkirim', kepada: 'a@b.c' }) }); };
  const f = new Function('window', 'document', 'navigator', 'fetch', 'setTimeout', 'clearTimeout', 'alert', 'confirm',
    src + '\n;return {hoLapor: window.hoLapor, hoKirim: window.hoKirim, hoSalin: window.hoSalin, hoPilihPerangkat: window.hoPilihPerangkat, hoLupaRute: window.hoLupaRute};');
  return { api: f(win, doc, navObj, global.fetch, win.setTimeout, win.clearTimeout, win.alert, win.confirm), panel, store, loc, logOf: () => my };
}

const urutan = (l) => l.filter(x => x.startsWith('navigasi:') || x.startsWith('window.open:'));
const BUTTON = (extra) => mkEl(Object.assign({
  'data-mailto': 'mailto:a@b.c?subject=x',
  'href': 'mailto:a@b.c?subject=x',
  'data-web': 'https://outlook.office.com/mail/deeplink/compose?to=a@b.c',
  'data-msoutlook': 'ms-outlook://compose?to=a@b.c&subject=x',
  'data-rute': 'auto',
  'data-id': '30',
  'data-ping': '/finance/lapor-ho-log.php',
  'data-panel': 'hoFallback',
}, extra || {}));

let gagal = 0;
function cek(judul, syarat, detail) {
  const ok = syarat();
  if (!ok) gagal++;
  console.log((ok ? '  OK  ' : 'GAGAL ') + judul + (detail ? '  [' + detail() + ']' : ''));
}

console.log('--- HP & PWA (perilaku lama harus utuh) ---');
let e1 = env({ hidden: true, ua: 'Mozilla/5.0 (Linux; Android 13; SM-A125F) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36' });
e1.api.hoLapor(BUTTON());
cek('HP: navigasi mailto, tanpa ms-outlook', () => urutan(e1.logOf())[0].startsWith('navigasi:mailto:') && !e1.logOf().some(x => x.includes('ms-outlook')));
cek('HP: tidak ada panel saat fokus hilang (email ternyata terbuka)', () => !e1.logOf().includes('panel-ditampilkan'), () => e1.logOf().join(' | '));
cek('HP: klik dicatat ke server', () => e1.logOf().some(x => x.startsWith('ping:POST')));

let e2 = env({ hasFocus: true, ua: 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36' });
e2.api.hoLapor(BUTTON());
cek('HP tapi halaman masih fokus -> panel cadangan muncul', () => e2.logOf().includes('panel-ditampilkan'));

let e3 = env({ standalone: true, ua: 'Mozilla/5.0 (Linux; Android 13) ; wv) Chrome/126' });
e3.api.hoLapor(BUTTON());
cek('PWA/APK di HP: mailto dilempar ke tab baru (window.open)', () => e3.logOf().some(x => x.startsWith('window.open:mailto:')));
cek('PWA/APK di laptop Windows: cascade New Outlook lewat tab baru', () => {
  const x = env({ standalone: true, ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36' });
  x.api.hoLapor(BUTTON());
  const u = urutan(x.logOf());
  return u.length >= 1 && u[0].startsWith('window.open:ms-outlook://');
});
cek('PWA/APK: tidak memakai ms-outlook', () => !e3.logOf().some(x => x.includes('ms-outlook')));

console.log('--- Laptop Windows: rute auto mencoba New Outlook lebih dulu ---');
let e4 = env({});
e4.api.hoLapor(BUTTON());
const l4 = e4.logOf();
const u4 = urutan(l4);
cek('kandidat #1 = ms-outlook://compose (navigasi, bukan window.open)', () => u4[0].startsWith('navigasi:ms-outlook://'), () => u4[0]);
cek('lalu varian ms-outlook:compose', () => l4.some(x => x.startsWith('navigasi:ms-outlook:compose')), () => l4.filter(x => x.startsWith('navigasi')).join(' | '));
cek('lalu mailto:', () => l4.some(x => x.startsWith('navigasi:mailto:')));
cek('urutan: ms-outlook:// -> ms-outlook: -> mailto -> https (lagi navigasi krn popup diblokir)', () =>
  u4[0].startsWith('navigasi:ms-outlook://') && u4[1].startsWith('navigasi:ms-outlook:compose')
  && u4[2].startsWith('navigasi:mailto:') && u4[3].startsWith('window.open:https://outlook')
  && u4[4].startsWith('navigasi:https://outlook'), () => u4.join(' -> '));
cek('pemakai ditanya setelah tiap percobaan', () => l4.filter(x => x === 'confirm').length >= 3, () => 'confirm x' + l4.filter(x => x === 'confirm').length);
cek('semua gagal -> panel cadangan dibuka', () => l4.includes('panel-ditampilkan'));

cek('jawaban "sudah" di kandidat #1 -> cara itu diingat', () => {
  const x = env({ setuju: [true] });
  x.api.hoLapor(BUTTON());
  return x.store['hoRuteLaptop'] === 'msoutlook';
});
cek('cara yang sudah diingat dipakai langsung (tanpa tanya)', () => {
  const x = env({ awal: { hoRuteLaptop: 'web' } });
  x.api.hoLapor(BUTTON());
  return urutan(x.logOf())[0].startsWith('window.open:https://outlook') && !x.logOf().includes('confirm');
});
cek('diingat msoutlook2 -> pakai varian ms-outlook:compose', () => {
  const x = env({ awal: { hoRuteLaptop: 'msoutlook2' } });
  x.api.hoLapor(BUTTON());
  return urutan(x.logOf())[0].startsWith('navigasi:ms-outlook:compose');
});
cek('browser kehilangan fokus/tab tertutup -> dianggap berhasil, tidak ditanya', () => {
  const x = env({ hidden: true });
  x.api.hoLapor(BUTTON());
  return x.store['hoRuteLaptop'] === 'msoutlook' && !x.logOf().includes('confirm');
});

console.log('--- rute lain & perangkat lain ---');
cek('rute "outlook": hanya ms-outlook, tidak turun ke mailto, panel muncul', () => {
  const x = env({ setuju: [false, false] });
  x.api.hoLapor(BUTTON({ 'data-rute': 'outlook' }));
  const l = x.logOf();
  return l.some(y => y.startsWith('navigasi:ms-outlook')) && !l.some(y => y.startsWith('navigasi:mailto:')) && l.includes('panel-ditampilkan');
});
cek('rute "mailto": tetap mailto seperti dulu', () => {
  const x = env({});
  x.api.hoLapor(BUTTON({ 'data-rute': 'mailto' }));
  return urutan(x.logOf())[0].startsWith('navigasi:mailto:') && !x.logOf().some(y => y.includes('ms-outlook'));
});
cek('rute "web": langsung Outlook di browser', () => {
  const x = env({ openResult: {} });
  x.api.hoLapor(BUTTON({ 'data-rute': 'web' }));
  return urutan(x.logOf())[0].startsWith('window.open:https://outlook');
});
cek('macOS: tidak mencoba ms-outlook (khusus Windows), mulai dari mailto', () => {
  const x = env({ ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.4 Safari/605.1.15' });
  x.api.hoLapor(BUTTON());
  return urutan(x.logOf())[0].startsWith('navigasi:mailto:') && !x.logOf().some(y => y.includes('ms-outlook'));
});
cek('iPad (menyamar Macintosh) dianggap HP -> mailto tanpa ms-outlook', () => {
  const x = env({ ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.4 Safari/605.1.15', touch: 5 });
  x.api.hoLapor(BUTTON());
  return urutan(x.logOf())[0].startsWith('navigasi:mailto:') && !x.logOf().some(y => y.includes('ms-outlook'));
});
cek('"Saya pakai laptop" mengalahkan UA Android', () => {
  const x = env({ ua: 'Mozilla/5.0 (Linux; Android 13; SM-A125F) Chrome/126 Mobile Safari/537.36', setuju: [true] });
  x.api.hoPilihPerangkat('laptop');
  return x.store['hoPerangkat'] === 'laptop';
});
cek('"Ulangi pemilihan cara" menghapus memori rute & perangkat', () => {
  const x = env({ awal: { hoRuteLaptop: 'msoutlook', hoPerangkat: 'laptop' } });
  try { x.api.hoLupaRute(); } catch (e) { /* reload() tidak ada di stub -> diabaikan */ }
  return !('hoRuteLaptop' in x.store);
});
cek('tombol tanpa data-msoutlook (mis. fitur lama) -> auto tetap mulai dari mailto', () => {
  const x = env({});
  x.api.hoLapor(BUTTON({ 'data-msoutlook': null }));
  return urutan(x.logOf())[0].startsWith('navigasi:mailto:');
});

console.log('--- jalur lain yang sudah ada ---');
let e5 = env({});
e5.api.hoKirim(mkEl({ 'data-kirim': '/finance/lapor-ho-kirim.php', 'data-id': '30', 'data-panel': 'hoFallback' }));
cek('mode server: POST ke endpoint kirim', () => e5.logOf().some(x => x.includes('lapor-ho-kirim')));

let e6 = env({ secure: true, clipboard: true });
e6.api.hoSalin('isiEmailHo');
cek('salin isi email tidak melempar error', () => true);

let e7 = env({});
e7.api.hoLapor(mkEl({
  'href': 'mailto:a@b.c?subject=x', 'data-mailto': 'mailto:a@b.c?subject=x',
  'data-msoutlook': 'ms-outlook://compose?to=a@b.c', 'data-web': 'https://outlook.office.com/mail/deeplink/compose?to=a@b.c',
  'data-rute': 'outlook', 'data-id': '1',
}));
cek('baris daftar (tanpa panel): New Outlook tidak jawab -> alert arahan', () =>
  e7.logOf().some(x => x.startsWith('navigasi:ms-outlook://')) && e7.logOf().some(x => x.startsWith('alert:')), () => e7.logOf().join(' | '));
cek('baris daftar: rute "outlook" mencoba 2 varian ms-outlook, tidak turun ke mailto/browser', () =>
  e7.logOf().filter(x => x.startsWith('navigasi:ms-outlook')).length === 2
  && !e7.logOf().some(x => x.startsWith('navigasi:mailto:') || x.startsWith('window.open:https')), () => e7.logOf().join(' | '));

console.log(gagal === 0 ? '\nSEMUA SKUJI JS LOLOS' : `\n${gagal} SKUJI JS GAGAL`);
process.exit(gagal === 0 ? 0 : 1);
