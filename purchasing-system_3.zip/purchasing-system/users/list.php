<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);
$pageTitle = 'Manajemen User';
$users = $pdo->query("SELECT * FROM users ORDER BY role, name")->fetchAll();
include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-people"></i> Manajemen User</h4>
  <a href="<?= BASE_URL ?>/users/add.php" class="btn btn-brand"><i class="bi bi-plus-lg"></i> Tambah User</a>
</div>

<div class="table-responsive">
  <table class="table table-hover bg-white align-middle">
    <thead class="table-light">
      <tr><th>Nama</th><th>Username</th><th>No. WhatsApp</th><th>Role</th><th>Status</th><th></th></tr>
    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?= e($u['name']) ?></td>
          <td><?= e($u['username']) ?></td>
          <td><?= $u['whatsapp'] ? e($u['whatsapp']) : '<span class="text-muted">-</span>' ?></td>
          <td><span class="badge text-bg-secondary"><?= e(role_label($u['role'])) ?></span></td>
          <td><?= $u['is_active'] ? '<span class="badge text-bg-success">Aktif</span>' : '<span class="badge text-bg-danger">Nonaktif</span>' ?></td>
          <td>
            <a href="<?= BASE_URL ?>/users/edit.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
            <?php if ($u['id'] != current_user()['id']): ?>
              <a href="<?= BASE_URL ?>/users/delete.php?id=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus user ini?')"><i class="bi bi-trash"></i></a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
