<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);

$id = (int)($_GET['id'] ?? 0);
$user = current_user();

if ($id === $user['id']) {
    set_flash('danger', 'Anda tidak dapat menghapus akun Anda sendiri.');
    redirect('/users/list.php');
}

$checkStmt = $pdo->prepare("SELECT COUNT(*) FROM purchases WHERE pic_id = ? OR approved_by = ? OR processed_by = ?");
$checkStmt->execute([$id, $id, $id]);
if ($checkStmt->fetchColumn() > 0) {
    set_flash('danger', 'User tidak dapat dihapus karena memiliki riwayat transaksi. Nonaktifkan saja user ini.');
    redirect('/users/list.php');
}

$stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
$stmt->execute([$id]);

set_flash('success', 'User berhasil dihapus.');
redirect('/users/list.php');
