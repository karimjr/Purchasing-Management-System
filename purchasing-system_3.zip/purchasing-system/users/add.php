<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);
$errors = [];
$form = ['name' => '', 'username' => '', 'whatsapp' => '', 'role' => 'pic'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['name'] = trim($_POST['name'] ?? '');
    $form['username'] = trim($_POST['username'] ?? '');
    $form['whatsapp'] = trim($_POST['whatsapp'] ?? '');
    $form['role'] = $_POST['role'] ?? 'pic';
    $password = $_POST['password'] ?? '';

    if ($form['name'] === '') $errors[] = 'Nama wajib diisi.';
    if ($form['username'] === '') $errors[] = 'Username wajib diisi.';
    if ($password === '' || strlen($password) < 6) $errors[] = 'Password wajib diisi, minimal 6 karakter.';
    if (!in_array($form['role'], ['admin', 'petugas', 'pic', 'finance', 'dirops', 'manajemen'])) $errors[] = 'Role tidak valid.';

    if (empty($errors)) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
        $check->execute([$form['username']]);
        if ($check->fetchColumn() > 0) {
            $errors[] = 'Username sudah digunakan.';
        }
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $waNumber = $form['whatsapp'] !== '' ? normalize_wa_number($form['whatsapp']) : null;
        $stmt = $pdo->prepare("INSERT INTO users (name, username, whatsapp, password, role) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$form['name'], $form['username'], $waNumber, $hash, $form['role']]);
        set_flash('success', 'User berhasil ditambahkan.');
        redirect('/users/list.php');
    }
}

$pageTitle = 'Tambah User';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-plus-lg"></i> Tambah User</h4>

<?php if ($errors): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="name" class="form-control" value="<?= e($form['name']) ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="<?= e($form['username']) ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">No. WhatsApp</label>
        <input type="text" name="whatsapp" class="form-control" value="<?= e($form['whatsapp']) ?>" placeholder="08xxxxxxxxxx">
        <div class="form-text">Dipakai untuk mengirim notifikasi &amp; reminder approval otomatis lewat WhatsApp.</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select">
          <option value="pic" <?= $form['role'] === 'pic' ? 'selected' : '' ?>>PIC (input pembelian)</option>
          <option value="petugas" <?= $form['role'] === 'petugas' ? 'selected' : '' ?>>Petugas (approval)</option>
          <option value="dirops" <?= $form['role'] === 'dirops' ? 'selected' : '' ?>>Direktur Operasional (approval akhir)</option>
          <option value="finance" <?= $form['role'] === 'finance' ? 'selected' : '' ?>>Finance (pembayaran)</option>
          <option value="manajemen" <?= $form['role'] === 'manajemen' ? 'selected' : '' ?>>Manajemen (lihat laporan &amp; data, tanpa input)</option>
          <option value="admin" <?= $form['role'] === 'admin' ? 'selected' : '' ?>>Administrator</option>
        </select>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan</button>
        <a href="<?= BASE_URL ?>/users/list.php" class="btn btn-outline-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
