<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin']);

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$id]);
$userRow = $stmt->fetch();

if (!$userRow) {
    set_flash('danger', 'User tidak ditemukan.');
    redirect('/users/list.php');
}

$errors = [];
$form = $userRow;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['name'] = trim($_POST['name'] ?? '');
    $form['username'] = trim($_POST['username'] ?? '');
    $form['whatsapp'] = trim($_POST['whatsapp'] ?? '');
    $form['role'] = $_POST['role'] ?? 'pic';
    $form['is_active'] = isset($_POST['is_active']) ? 1 : 0;
    $password = $_POST['password'] ?? '';

    if ($form['name'] === '') $errors[] = 'Nama wajib diisi.';
    if ($form['username'] === '') $errors[] = 'Username wajib diisi.';
    if (!in_array($form['role'], ['admin', 'petugas', 'pic', 'finance', 'dirops', 'manajemen'])) $errors[] = 'Role tidak valid.';
    if ($password !== '' && strlen($password) < 6) $errors[] = 'Password baru minimal 6 karakter.';

    if (empty($errors)) {
        $check = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
        $check->execute([$form['username'], $id]);
        if ($check->fetchColumn() > 0) {
            $errors[] = 'Username sudah digunakan user lain.';
        }
    }

    if (empty($errors)) {
        $waNumber = $form['whatsapp'] !== '' ? normalize_wa_number($form['whatsapp']) : null;
        if ($password !== '') {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET name=?, username=?, whatsapp=?, role=?, is_active=?, password=? WHERE id=?");
            $stmt->execute([$form['name'], $form['username'], $waNumber, $form['role'], $form['is_active'], $hash, $id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET name=?, username=?, whatsapp=?, role=?, is_active=? WHERE id=?");
            $stmt->execute([$form['name'], $form['username'], $waNumber, $form['role'], $form['is_active'], $id]);
        }
        set_flash('success', 'User berhasil diperbarui.');
        redirect('/users/list.php');
    }
}

$pageTitle = 'Edit User';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-pencil"></i> Edit User</h4>

<?php if ($errors): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="id" value="<?= $id ?>">
      <div class="mb-3">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="name" class="form-control" value="<?= e($form['name']) ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="<?= e($form['username']) ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">No. WhatsApp</label>
        <input type="text" name="whatsapp" class="form-control" value="<?= e($form['whatsapp'] ?? '') ?>" placeholder="08xxxxxxxxxx">
        <div class="form-text">Dipakai untuk mengirim notifikasi &amp; reminder approval otomatis lewat WhatsApp.</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Password Baru (opsional)</label>
        <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak ingin mengubah">
      </div>
      <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select">
          <option value="pic" <?= $form['role'] === 'pic' ? 'selected' : '' ?>>PIC (input pembelian)</option>
          <option value="petugas" <?= $form['role'] === 'petugas' ? 'selected' : '' ?>>Petugas (approval)</option>
          <option value="dirops" <?= $form['role'] === 'dirops' ? 'selected' : '' ?>>Direktur Operasional (approval akhir)</option>
          <option value="finance" <?= $form['role'] === 'finance' ? 'selected' : '' ?>>Finance (pembayaran)</option>
          <option value="manajemen" <?= $form['role'] === 'manajemen' ? 'selected' : '' ?>>Manajemen (lihat laporan &amp; data, tanpa input)</option>
          <option value="admin" <?= $form['role'] === 'admin' ? 'selected' : '' ?>>Administrator</option>
        </select>
      </div>
      <div class="form-check mb-3">
        <input type="checkbox" name="is_active" class="form-check-input" id="isActive" <?= $form['is_active'] ? 'checked' : '' ?>>
        <label class="form-check-label" for="isActive">Akun aktif</label>
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan</button>
        <a href="<?= BASE_URL ?>/users/list.php" class="btn btn-outline-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
