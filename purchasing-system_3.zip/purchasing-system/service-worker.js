/**
 * Service Worker - Purchasing Management System
 * Menyimpan "app shell" (CSS/JS/ikon + halaman terakhir yang dibuka) di HP
 * supaya aplikasi tetap bisa dibuka walau tidak ada internet.
 * Data (submit form) TIDAK ditangani di sini - itu ditangani oleh
 * assets/js/offline-queue.js lewat IndexedDB.
 */

const VERSION = 'v17';
const CACHE_STATIC = 'purchasing-static-' + VERSION;
const CACHE_PAGES = 'purchasing-pages-' + VERSION;
const CACHE_CDN = 'purchasing-cdn-' + VERSION;

// Tentukan base path secara dinamis dari lokasi file ini sendiri,
// supaya tetap benar walau aplikasi dipasang di sub-folder hosting.
const BASE = self.location.href.replace(/service-worker\.js(\?.*)?$/, '');

// Penanda "?v=10" pada URL ikon: hosting mengirim aset statis dengan
// Cache-Control: max-age=2592000, immutable, jadi tanpa penanda ini HP yang sudah
// pernah membuka situs akan terus memakai ikon lama sampai 30 hari.
const STATIC_ASSETS = [
  BASE + 'manifest.json',
  BASE + 'assets/css/style.css',
  BASE + 'assets/js/offline-queue.js',
  BASE + 'assets/js/mobile-tables.js',
  BASE + 'assets/js/lapor-ho.js',
  BASE + 'assets/js/image-compress.js',
  BASE + 'assets/icons/icon-192.png?v=10',
  BASE + 'assets/icons/icon-512.png?v=10',
  BASE + 'assets/icons/icon-maskable-512.png?v=10',
  BASE + 'assets/icons/apple-touch-icon.png?v=11',
  BASE + 'offline.html',
];

const CDN_ASSETS = [
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      const staticCache = await caches.open(CACHE_STATIC);
      await staticCache.addAll(STATIC_ASSETS).catch(() => {});

      const cdnCache = await caches.open(CACHE_CDN);
      await Promise.all(
        CDN_ASSETS.map((url) =>
          fetch(url).then((res) => cdnCache.put(url, res)).catch(() => {})
        )
      );
      self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter((k) => ![CACHE_STATIC, CACHE_PAGES, CACHE_CDN].includes(k))
          .map((k) => caches.delete(k))
      );
      self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return; // biarkan POST/PUT/DELETE lewat apa adanya (form, API sync, dll)

  const url = new URL(req.url);

  // Aset dari CDN (Bootstrap dll) -> cache-first, simpan versi baru kalau berhasil online
  if (url.hostname === 'cdn.jsdelivr.net') {
    event.respondWith(
      caches.match(req).then((cached) => {
        const fetchPromise = fetch(req)
          .then((res) => {
            caches.open(CACHE_CDN).then((c) => c.put(req, res.clone()));
            return res;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
    );
    return;
  }

  if (url.origin !== self.location.origin) return; // domain lain, jangan dicampuri

  // Aset statis milik app sendiri -> cache-first
  if (STATIC_ASSETS.includes(req.url) || /\.(css|js|png|jpg|jpeg|webp|svg)$/.test(url.pathname)) {
    event.respondWith(
      caches.match(req).then((cached) => {
        if (cached) return cached;
        return fetch(req)
          .then((res) => {
            caches.open(CACHE_STATIC).then((c) => c.put(req, res.clone()));
            return res;
          })
          .catch(() => cached);
      })
    );
    return;
  }

  // Halaman HTML (navigasi) -> coba online dulu, simpan salinannya;
  // kalau gagal (offline), pakai salinan terakhir yang tersimpan,
  // kalau belum pernah dibuka sama sekali baru tampilkan offline.html
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          caches.open(CACHE_PAGES).then((c) => c.put(req, res.clone()));
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(req);
          return cached || caches.match(BASE + 'offline.html');
        })
    );
  }
});
