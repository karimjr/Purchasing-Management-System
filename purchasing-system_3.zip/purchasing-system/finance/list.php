<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';
require_role(['admin', 'finance']);
$pageTitle = 'Pembayaran (Finance)';

$filter = $_GET['status'] ?? 'menunggu_finance';
$allowed = ['menunggu_finance', 'ditolak_finance', 'menunggu_dirops', 'ditolak_dirops', 'sudah_diajukan_ho', 'menunggu_pembayaran', 'sedang_diproses', 'selesai', 'gagal', 'dibatalkan', 'semua'];
if (!in_array($filter, $allowed)) $filter = 'menunggu_finance';

// Finance memverifikasi tiket terlebih dahulu, lalu meminta approval Dirops.
$sql = "SELECT p.*, v.name as vendor_name, u.name as pic_name
        FROM purchases p
        JOIN vendors v ON v.id = p.vendor_id
        JOIN users u ON u.id = p.pic_id
        WHERE p.status_approval = 'disetujui'";
$params = [];
if ($filter === 'menunggu_finance') {
    $sql .= " AND p.status_finance_approval = 'menunggu'";
} elseif ($filter === 'ditolak_finance') {
    $sql .= " AND p.status_finance_approval = 'ditolak'";
} elseif ($filter === 'menunggu_dirops') {
    $sql .= " AND p.status_finance_approval = 'disetujui' AND p.status_dirops = 'menunggu'";
} elseif ($filter === 'ditolak_dirops') {
    $sql .= " AND p.status_finance_approval = 'disetujui' AND p.status_dirops = 'ditolak'";
} elseif ($filter !== 'semua') {
    $sql .= " AND p.status_finance_approval = 'disetujui' AND p.status_dirops = 'disetujui' AND p.status_pembayaran = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY p.approved_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$purchases = $stmt->fetchAll();

$waFinanceUsers = get_users_with_wa($pdo, ['finance']);
$waDiropsUsers = get_users_with_wa($pdo, ['dirops']);

$tabs = [
    'menunggu_finance' => 'Menunggu Approval Finance',
    'ditolak_finance' => 'Ditolak Finance',
    'menunggu_dirops' => 'Menunggu Approval Dirops',
    'menunggu_pembayaran' => 'Menunggu Pembayaran',
    'sedang_diproses' => 'Sedang Diproses',
    'selesai' => 'Selesai',
    'gagal' => 'Gagal',
    'dibatalkan' => 'Dibatalkan',
    'ditolak_dirops' => 'Ditolak Dirops',
    'sudah_diajukan_ho' => 'Sudah Diajukan ke HO',
    'semua' => 'Semua',
];

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-cash-coin"></i> Pembayaran (Finance)</h4>
<p class="text-muted small mt-n2">Alur: Petugas → Finance → Dirops → Finance. Finance melakukan verifikasi terlebih dahulu sebelum meminta approval Dirops.
  Untuk tiket yang sudah <span class="badge text-bg-success">Selesai / Done</span>, tersedia tombol <strong>Lapor HO</strong> untuk mengirim email pemberitahuan ke HO.</p>

<ul class="nav nav-pills mb-4 flex-wrap">
  <?php foreach ($tabs as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?= $filter === $key ? 'active bg-success' : 'text-dark' ?>" href="?status=<?= $key ?>"><?= $label ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="table-responsive">
  <table class="table table-hover align-middle bg-white">
    <thead class="table-light">
      <tr>
        <th>No Ticket</th>
        <th>Tanggal</th>
        <th>PIC</th>
        <th>Supplier</th>
        <th>Total Sebelum Pajak</th>
        <th>Total Potongan</th>
        <th>Total Setelah Pajak</th>
        <th>Status Dirops</th>
        <th>Status Pembayaran</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($purchases)): ?>
        <tr><td colspan="10" class="text-center text-muted py-4">Tidak ada data.</td></tr>
      <?php else: foreach ($purchases as $row): ?>
        <tr>
          <td><?= e($row['no_ticket']) ?></td>
          <td><?= format_tanggal($row['tanggal']) ?></td>
          <td><?= e($row['pic_name']) ?></td>
          <td><?= e($row['vendor_name']) ?></td>
          <td><?= format_rupiah($row['total_harga']) ?></td>
          <td><?= format_rupiah(total_potongan_pajak($row)) ?></td>
          <td><?= format_rupiah(total_setelah_pajak($row)) ?></td>
          <td><?= badge_dirops($row['status_dirops']) ?></td>
          <td><?= badge_pembayaran($row['status_pembayaran']) ?></td>
          <td class="text-nowrap">
            <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
            <?php if ($row['status_finance_approval'] === 'menunggu'): ?>
              <a href="<?= BASE_URL ?>/finance/approve.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses Approval Finance"><i class="bi bi-check2-square"></i> Approval Finance</a>
            <?php elseif ($row['status_finance_approval'] === 'disetujui' && $row['status_dirops'] === 'menunggu'): ?>
              <?php $askMsg = "Permisi Bapak/Ibu Direktur Operasional, mohon dibantu approval pembelian {$row['no_ticket']} dari PIC {$row['pic_name']} (Supplier: {$row['vendor_name']}, Nilai: " . format_rupiah($row['total_harga']) . ") yang telah disetujui Petugas dan Finance. Mohon diberikan keputusan beserta catatan apabila belum disetujui. Terima kasih."; ?>
              <?php if (!empty($waDiropsUsers)): ?>
                <?php if (count($waDiropsUsers) === 1): ?>
                  <a href="<?= e(wa_link($waDiropsUsers[0]['whatsapp'], $askMsg)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-success" title="Minta Approval Dirops"><i class="bi bi-whatsapp"></i> Minta Approval Dirops</a>
                <?php else: ?><div class="dropdown d-inline-block"><button class="btn btn-sm btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown"><i class="bi bi-whatsapp"></i> Minta Approval Dirops</button><ul class="dropdown-menu"><?php foreach ($waDiropsUsers as $wd): ?><li><a class="dropdown-item" href="<?= e(wa_link($wd['whatsapp'], $askMsg)) ?>" target="_blank" rel="noopener">WA ke <?= e($wd['name']) ?></a></li><?php endforeach; ?></ul></div><?php endif; ?>
              <?php else: ?><span class="badge text-bg-light text-muted border">Belum ada kontak Dirops</span><?php endif; ?>
            <?php elseif ($row['status_finance_approval'] === 'disetujui' && $row['status_dirops'] === 'disetujui'): ?>
              <?php if (!in_array($row['status_pembayaran'], ['selesai', 'dibatalkan'])): ?><a href="<?= BASE_URL ?>/finance/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Update Status Pembayaran"><i class="bi bi-cash-coin"></i> Update Status</a><?php endif; ?>
              <a href="<?= BASE_URL ?>/voucher/lihat.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-success" title="Voucher Pembayaran"><i class="bi bi-receipt"></i> Voucher</a>
              <?php if (!empty($waDiropsUsers)): ?><?php $progressMsg = "Permisi Bapak/Ibu Direktur Operasional, kami informasikan progres pembelian {$row['no_ticket']} yang telah disetujui: status saat ini " . str_replace('_', ' ', $row['status_pembayaran']) . ". Finance akan memperbarui kembali apabila ada perkembangan berikutnya. Terima kasih."; ?><a href="<?= e(wa_link($waDiropsUsers[0]['whatsapp'], $progressMsg)) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-primary" title="Lapor progres ke Dirops"><i class="bi bi-whatsapp"></i></a><?php endif; ?>
              <?php if ($row['status_pembayaran'] === 'selesai'): ?>
                <?php // Klik -> Outlook terbuka dengan laporan untuk HO sudah terisi (Pak Arnold)
                      $hoBtn = ho_tombol_html($pdo, $row, 'btn-outline-primary', '<i class="bi bi-envelope-paper"></i> Lapor HO'); ?>
                <?= $hoBtn ?>
              <?php endif; ?>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
