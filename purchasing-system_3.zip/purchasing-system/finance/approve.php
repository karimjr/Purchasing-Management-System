<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'finance']);
$user = current_user();
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name FROM purchases p JOIN vendors v ON v.id=p.vendor_id JOIN users u ON u.id=p.pic_id WHERE p.id=?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();
if (!$purchase) { set_flash('danger', 'Data tidak ditemukan.'); redirect('/finance/list.php'); }
if ($purchase['status_approval'] !== 'disetujui') { set_flash('warning', 'Pembelian belum disetujui Petugas.'); redirect('/finance/list.php'); }
if ($purchase['status_finance_approval'] !== 'menunggu') { set_flash('warning', 'Approval Finance untuk pembelian ini sudah diproses.'); redirect('/finance/list.php'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $decision = $_POST['decision'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');
    if (!in_array($decision, ['disetujui','ditolak'])) set_flash('danger', 'Keputusan tidak valid.');
    elseif ($decision === 'ditolak' && $catatan === '') set_flash('danger', 'Alasan penolakan wajib diisi.');
    else {
        $stmt = $pdo->prepare("UPDATE purchases SET status_finance_approval=?, catatan_finance_approval=?, finance_approval_by=?, finance_approval_at=NOW(), last_reminder_stage=NULL, last_reminder_at=NULL WHERE id=?");
        $stmt->execute([$decision, $catatan, $user['id'], $id]);
        $label = $decision === 'disetujui' ? 'Disetujui oleh Finance' : 'Ditolak oleh Finance';
        log_activity($pdo, $id, $label, $catatan ?: null);
        $decisionLabel = $decision === 'disetujui' ? 'disetujui' : 'ditolak';
        create_notification($pdo, $purchase['pic_id'], "Pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Finance ({$user['name']})." . ($catatan ? " Catatan: $catatan" : ''), '/pembelian/detail.php?id='.$id, $id, 'finance_selesai');
        notify_user_wa($pdo, $purchase['pic_id'], "Permisi, kami informasikan bahwa pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Finance ({$user['name']})." . ($catatan ? " Alasan/catatan: $catatan" : ''), $id);
        if ($decision === 'disetujui') {
            notify_role($pdo, ['finance', 'admin'], "Pembelian {$purchase['no_ticket']} telah disetujui Finance dan siap dimintakan approval kepada Direktur Operasional.", '/finance/list.php?status=menunggu_dirops', $id, 'dirops_menunggu', $user['id']);
            notify_role_wa($pdo, ['dirops'], "Permisi Bapak/Ibu Direktur Operasional, mohon dibantu approval pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . ") yang telah diverifikasi Petugas dan disetujui Finance. Mohon kiranya dapat diberikan keputusan approval beserta catatan apabila diperlukan. Terima kasih.", $id);
        } else {
            notify_role($pdo, ['finance','admin'], "Pembelian {$purchase['no_ticket']} ditolak oleh Finance ({$user['name']})." . ($catatan ? " Alasan: $catatan" : ''), '/pembelian/detail.php?id='.$id, $id, 'finance_selesai', $user['id']);
        }
        set_flash('success', "Pembelian {$purchase['no_ticket']} telah $decision oleh Finance.");
        redirect('/finance/list.php?status=' . ($decision === 'disetujui' ? 'menunggu_dirops' : 'ditolak_finance'));
    }
}
$pageTitle = 'Approval Finance'; include __DIR__ . '/../includes/header.php';
?>
<h4 class="mb-3"><i class="bi bi-check2-square"></i> Approval Finance - <?= e($purchase['no_ticket']) ?></h4>
<div class="row g-4"><div class="col-lg-6"><div class="card"><div class="card-header bg-white fw-bold">Ringkasan Pembelian</div><div class="card-body"><table class="table table-borderless mb-0">
<tr><td class="label text-success fw-semibold">Tanggal</td><td><?= format_tanggal($purchase['tanggal']) ?></td></tr>
<tr><td class="label text-success fw-semibold">PIC</td><td><?= e($purchase['pic_name']) ?></td></tr>
<tr><td class="label text-success fw-semibold">Supplier</td><td><?= e($purchase['vendor_name']) ?></td></tr>
<tr><td class="label text-success fw-semibold">No Nota</td><td><?= e($purchase['no_nota']) ?></td></tr>
<tr><td class="label text-success fw-semibold">Nilai</td><td class="fw-bold"><?= format_rupiah($purchase['total_harga']) ?></td></tr>
</table></div></div></div>
<div class="col-lg-6"><div class="card"><div class="card-header bg-white fw-bold">Keputusan Finance</div><div class="card-body"><form method="POST"><input type="hidden" name="id" value="<?= $id ?>"><div class="mb-3"><label class="form-label">Catatan / alasan (wajib jika ditolak)</label><textarea name="catatan" class="form-control" rows="4" placeholder="Contoh: Dokumen dan nilai pembelian telah diverifikasi."></textarea></div><div class="d-flex gap-2"><button name="decision" value="disetujui" class="btn btn-success flex-fill"><i class="bi bi-check-lg"></i> Setujui</button><button name="decision" value="ditolak" class="btn btn-danger flex-fill" onclick="return confirm('Tolak approval Finance ini?')"><i class="bi bi-x-lg"></i> Tolak</button></div></form></div></div></div></div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
