<?php
// =========================================================
// Unduh laporan HO sebagai berkas .eml (jalur cadangan)
// ----------------------------------------------------------
// Dipakai kalau mailto: tidak membuka apa-apa (mis. aplikasi dibuka
// dari ikon PWA/APK, atau Windows belum punya aplikasi email bawaan).
// Berkas .eml tinggal diklik 2x dari folder Download -> Outlook
// membukanya sebagai pesan BARU yang sudah terisi, tinggal Kirim.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';
require_login();

if (!in_array(current_user()['role'], ['admin', 'finance'], true)) {
    set_flash('danger', 'Hanya Finance/Admin yang bisa membuat berkas laporan HO.');
    redirect('/dashboard.php');
}

$id = (int)($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name
                       FROM purchases p
                       JOIN vendors v ON v.id = p.vendor_id
                       JOIN users u ON u.id = p.pic_id
                       WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase || !ho_eligible($purchase)) {
    set_flash('warning', 'Berkas laporan hanya bisa dibuat untuk tiket yang sudah Selesai / Done.');
    redirect('/finance/list.php?status=selesai');
}

$ho = ho_laporan($pdo, $purchase);
if (!$ho['siap']) {
    set_flash('warning', $ho['alasan']);
    redirect('/pembelian/detail.php?id=' . $id);
}

// Sekalian dicatat (dijeda 10 menit supaya tidak dobel kalau tombol mailto
// baru saja ditekan untuk tiket yang sama)
$cek = $pdo->prepare("SELECT created_at FROM purchase_logs
                      WHERE purchase_id = ? AND action LIKE 'Email Laporan ke HO%'
                      ORDER BY id DESC LIMIT 1");
$cek->execute([$id]);
$terakhir = $cek->fetchColumn();
if (!$terakhir || (time() - strtotime($terakhir)) > 600) {
    log_activity($pdo, $id, 'Email Laporan ke HO (' . $ho['kepada'] . ')',
        'Berkas .eml diunduh - nilai dibayarkan ' . format_rupiah(total_setelah_pajak($purchase)));
}

$namaFile = 'Laporan-HO_' . preg_replace('/[^A-Za-z0-9._-]/', '', $purchase['no_ticket']) . '.eml';
while (ob_get_level() > 0) {
    ob_end_clean();
}
header('Content-Type: message/rfc822');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
header('Cache-Control: no-store');
echo ho_eml_content($ho['kepada'], $ho['cc'], $ho['subjek'], $ho['isi']);
exit;
