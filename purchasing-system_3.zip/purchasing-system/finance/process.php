<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'finance']);
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name as vendor_name, u.name as pic_name FROM purchases p
                        JOIN vendors v ON v.id = p.vendor_id JOIN users u ON u.id = p.pic_id WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data tidak ditemukan.');
    redirect('/finance/list.php');
}
if ($purchase['status_approval'] !== 'disetujui') {
    set_flash('warning', 'Pembelian ini belum disetujui Petugas.');
    redirect('/finance/list.php');
}
if ($purchase['status_finance_approval'] !== 'disetujui') {
    set_flash('warning', 'Pembelian ini belum disetujui Finance.');
    redirect('/finance/list.php');
}
if ($purchase['status_dirops'] !== 'disetujui') {
    set_flash('warning', 'Pembelian ini belum disetujui Direktur Operasional.');
    redirect('/finance/list.php');
}
if (in_array($purchase['status_pembayaran'], ['selesai', 'dibatalkan'])) {
    set_flash('warning', 'Status pembayaran pembelian ini sudah final.');
    redirect('/pembelian/detail.php?id=' . $id);
}

$statusOptions = [
    'sudah_diajukan_ho' => 'Sudah Diajukan ke HO',
    'menunggu_pembayaran' => 'Menunggu Pembayaran',
    'sedang_diproses' => 'Sedang Diproses',
    'selesai' => 'Selesai / Done',
    'gagal' => 'Gagal',
    'dibatalkan' => 'Dibatalkan',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status_pembayaran'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');

    if (!array_key_exists($status, $statusOptions)) {
        set_flash('danger', 'Status pembayaran tidak valid.');
    } else {
        $stmt = $pdo->prepare("UPDATE purchases SET status_pembayaran=?, catatan_finance=?, processed_by=?, processed_at=NOW() WHERE id=?");
        $stmt->execute([$status, $catatan, $user['id'], $id]);

        log_activity($pdo, $id, 'Status Pembayaran: ' . $statusOptions[$status], $catatan ?: null);

        // Notifikasi ke PIC pemilik data: pembelian sudah diproses oleh Finance
        create_notification(
            $pdo,
            $purchase['pic_id'],
            "Pembelian {$purchase['no_ticket']} Anda telah diproses Finance ({$user['name']}). Status: {$statusOptions[$status]}.",
            '/pembelian/detail.php?id=' . $id,
            $id,
            'pembayaran_selesai'
        );
        notify_user_wa(
            $pdo,
            $purchase['pic_id'],
            "Info: Pembelian {$purchase['no_ticket']} Anda status pembayarannya: {$statusOptions[$status]}." . ($catatan ? " Catatan: $catatan" : ''),
            $id
        );

        // Notifikasi ke Admin sebagai pengawasan, kecuali Admin sendiri yang bertindak
        notify_role(
            $pdo,
            ['admin'],
            "Status pembayaran {$purchase['no_ticket']} diperbarui menjadi \"{$statusOptions[$status]}\" oleh {$user['name']}.",
            '/pembelian/detail.php?id=' . $id,
            $id,
            'pembayaran_selesai',
            $user['id']
        );

        // Finance tetap lapor progres pembayaran ke Dirops yang menyetujui,
        // supaya Dirops tahu apakah pembelian yang disetujuinya sudah dibayar atau belum.
        notify_role(
            $pdo,
            ['dirops'],
            "Laporan progres pembayaran {$purchase['no_ticket']} dari Finance ({$user['name']}): {$statusOptions[$status]}.",
            '/pembelian/detail.php?id=' . $id,
            $id,
            'pembayaran_selesai',
            $user['id']
        );
        notify_role_wa(
            $pdo,
            ['dirops'],
            "Laporan progres: Pembelian {$purchase['no_ticket']} yang Anda setujui - status pembayaran saat ini: {$statusOptions[$status]}." . ($catatan ? " Catatan: $catatan" : ''),
            $id
        );

        set_flash('success', "Status pembayaran {$purchase['no_ticket']} diperbarui menjadi \"{$statusOptions[$status]}\".");
        redirect('/finance/list.php');
    }
}

$pageTitle = 'Proses Pembayaran';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-cash-coin"></i> Proses Pembayaran - <?= e($purchase['no_ticket']) ?></h4>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Ringkasan Pembelian</div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr><td class="label text-success fw-semibold" style="width:45%">Tanggal</td><td><?= format_tanggal($purchase['tanggal']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">PIC</td><td><?= e($purchase['pic_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Supplier</td><td><?= e($purchase['vendor_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">No Nota</td><td><?= e($purchase['no_nota']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Total Sebelum Pajak</td><td><?= format_rupiah($purchase['total_harga']) ?></td></tr><tr><td class="label text-success fw-semibold">Total Potongan Pajak</td><td><?= format_rupiah(total_potongan_pajak($purchase)) ?></td></tr><tr><td class="label text-success fw-semibold">Total Setelah Pajak</td><td class="fw-bold"><?= format_rupiah(total_setelah_pajak($purchase)) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Status Saat Ini</td><td><?= badge_pembayaran($purchase['status_pembayaran']) ?></td></tr>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Update Status Pembayaran</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="id" value="<?= $id ?>">
          <div class="mb-3">
            <label class="form-label">Status Pembayaran</label>
            <select name="status_pembayaran" class="form-select" required>
              <?php foreach ($statusOptions as $key => $label): ?>
                <option value="<?= $key ?>" <?= $purchase['status_pembayaran'] === $key ? 'selected' : '' ?>><?= $label ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Catatan (opsional)</label>
            <textarea name="catatan" class="form-control" rows="3" placeholder="Contoh: Transfer sudah dilakukan via BCA."></textarea>
          </div>
          <button type="submit" class="btn btn-brand w-100"><i class="bi bi-save"></i> Simpan Status</button>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
