<?php
// =========================================================
// Mencatat bahwa Finance sudah mengirim email laporan ke HO.
// Dipanggil otomatis (fetch) sesaat setelah tombol email diklik,
// supaya timeline tiket punya bukti "sudah dilaporkan ke Pak Arnold".
// Tidak mengirim email apa pun di sini - emailnya lewat mailto:.
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['ok' => false, 'error' => 'Metode tidak diizinkan.'], 405);
}
if (!current_user()) {
    json_response(['ok' => false, 'error' => 'Sesi berakhir, silakan login lagi.'], 401);
}
if (!in_array(current_user()['role'], ['admin', 'finance'], true)) {
    json_response(['ok' => false, 'error' => 'Hanya Finance/Admin yang bisa mencatat laporan HO.'], 403);
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    json_response(['ok' => false, 'error' => 'ID tidak valid.'], 422);
}

$stmt = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name
                       FROM purchases p
                       JOIN vendors v ON v.id = p.vendor_id
                       JOIN users u ON u.id = p.pic_id
                       WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    json_response(['ok' => false, 'error' => 'Data pembelian tidak ditemukan.'], 404);
}
if (!ho_eligible($purchase)) {
    json_response(['ok' => false, 'error' => 'Tiket belum selesai dibayar, jadi belum bisa dilaporkan.'], 422);
}

$ho = ho_laporan($pdo, $purchase);
$kepada = $ho['siap'] ? $ho['kepada'] : 'HO';
$keterangan = 'Dikirim ke ' . $kepada . ' - nilai dibayarkan ' . format_rupiah(total_setelah_pajak($purchase))
            . ' - ' . $purchase['no_ticket'];

log_activity($pdo, $id, 'Email Laporan ke HO (' . $kepada . ')', $keterangan);

json_response(['ok' => true, 'dicatat' => date('d.m.Y H:i')]);
