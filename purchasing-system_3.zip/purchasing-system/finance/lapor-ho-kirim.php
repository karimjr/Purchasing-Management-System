<?php
// =========================================================
// Kirim email laporan HO dari server (jalur "tanpa Outlook")
// ----------------------------------------------------------
// Hanya dipakai kalau Admin menyalakan "Kirim dari server" di
// Pengaturan Email Laporan. Memakai mail() bawaan hosting, jadi
// komputer pemakai tidak perlu punya aplikasi email sama sekali.
// Kalau hosting memblokir mail(), hasilnya tetap dijelaskan ke
// pemakai (tombol cadangan .eml / mailto selalu ada).
// =========================================================

require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/laporan_ho.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    json_response(['ok' => false, 'error' => 'Metode tidak diizinkan.'], 405);
}
if (!current_user()) {
    json_response(['ok' => false, 'error' => 'Sesi berakhir, silakan login lagi.'], 401);
}
if (!in_array(current_user()['role'], ['admin', 'finance'], true)) {
    json_response(['ok' => false, 'error' => 'Hanya Finance/Admin yang bisa mengirim laporan HO.'], 403);
}

$id = (int)($_POST['id'] ?? 0);
if ($id <= 0) {
    json_response(['ok' => false, 'error' => 'ID tidak valid.'], 422);
}

$stmt = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name
                       FROM purchases p
                       JOIN vendors v ON v.id = p.vendor_id
                       JOIN users u ON u.id = p.pic_id
                       WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    json_response(['ok' => false, 'error' => 'Data pembelian tidak ditemukan.'], 404);
}

$hasil = ho_kirim_server($pdo, $purchase);
if (!$hasil['ok']) {
    json_response(['ok' => false, 'error' => $hasil['pesan']], 502);
}
json_response(['ok' => true, 'pesan' => $hasil['pesan'], 'kepada' => $hasil['kepada'], 'dicatat' => $hasil['dicatat']]);
