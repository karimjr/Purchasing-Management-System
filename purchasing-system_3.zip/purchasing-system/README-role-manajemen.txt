=========================================================
ROLE BARU: MANAJEMEN (VIEW ONLY)
=========================================================

Isi zip ini:
  - migrasi-role-manajemen.sql  -> jalankan dulu di phpMyAdmin
  - includes/functions.php      -> (ditimpa)
  - includes/sidebar.php        -> (ditimpa)
  - users/add.php               -> (ditimpa)
  - users/edit.php              -> (ditimpa)
  - pembelian/list.php          -> (ditimpa)
  - harga-harian/list.php       -> (ditimpa)
  - vendors/list.php            -> (ditimpa)
  - README-role-manajemen.txt   -> file ini

---------------------------------------------------------
APA YANG DIUBAH
---------------------------------------------------------
Role "Manajemen" ditambahkan khusus untuk Arnold, Tomo,
Dewi, Ayu, Martha. Hak aksesnya:

  BISA:
  - Dashboard (ringkasan umum)
  - Daftar Pembelian + detail tiket  (LIAT SAJA -
    tidak ada tombol Tambah/Edit/Hapus)
  - Harga Harian                     (lihat saja)
  - Data Supplier                    (lihat saja)
  - Rekapitulasi + Rekap Beres + export Excel/PDF
  - Notifikasi

  TIDAK BISA:
  - Tambah/edit/hapus pembelian (termasuk lewat API HP)
  - Approval (Petugas & Dirops)
  - Pembayaran Finance & Voucher
  - Menetapkan/hapus harga harian
  - Kelola supplier, user, dan pengaturan
  - Halaman Rekap tidak bisa dipakai untuk mengubah apa pun
    (halaman rekap memang hanya menampilkan)

---------------------------------------------------------
CARA PASANG (urutan penting)
---------------------------------------------------------
  LANGKAH 1 - DATABASE:
  Buka phpMyAdmin -> database potensib_purchasing_db ->
  tab Import -> pilih migrasi-role-manajemen.sql -> Go

  Efek:
  - kolom role di tabel users bertambah nilai 'manajemen'
  - 5 akun (arnold, tomo, dewi, ayu, martha) yang tadinya
    role PIC otomatis diubah jadi MANAJEMEN

  LANGKAH 2 - FILE:
  Salin 7 file .php di atas ke lokasi yang sama di hosting
  (struktur foldernya sudah sesuai).

Selesai. Tidak perlu login ulang yang sudah masuk; kalau
perlu, logout-login lagi supaya role barunya terbaca.

---------------------------------------------------------
CATATAN
---------------------------------------------------------
  - Aman dijalankan ulang (idempotent).
  - Kalau 5 akun BELUM dibuat di database kamu, pakai juga
    zip AKUN-PIC (versi terbaru) yang sudah membuat akun
    langsung dengan role manajemen + password acak.
  - Nanti kalau ada orang baru yang perlu role sama,
    cukup: Manajemen User -> Tambah User -> role pilih
    "Manajemen (lihat laporan & data, tanpa input)".
