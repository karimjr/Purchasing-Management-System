<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'dirops']);
$pageTitle = 'Approval Direktur Operasional';

$filter = $_GET['status'] ?? 'menunggu';
$allowed = ['menunggu', 'disetujui', 'ditolak', 'semua'];
if (!in_array($filter, $allowed)) $filter = 'menunggu';

// Dirops hanya menangani pembelian yang sudah disetujui Petugas terlebih dahulu.
$sql = "SELECT p.*, v.name as vendor_name, u.name as pic_name, a.name as approved_by_name
        FROM purchases p
        JOIN vendors v ON v.id = p.vendor_id
        JOIN users u ON u.id = p.pic_id
        LEFT JOIN users a ON a.id = p.approved_by
        WHERE p.status_approval = 'disetujui' AND p.status_finance_approval = 'disetujui'";
$params = [];
if ($filter !== 'semua') {
    $sql .= " AND p.status_dirops = ?";
    $params[] = $filter;
}
$sql .= " ORDER BY p.approved_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$purchases = $stmt->fetchAll();

$waUsersByRole = [
    'petugas' => get_users_with_wa($pdo, ['petugas']),
    'dirops'  => get_users_with_wa($pdo, ['dirops']),
    'finance' => get_users_with_wa($pdo, ['finance']),
];

include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-person-check"></i> Approval Direktur Operasional</h4>
<p class="text-muted small mt-n2">Daftar pembelian yang sudah disetujui Petugas dan Finance. Finance akan menindaklanjuti hasil approval Anda untuk proses pembayaran. Data yang sudah diproses tetap tersedia pada tab Disetujui, dengan tombol WhatsApp untuk menginformasikan hasilnya kepada Finance.</p>

<ul class="nav nav-pills mb-4">
  <?php foreach (['menunggu' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak', 'semua' => 'Semua'] as $key => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?= $filter === $key ? 'active bg-success' : 'text-dark' ?>" href="?status=<?= $key ?>"><?= $label ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<div class="table-responsive">
  <table class="table table-hover align-middle bg-white">
    <thead class="table-light">
      <tr>
        <th>No Ticket</th>
        <th>Tanggal</th>
        <th>PIC</th>
        <th>Supplier</th>
        <th>Berat Basah</th>
        <th>Harga Pembayaran</th>
        <th>Disetujui Petugas Oleh</th>
        <th>Status Dirops</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($purchases)): ?>
        <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada data.</td></tr>
      <?php else: foreach ($purchases as $row): ?>
        <tr>
          <td><?= e($row['no_ticket']) ?></td>
          <td><?= format_tanggal($row['tanggal']) ?></td>
          <td><?= e($row['pic_name']) ?></td>
          <td><?= e($row['vendor_name']) ?></td>
          <td><?= e($row['berat_basah']) ?> KG</td>
          <td><?= format_rupiah($row['total_harga']) ?></td>
          <td><?= e($row['approved_by_name']) ?></td>
          <td><?= badge_dirops($row['status_dirops']) ?></td>
          <td>
            <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary" title="Detail"><i class="bi bi-eye"></i></a>
            <?php if ($row['status_dirops'] === 'menunggu'): ?>
              <a href="<?= BASE_URL ?>/dirops/process.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-brand" title="Proses"><i class="bi bi-check2-square"></i> Proses</a>
            <?php else: ?>
              <?= render_wa_button($row, $waUsersByRole) ?>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
