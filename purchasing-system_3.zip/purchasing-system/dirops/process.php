<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'dirops']);
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT p.*, v.name as vendor_name, u.name as pic_name, a.name as approved_by_name FROM purchases p
                        JOIN vendors v ON v.id = p.vendor_id JOIN users u ON u.id = p.pic_id
                        LEFT JOIN users a ON a.id = p.approved_by WHERE p.id = ?");
$stmt->execute([$id]);
$purchase = $stmt->fetch();

if (!$purchase) {
    set_flash('danger', 'Data tidak ditemukan.');
    redirect('/dirops/list.php');
}
if ($purchase['status_approval'] !== 'disetujui' || $purchase['status_finance_approval'] !== 'disetujui') {
    set_flash('warning', 'Pembelian ini harus disetujui Petugas dan Finance terlebih dahulu.');
    redirect('/dirops/list.php');
}
if ($purchase['status_dirops'] !== 'menunggu') {
    set_flash('warning', 'Pembelian ini sudah diproses sebelumnya oleh Dirops.');
    redirect('/pembelian/detail.php?id=' . $id);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $decision = $_POST['decision'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');

    if (!in_array($decision, ['disetujui', 'ditolak'])) {
        set_flash('danger', 'Keputusan tidak valid.');
    } elseif ($catatan === '') {
        set_flash('danger', 'Catatan wajib diisi untuk keputusan approval Direktur Operasional.');
    } else {
        // Setelah disetujui Dirops, barulah Finance bisa memproses pembayarannya.
        $statusPembayaran = $decision === 'disetujui' ? 'menunggu_pembayaran' : 'belum_diajukan';
        $stmt = $pdo->prepare("UPDATE purchases SET status_dirops=?, catatan_dirops=?, dirops_by=?, dirops_at=NOW(), status_pembayaran=?, last_reminder_stage=NULL, last_reminder_at=NULL WHERE id=?");
        $stmt->execute([$decision, $catatan, $user['id'], $statusPembayaran, $id]);

        $label = $decision === 'disetujui' ? 'Disetujui oleh Dirops' : 'Ditolak oleh Dirops';
        log_activity($pdo, $id, $label, $catatan);

        $decisionLabel = $decision === 'disetujui' ? 'disetujui' : 'ditolak';

        // Notifikasi ke PIC pemilik data
        create_notification(
            $pdo, $purchase['pic_id'],
            "Pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Direktur Operasional ({$user['name']}). Catatan: $catatan",
            '/pembelian/detail.php?id=' . $id, $id, 'dirops_selesai'
        );
        notify_user_wa(
            $pdo, $purchase['pic_id'],
            "Info: Pembelian {$purchase['no_ticket']} Anda telah $decisionLabel oleh Direktur Operasional ({$user['name']}). Catatan: $catatan",
            $id
        );

        // Dirops hanya memberikan keputusan; hasilnya dikabarkan kepada Finance.
        if ($decision === 'disetujui') {
            notify_role(
                $pdo, ['finance', 'admin'],
                "Pembelian {$purchase['no_ticket']} telah disetujui Direktur Operasional dan siap diproses pembayarannya. Catatan: $catatan",
                '/pembelian/detail.php?id=' . $id, $id, 'pembayaran_menunggu', $user['id']
            );
            notify_role_wa(
                $pdo, ['finance'],
                "Permisi Bapak/Ibu Finance, terkait tiket pembelian {$purchase['no_ticket']} dari PIC {$purchase['pic_name']} (Supplier: {$purchase['vendor_name']}, Nilai: " . format_rupiah($purchase['total_harga']) . "), telah saya setujui. Silakan dilanjutkan ke proses pembayaran sesuai prosedur. Mohon dibantu memperbarui statusnya apabila sudah diajukan ke HO, sedang diproses, selesai, atau terdapat kendala. Catatan: $catatan",
                $id
            );
        } else {
            notify_role(
                $pdo, ['finance', 'admin'],
                "Pembelian {$purchase['no_ticket']} ditolak oleh Direktur Operasional ({$user['name']}). Catatan: $catatan",
                '/pembelian/detail.php?id=' . $id, $id, 'dirops_selesai', $user['id']
            );
            notify_role_wa(
                $pdo, ['finance'],
                "Info: Pembelian {$purchase['no_ticket']} DITOLAK oleh Direktur Operasional. Catatan: $catatan",
                $id
            );
        }

        set_flash('success', "Pembelian {$purchase['no_ticket']} telah $decision oleh Dirops.");
        redirect('/dirops/list.php?status=' . ($decision === 'disetujui' ? 'disetujui' : 'ditolak'));
    }
}

$pageTitle = 'Proses Approval Dirops';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-person-check"></i> Proses Approval Dirops - <?= e($purchase['no_ticket']) ?></h4>

<div class="row g-4">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Ringkasan Pembelian</div>
      <div class="card-body">
        <table class="table table-borderless mb-0">
          <tr><td class="label text-success fw-semibold" style="width:45%">Tanggal</td><td><?= format_tanggal($purchase['tanggal']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">PIC</td><td><?= e($purchase['pic_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Supplier</td><td><?= e($purchase['vendor_name']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">No Nota</td><td><?= e($purchase['no_nota']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Berat Basah</td><td><?= e($purchase['berat_basah']) ?> KG</td></tr>
          <tr><td class="label text-success fw-semibold">DRC</td><td><?= e($purchase['drc']) ?> %</td></tr>
          <tr><td class="label text-success fw-semibold">Harga Basah</td><td><?= format_rupiah($purchase['harga_basah']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Harga Pembayaran</td><td class="fw-bold"><?= format_rupiah($purchase['total_harga']) ?></td></tr>
          <tr><td class="label text-success fw-semibold">Disetujui Petugas</td><td><?= e($purchase['approved_by_name']) ?> &middot; <?= format_tanggal_waktu($purchase['approved_at']) ?></td></tr>
          <?php if ($purchase['catatan_approval']): ?>
            <tr><td class="label text-success fw-semibold">Catatan Petugas</td><td><?= e($purchase['catatan_approval']) ?></td></tr>
          <?php endif; ?>
        </table>
        <?php
        // v12: peninjau melihat SEMUA berkas tiket (foto utama + dokumen pendukung),
        // tidak hanya purchases.foto. Tampilan dipakai dari helper yang sama dengan
        // halaman detail, jadi tidak bisa beda-beda kalau aturannya diubah.
        $fotosTiket = purchase_fotos($pdo, $purchase);
        if ($fotosTiket) {
            echo foto_galeri_html($fotosTiket, ['purchase_id' => $id]);
        } ?>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-white fw-bold">Keputusan Dirops</div>
      <div class="card-body">
        <form method="POST">
          <input type="hidden" name="id" value="<?= $id ?>">
          <div class="mb-3">
            <label class="form-label">Catatan <span class="text-danger">*</span> <span class="text-muted fw-normal">(wajib diisi)</span></label>
            <textarea name="catatan" class="form-control" rows="3" placeholder="Contoh: Disetujui, sesuai anggaran operasional." required></textarea>
          </div>
          <div class="d-flex gap-2">
            <button type="submit" name="decision" value="disetujui" class="btn btn-success flex-fill">
              <i class="bi bi-check-lg"></i> Setujui
            </button>
            <button type="submit" name="decision" value="ditolak" class="btn btn-danger flex-fill" onclick="return confirm('Tolak pembelian ini?')">
              <i class="bi bi-x-lg"></i> Tolak
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
