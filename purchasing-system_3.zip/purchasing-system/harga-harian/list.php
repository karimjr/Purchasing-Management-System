<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'petugas', 'pic', 'finance', 'dirops', 'manajemen']);
$user = current_user();
$pageTitle = 'Harga Harian (Notaring)';
$canManage = in_array($user['role'], ['admin', 'petugas']);

$prices = $pdo->query("SELECT dp.*, u.name as set_by_name FROM daily_prices dp
                        JOIN users u ON u.id = dp.set_by
                        ORDER BY dp.tanggal DESC")->fetchAll();

// Harga hari ini (untuk ditonjolkan di atas)
$todayStmt = $pdo->prepare("SELECT dp.*, u.name as set_by_name FROM daily_prices dp
                             JOIN users u ON u.id = dp.set_by WHERE dp.tanggal = CURDATE() ORDER BY dp.daerah");
$todayStmt->execute();
$todayPrices = $todayStmt->fetchAll();

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-tag"></i> Harga Harian (Notaring / Kering)</h4>
  <?php if ($canManage): ?>
    <a href="<?= BASE_URL ?>/harga-harian/set.php" class="btn btn-brand">
      <i class="bi bi-plus-lg"></i> Tetapkan / Update Harga
    </a>
  <?php endif; ?>
</div>
<p class="text-muted small mt-n2">Harga ini dipakai sistem untuk menghitung <strong>DRC</strong> setiap pembelian: DRC = Harga Basah &divide; Harga Harian (Notaring) &times; 100%.</p>

<div class="card mb-4" style="border-left:4px solid #1e8449;">
  <div class="card-body">
    <span class="label d-block text-success fw-semibold">Harga Hari Ini (<?= format_tanggal(date('Y-m-d')) ?>)</span>
    <?php if ($todayPrices): ?>
      <div class="row g-2">
        <?php foreach ($todayPrices as $todayPrice): ?>
          <div class="col-md-4"><div class="border rounded p-2 h-100"><div class="small text-success fw-semibold"><?= e($todayPrice['daerah']) ?></div><div class="fs-4 fw-bold"><?= format_rupiah($todayPrice['harga']) ?> / KG</div><div class="small text-muted">Ditetapkan oleh <?= e($todayPrice['set_by_name']) ?> �� <?= format_tanggal_waktu($todayPrice['updated_at']) ?></div><?php if ($todayPrice['catatan']): ?><div class="small text-muted">Catatan: <?= e($todayPrice['catatan']) ?></div><?php endif; ?></div></div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="text-muted">Belum ada harga yang ditetapkan untuk hari ini.
        <?php if ($canManage): ?>
          <a href="<?= BASE_URL ?>/harga-harian/set.php">Tetapkan sekarang</a>.
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <div class="card-header bg-white fw-bold">Riwayat Harga Harian</div>
  <div class="table-responsive">
    <table class="table table-hover mb-0 align-middle">
      <thead class="table-light">
        <tr>
          <th>Tanggal</th>
          <th>Daerah</th>
          <th>Harga / KG</th>
          <th>Catatan</th>
          <th>Ditetapkan Oleh</th>
          <th>Terakhir Diubah</th>
          <?php if ($canManage): ?><th></th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($prices)): ?>
          <tr><td colspan="7" class="text-center text-muted py-4">Belum ada data harga harian.</td></tr>
        <?php else: foreach ($prices as $row): ?>
          <tr>
            <td><?= format_tanggal($row['tanggal']) ?></td>
            <td><?= e($row['daerah']) ?></td>
            <td class="fw-semibold"><?= format_rupiah($row['harga']) ?></td>
            <td><?= e($row['catatan'] ?: '-') ?></td>
            <td><?= e($row['set_by_name']) ?></td>
            <td><?= format_tanggal_waktu($row['updated_at']) ?></td>
            <?php if ($canManage): ?>
              <td class="text-nowrap"><a href="<?= BASE_URL ?>/harga-harian/set.php?tanggal=<?= e($row['tanggal']) ?>&daerah=<?= rawurlencode($row['daerah']) ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a> <a href="<?= BASE_URL ?>/harga-harian/delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" title="Hapus"><i class="bi bi-trash"></i></a></td>
            <?php endif; ?>
          </tr>
        <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
