<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'petugas']);
$user = current_user();
$areas = $pdo->query("SELECT DISTINCT daerah FROM daily_prices WHERE daerah <> '' ORDER BY daerah")->fetchAll(PDO::FETCH_COLUMN);

$tanggal = $_GET['tanggal'] ?? $_POST['tanggal'] ?? date('Y-m-d');
$daerah = trim($_GET['daerah'] ?? $_POST['daerah'] ?? 'Umum');
if (($_POST['daerah_mode'] ?? '') === '__baru__') $daerah = trim($_POST['daerah_baru'] ?? '');

$stmt = $pdo->prepare("SELECT * FROM daily_prices WHERE tanggal = ? AND daerah = ?");
$stmt->execute([$tanggal, $daerah]);
$existing = $stmt->fetch();

$errors = [];
$form = [
    'tanggal' => $tanggal,
    'daerah' => $daerah,
    'harga' => $existing['harga'] ?? '',
    'catatan' => $existing['catatan'] ?? '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form['tanggal'] = $_POST['tanggal'] ?? '';
    $form['daerah'] = trim($_POST['daerah'] ?? 'Umum');
    $form['harga'] = $_POST['harga'] ?? '';
    $form['catatan'] = trim($_POST['catatan'] ?? '');

    if ($form['tanggal'] === '') $errors[] = 'Tanggal wajib diisi.';
    if ($form['daerah'] === '') $errors[] = 'Daerah wajib dipilih atau diisi.';
    if ($form['harga'] === '' || !is_numeric($form['harga']) || $form['harga'] <= 0) $errors[] = 'Harga wajib diisi dengan angka lebih dari 0.';

    if (empty($errors)) {
        $checkStmt = $pdo->prepare("SELECT id FROM daily_prices WHERE tanggal = ? AND daerah = ?");
        $checkStmt->execute([$form['tanggal'], $form['daerah']]);
        $row = $checkStmt->fetch();

        if ($row) {
            $upd = $pdo->prepare("UPDATE daily_prices SET daerah=?, harga=?, catatan=?, set_by=? WHERE id=?");
            $upd->execute([$form['daerah'], $form['harga'], $form['catatan'] ?: null, $user['id'], $row['id']]);
            set_flash('success', 'Harga harian tanggal ' . format_tanggal($form['tanggal']) . ' berhasil diperbarui.');
        } else {
            $ins = $pdo->prepare("INSERT INTO daily_prices (tanggal, daerah, harga, catatan, set_by) VALUES (?, ?, ?, ?, ?)");
            $ins->execute([$form['tanggal'], $form['daerah'], $form['harga'], $form['catatan'] ?: null, $user['id']]);
            set_flash('success', 'Harga harian tanggal ' . format_tanggal($form['tanggal']) . ' berhasil ditetapkan.');
        }
        redirect('/harga-harian/list.php');
    }
}

$pageTitle = 'Tetapkan Harga Harian';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-tag"></i> Tetapkan / Update Harga Harian</h4>

<div id="connStatus" class="alert py-2 px-3 mb-3 d-flex align-items-center gap-2" style="display:none!important;">
  <span id="connStatusIcon"></span>
  <span id="connStatusText"></span>
</div>

<div id="pendingPanel" class="card mb-3" style="display:none;">
  <div class="card-body">
    <div class="d-flex justify-content-between align-items-center mb-2">
      <h6 class="mb-0"><i class="bi bi-cloud-upload"></i> Harga Belum Terkirim (<span id="pendingCount">0</span>)</h6>
      <button type="button" class="btn btn-sm btn-outline-secondary" id="syncNowBtn">
        <i class="bi bi-arrow-repeat"></i> Kirim Sekarang
      </button>
    </div>
    <div id="pendingList" class="list-group list-group-flush small"></div>
  </div>
</div>

<?php if ($errors): ?>
  <div class="alert alert-danger"><ul class="mb-0"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="card" style="max-width:560px;">
  <div class="card-body">
    <form method="POST" id="hargaForm">
      <div class="mb-3">
        <label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" id="tanggalInput" class="form-control" value="<?= e($form['tanggal']) ?>" required>
        <div class="form-text" id="tanggalHint">Ganti tanggal untuk melihat/mengubah harga di tanggal lain (perlu online).</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Daerah / Jenis Harga Notaring</label>
        <select name="daerah_mode" id="daerahMode" class="form-select" required>
          <?php foreach ($areas as $area): ?>
            <option value="<?= e($area) ?>" <?= $form['daerah'] === $area ? 'selected' : '' ?>>Harga Notaring <?= e($area) ?></option>
          <?php endforeach; ?>
          <option value="__baru__" <?= !in_array($form['daerah'], $areas, true) ? 'selected' : '' ?>>+ Tambah lagi</option>
        </select>
        <input type="text" name="daerah_baru" id="daerahBaru" class="form-control mt-2" value="<?= !in_array($form['daerah'], $areas, true) ? e($form['daerah']) : '' ?>" placeholder="Tulis nama daerah baru, contoh: Aceh Selatan" <?= in_array($form['daerah'], $areas, true) ? 'disabled' : 'required' ?>>
        <input type="hidden" name="daerah" id="daerahFinal" value="<?= e($form['daerah']) ?>">
        <div class="form-text">Pilih harga yang ingin diedit, atau pilih <strong>Tambah lagi</strong> untuk membuat daerah baru.</div>
      </div>
      <div class="mb-3">
        <label class="form-label">Harga per KG (Rp)</label>
        <input type="number" step="0.01" name="harga" id="hargaInput" class="form-control" value="<?= e($form['harga']) ?>" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Catatan (opsional)</label>
        <input type="text" name="catatan" id="catatanInput" class="form-control" value="<?= e($form['catatan']) ?>" placeholder="Contoh: Harga naik karena DRC tinggi">
      </div>
      <div class="d-flex gap-2">
        <button type="submit" class="btn btn-brand"><i class="bi bi-save"></i> Simpan Harga</button>
        <a href="<?= BASE_URL ?>/harga-harian/list.php" class="btn btn-outline-secondary">Batal</a>
      </div>
    </form>
  </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/offline-queue.js"></script>
<script>
const tanggalInput = document.getElementById('tanggalInput');
const hargaForm = document.getElementById('hargaForm');
const tanggalHint = document.getElementById('tanggalHint');
const daerahMode = document.getElementById('daerahMode');
const daerahBaru = document.getElementById('daerahBaru');
const daerahFinal = document.getElementById('daerahFinal');
function syncDaerah() {
  const isNew = daerahMode.value === '__baru__';
  daerahBaru.disabled = !isNew;
  daerahBaru.required = isNew;
  daerahBaru.classList.toggle('d-none', !isNew);
  daerahFinal.value = isNew ? daerahBaru.value.trim() : daerahMode.value;
}
daerahMode.addEventListener('change', syncDaerah);
daerahBaru.addEventListener('input', syncDaerah);
syncDaerah();

// Ganti tanggal = reload data (perlu online). Kalau offline, jangan reload -
// biarkan Petugas tetap bisa isi harga baru untuk tanggal itu secara offline.
tanggalInput.addEventListener('change', function () {
  if (navigator.onLine) {
    hargaForm.submit();
  } else {
    tanggalHint.innerHTML = '<span class="text-warning">Sedang offline - tidak bisa cek harga lama untuk tanggal ini. Isi harga barunya saja, nanti otomatis menimpa saat tersinkron.</span>';
  }
});

// =========================================================
// Mode Offline: simpan di HP kalau gak ada internet, auto-kirim kalau online
// =========================================================
const connStatus = document.getElementById('connStatus');
const connStatusIcon = document.getElementById('connStatusIcon');
const connStatusText = document.getElementById('connStatusText');

function renderConnStatus() {
  connStatus.style.setProperty('display', 'flex', 'important');
  if (navigator.onLine) {
    connStatus.className = 'alert alert-success py-2 px-3 mb-3 d-flex align-items-center gap-2';
    connStatusIcon.innerHTML = '<i class="bi bi-wifi"></i>';
    connStatusText.textContent = 'Online - data akan langsung tersimpan ke server.';
  } else {
    connStatus.className = 'alert alert-warning py-2 px-3 mb-3 d-flex align-items-center gap-2';
    connStatusIcon.innerHTML = '<i class="bi bi-wifi-off"></i>';
    connStatusText.textContent = 'Tidak ada koneksi internet - harga akan disimpan dulu di HP dan otomatis terkirim nanti.';
  }
}
window.addEventListener('online', () => { renderConnStatus(); renderPendingPanel(); });
window.addEventListener('offline', renderConnStatus);
renderConnStatus();

const pendingPanel = document.getElementById('pendingPanel');
const pendingCount = document.getElementById('pendingCount');
const pendingList = document.getElementById('pendingList');

function statusBadge(status) {
  const map = {
    pending: '<span class="badge text-bg-secondary">Menunggu sinyal</span>',
    syncing: '<span class="badge text-bg-info">Mengirim...</span>',
    error: '<span class="badge text-bg-danger">Gagal - perlu dicek</span>',
  };
  return map[status] || map.pending;
}

async function renderPendingPanel() {
  const items = await OfflineQueue.getAllPendingHargaHarian();
  pendingCount.textContent = items.length;
  pendingPanel.style.display = items.length ? 'block' : 'none';
  pendingList.innerHTML = '';
  items.sort((a, b) => b.created_at - a.created_at).forEach((item) => {
    const div = document.createElement('div');
    div.className = 'list-group-item d-flex justify-content-between align-items-start';
    div.innerHTML =
      '<div>' +
        '<div><strong>' + item.tanggal + '</strong> &middot; Rp ' + Number(item.harga).toLocaleString('id-ID') + '/KG</div>' +
        (item.catatan ? '<div class="text-muted">' + item.catatan + '</div>' : '') +
        (item.error_message ? '<div class="text-danger small mt-1">' + item.error_message + '</div>' : '') +
      '</div>' +
      '<div class="text-end">' + statusBadge(item.status) + '</div>';
    pendingList.appendChild(div);
  });
}

document.getElementById('syncNowBtn').addEventListener('click', async () => {
  await OfflineQueue.syncAll();
  renderPendingPanel();
});

hargaForm.addEventListener('submit', function (e) {
  if (navigator.onLine) {
    return; // online seperti biasa, form diproses PHP di halaman ini
  }
  e.preventDefault();

  const record = {
    tanggal: tanggalInput.value,
    daerah: document.querySelector('[name=daerah]').value,
    harga: document.getElementById('hargaInput').value,
    catatan: document.getElementById('catatanInput').value,
  };

  if (!record.tanggal || !record.harga) {
    alert('Mohon isi tanggal dan harga sebelum disimpan offline.');
    return;
  }

  OfflineQueue.enqueueHargaHarian(record).then(() => {
    alert('Tidak ada internet. Harga sudah disimpan di HP dan akan otomatis terkirim begitu ada sinyal.');
    renderPendingPanel();
  });
});

renderPendingPanel();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
