<?php
require_once __DIR__ . '/../includes/init.php';
require_role(['admin', 'petugas']);

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM daily_prices WHERE id = ?");
$stmt->execute([$id]);
$price = $stmt->fetch();

if (!$price) {
    set_flash('danger', 'Harga harian tidak ditemukan.');
    redirect('/harga-harian/list.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $del = $pdo->prepare("DELETE FROM daily_prices WHERE id = ?");
    $del->execute([$id]);
    set_flash('success', 'Harga daerah ' . $price['daerah'] . ' untuk tanggal ' . format_tanggal($price['tanggal']) . ' berhasil dihapus.');
    redirect('/harga-harian/list.php');
}

$pageTitle = 'Hapus Harga Harian';
include __DIR__ . '/../includes/header.php';
?>
<div class="card" style="max-width:560px;">
  <div class="card-header bg-white fw-bold">Konfirmasi Hapus Harga</div>
  <div class="card-body">
    <p>Hapus harga harian berikut?</p>
    <dl class="row">
      <dt class="col-4">Tanggal</dt><dd class="col-8"><?= format_tanggal($price['tanggal']) ?></dd>
      <dt class="col-4">Daerah</dt><dd class="col-8"><?= e($price['daerah']) ?></dd>
      <dt class="col-4">Harga</dt><dd class="col-8"><?= format_rupiah($price['harga']) ?></dd>
    </dl>
    <div class="alert alert-warning small">Data pembelian yang sudah tersimpan tidak berubah karena harga disimpan sebagai snapshot.</div>
    <form method="POST" class="d-flex gap-2">
      <input type="hidden" name="id" value="<?= $id ?>">
      <button type="submit" class="btn btn-danger"><i class="bi bi-trash"></i> Hapus</button>
      <a href="<?= BASE_URL ?>/harga-harian/list.php" class="btn btn-outline-secondary">Batal</a>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>