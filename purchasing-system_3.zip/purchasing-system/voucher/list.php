<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/voucher.php';
require_role(['admin', 'finance', 'dirops']);
$user = current_user();
$canCreate = in_array($user['role'], ['admin', 'finance']);
$pageTitle = 'Voucher Pembayaran';
$tersedia = voucher_tersedia($pdo);

$filter = $_GET['status'] ?? 'belum';
if (!in_array($filter, ['belum', 'sudah', 'semua'], true)) $filter = 'belum';
$q = trim($_GET['q'] ?? '');

$purchases = [];
if ($tersedia) {
    $sql = "SELECT p.*, v.name AS vendor_name, pv.voucher_no, pv.voucher_date
            FROM purchases p
            JOIN vendors v ON v.id = p.vendor_id
            LEFT JOIN payment_vouchers pv ON pv.purchase_id = p.id
            WHERE p.status_approval = 'disetujui' AND p.status_finance_approval = 'disetujui'
              AND p.status_dirops = 'disetujui' AND p.status_pembayaran <> 'dibatalkan'";
    $params = [];
    if ($filter === 'belum') $sql .= " AND pv.id IS NULL";
    if ($filter === 'sudah') $sql .= " AND pv.id IS NOT NULL";
    if ($q !== '') {
        $sql .= " AND (p.no_ticket LIKE ? OR v.name LIKE ? OR pv.voucher_no LIKE ? OR p.daerah LIKE ?)";
        $like = '%' . $q . '%';
        array_push($params, $like, $like, $like, $like);
    }
    $sql .= " ORDER BY COALESCE(pv.id, 0) DESC, p.id DESC LIMIT 300";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $purchases = $stmt->fetchAll();
}

include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-2">
  <h4 class="mb-0"><i class="bi bi-receipt"></i> Voucher Pembayaran</h4>
</div>
<p class="text-muted small">Voucher dibuat per tiket yang sudah disetujui Petugas, Finance, dan Dirops. Satu tiket = satu voucher.</p>

<?php if (!$tersedia): ?>
  <div class="alert alert-warning">
    <strong>Tabel voucher belum ada.</strong> Jalankan berkas <code>migration_v13_voucher.sql</code> sekali di phpMyAdmin
    (database &rarr; tab SQL), lalu muat ulang halaman ini. Data lama tidak terpengaruh.
  </div>
<?php else: ?>

<ul class="nav nav-pills mb-3">
  <?php foreach (['belum' => 'Belum Dibuat Voucher', 'sudah' => 'Sudah Ada Voucher', 'semua' => 'Semua'] as $k => $label): ?>
    <li class="nav-item">
      <a class="nav-link <?= $filter === $k ? 'active bg-success' : 'text-dark' ?>" href="?status=<?= $k ?>&q=<?= urlencode($q) ?>"><?= $label ?></a>
    </li>
  <?php endforeach; ?>
</ul>

<form method="GET" class="row g-2 mb-3">
  <input type="hidden" name="status" value="<?= e($filter) ?>">
  <div class="col-md-5"><input type="text" name="q" value="<?= e($q) ?>" class="form-control" placeholder="Cari no tiket / supplier / daerah / no voucher"></div>
  <div class="col-auto"><button class="btn btn-brand"><i class="bi bi-search"></i> Cari</button></div>
  <?php if ($q !== ''): ?><div class="col-auto"><a class="btn btn-outline-secondary" href="?status=<?= e($filter) ?>">Reset</a></div><?php endif; ?>
</form>

<div class="table-responsive">
  <table class="table table-hover align-middle bg-white">
    <thead class="table-light">
      <tr>
        <th>No Voucher</th><th>No Ticket</th><th>Tanggal Tiket</th><th>Supplier</th><th>Daerah</th>
        <th class="text-end">Sebelum Pajak</th><th class="text-end">Potongan Pajak</th><th class="text-end">Total Amount</th><th></th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($purchases)): ?>
        <tr><td colspan="9" class="text-center text-muted py-4">Tidak ada data.</td></tr>
      <?php else: foreach ($purchases as $row):
        $potong = total_potongan_pajak($row); ?>
        <tr>
          <td><?php if ($row['voucher_no']): ?><span class="fw-semibold"><?= e($row['voucher_no']) ?></span><div class="small text-muted"><?= format_tanggal($row['voucher_date']) ?></div><?php else: ?><span class="badge text-bg-light border text-muted">Belum dibuat</span><?php endif; ?></td>
          <td><?= e($row['no_ticket']) ?></td>
          <td><?= format_tanggal($row['tanggal']) ?></td>
          <td><?= e($row['vendor_name']) ?></td>
          <td><?= e($row['daerah']) ?></td>
          <td class="text-end"><?= format_rupiah($row['total_harga']) ?></td>
          <td class="text-end"><?= format_rupiah($potong) ?></td>
          <td class="text-end fw-semibold"><?= format_rupiah((float)$row['total_harga'] - $potong) ?></td>
          <td class="text-nowrap">
            <?php if ($row['voucher_no']): ?>
              <a href="<?= BASE_URL ?>/voucher/lihat.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-outline-success"><i class="bi bi-eye"></i> Lihat / Cetak</a>
            <?php elseif ($canCreate): ?>
              <a href="<?= BASE_URL ?>/voucher/buat.php?id=<?= (int)$row['id'] ?>" class="btn btn-sm btn-brand"><i class="bi bi-plus-lg"></i> Buat Voucher</a>
            <?php else: ?><span class="text-muted small">-</span><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../includes/footer.php'; ?>
