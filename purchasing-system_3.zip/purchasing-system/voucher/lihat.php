<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/voucher.php';
require_role(['admin', 'finance', 'dirops']);
$user = current_user();
$id = (int)($_GET['id'] ?? 0);
$v = $id ? voucher_ambil($pdo, $id) : null;
if (!$v) {
    set_flash('warning', 'Voucher untuk tiket ini belum dibuat.');
    redirect(in_array($user['role'], ['admin', 'finance']) && $id ? '/voucher/buat.php?id=' . $id : '/voucher/list.php');
}

$tiket      = voucher_ambil_tiket($pdo, $id);
$dibuatOleh = voucher_nama_user($pdo, $v['created_by']);

// Halaman cetak polos (tanpa menu aplikasi) - langsung membuka dialog cetak
if (!empty($_GET['cetak'])) {
    ?><!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title><?= e(voucher_nama_berkas($v)) ?></title>
<style>
  @page { size: A4 portrait; margin: 12mm; }
  body { margin: 0; padding: 24px; background: #fff; }
  .vc-wrap { max-width: none; }
  .no-print { margin-bottom: 18px; font-family: Arial, sans-serif; }
  @media print { .no-print { display: none; } body { padding: 0; }
                 .vc-table th, .vc-table td, .vc-meta>div, .vc-rinc>div, .vc-terbilang {
                   -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
  <?= voucher_css() ?>
</style></head>
<body>
<div class="no-print">
  <button onclick="window.print()">Cetak / Simpan PDF</button>
  <button onclick="window.close()">Tutup</button>
</div>
<?= voucher_html($v, $tiket, $dibuatOleh) ?>
<script>window.addEventListener('load', function () { setTimeout(function () { window.print(); }, 300); });</script>
</body></html><?php
    exit;
}

$pageTitle = 'Voucher ' . $v['voucher_no'];
include __DIR__ . '/../includes/header.php';
?>
<style><?= voucher_css() ?></style>

<div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
  <h4 class="mb-0"><i class="bi bi-receipt"></i> Voucher Pembayaran</h4>
  <div class="d-flex gap-2 flex-wrap">
    <a href="<?= BASE_URL ?>/voucher/lihat.php?id=<?= $id ?>&cetak=1" target="_blank" rel="noopener" class="btn btn-brand"><i class="bi bi-printer"></i> Cetak</a>
    <a href="<?= BASE_URL ?>/voucher/export.php?id=<?= $id ?>&export=pdf" class="btn btn-outline-danger"><i class="bi bi-file-earmark-pdf"></i> Unduh PDF</a>
    <a href="<?= BASE_URL ?>/voucher/export.php?id=<?= $id ?>&export=xlsx" class="btn btn-outline-success"><i class="bi bi-file-earmark-excel"></i> Unduh Excel</a>
    <a href="<?= BASE_URL ?>/voucher/list.php?status=sudah" class="btn btn-outline-secondary">Kembali</a>
  </div>
</div>

<div class="card mb-3">
  <div class="card-body" style="overflow-x:auto"><?= voucher_html($v, $tiket, $dibuatOleh) ?></div>
</div>

<div class="small text-muted">
  Tiket: <a href="<?= BASE_URL ?>/pembelian/detail.php?id=<?= $id ?>"><?= e($tiket['no_ticket'] ?? '') ?></a>
  &middot; dibuat <?= e(format_tanggal_waktu($v['created_at'])) ?>
  <?php if ($dibuatOleh !== ''): ?>&middot; oleh <?= e($dibuatOleh) ?><?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
