<?php
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/voucher.php';
require_role(['admin', 'finance']);
$user = current_user();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$p = $id ? voucher_ambil_tiket($pdo, $id) : null;
if (!$p) {
    set_flash('danger', 'Tiket tidak ditemukan.');
    redirect('/voucher/list.php');
}
if (!voucher_tersedia($pdo)) {
    set_flash('danger', 'Tabel voucher belum ada. Jalankan migration_v13_voucher.sql di phpMyAdmin dulu.');
    redirect('/voucher/list.php');
}
if (voucher_ambil($pdo, $id)) {            // sudah ada -> langsung tampilkan
    redirect('/voucher/lihat.php?id=' . $id);
}

$error = null;
// No Voucher SELALU otomatis (tidak ada isian manual lagi).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hasil = voucher_buat($pdo, $id, $user['id']);
    if ($hasil['ok']) {
        set_flash('success', $hasil['pesan']);
        redirect('/voucher/lihat.php?id=' . $id);
    }
    $error = $hasil['pesan'];
}

$layak      = voucher_tiket_layak($p);
$sebelum    = (float)$p['total_harga'];
$potongan   = (float)total_potongan_pajak($p);
$noBerikut  = voucher_nomor_berikut($pdo, date('Y-m-d'), (string)$p['no_ticket']);
$pageTitle  = 'Buat Voucher Pembayaran';
include __DIR__ . '/../includes/header.php';
?>

<h4 class="mb-3"><i class="bi bi-receipt"></i> Buat Voucher Pembayaran</h4>

<?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<?php if (!$layak): ?>
  <div class="alert alert-warning">Voucher hanya bisa dibuat untuk tiket yang sudah disetujui Petugas, Finance, dan Dirops.</div>
<?php endif; ?>

<div class="card mb-3" style="max-width:760px">
  <div class="card-body">
    <table class="table table-sm mb-0">
      <tr><td class="text-muted" style="width:38%">Description</td><td class="fw-semibold"><?= e(voucher_deskripsi($p)) ?></td></tr>
      <tr><td class="text-muted">Total Sebelum Pajak</td><td><?= format_rupiah($sebelum) ?></td></tr>
      <tr><td class="text-muted">Total Potongan Pajak</td><td><?= format_rupiah($potongan) ?></td></tr>
      <tr><td class="text-muted">Total Amount</td><td class="fw-bold"><?= format_rupiah($sebelum - $potongan) ?></td></tr>
      <tr><td class="text-muted">Tanggal Voucher</td><td><?= format_tanggal(date('Y-m-d')) ?> (hari ini)</td></tr>
    </table>
  </div>
</div>

<form method="POST" style="max-width:760px">
  <input type="hidden" name="id" value="<?= $id ?>">
  <div class="mb-3">
    <label class="form-label">No Voucher <span class="badge text-bg-success">otomatis</span></label>
    <input type="text" class="form-control fw-bold" value="<?= e($noBerikut) ?>" disabled style="max-width:280px">
    <div class="form-text">
      Nomor voucher dibuat sistem <strong>otomatis mengikuti nomor tiket</strong>
      (contoh: tiket <code>Ranger-0005</code> &rarr; voucher
      <code><?= e(voucher_nomor_sepadan_tiket($p['no_ticket'], date('Y-m-d')) ?: VOUCHER_PREFIX . '-' . date('Ym') . '-xxxx') ?></code>).
      Tidak perlu dan tidak bisa diketik manual.
    </div>
  </div>
  <button class="btn btn-brand" <?= $layak ? '' : 'disabled' ?>><i class="bi bi-check2-circle"></i> Buat Voucher</button>
  <a href="<?= BASE_URL ?>/voucher/list.php" class="btn btn-outline-secondary">Batal</a>
  <div class="form-text mt-2">Angka dan nomor voucher disimpan saat dibuat dan tidak berubah lagi.</div>
</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>
