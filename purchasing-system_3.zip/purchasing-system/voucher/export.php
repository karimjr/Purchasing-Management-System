<?php
// Unduh voucher pembayaran: ?id=<id tiket>&export=xlsx|pdf
require_once __DIR__ . '/../includes/init.php';
require_once __DIR__ . '/../includes/voucher.php';
require_role(['admin', 'finance', 'dirops']);

$id = (int)($_GET['id'] ?? 0);
$v = $id ? voucher_ambil($pdo, $id) : null;
if (!$v) {
    set_flash('warning', 'Voucher untuk tiket ini belum dibuat.');
    redirect('/voucher/list.php');
}
$nama = voucher_nama_berkas($v);
$tiket      = voucher_ambil_tiket($pdo, $id);
$dibuatOleh = voucher_nama_user($pdo, $v['created_by']);
while (ob_get_level() > 0) ob_end_clean();

if (($_GET['export'] ?? 'xlsx') === 'pdf') {
    $data = voucher_pdf_bytes($v, $tiket, $dibuatOleh);
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $nama . '.pdf"');
} else {
    $data = voucher_xlsx_bytes($v, $tiket, $dibuatOleh);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $nama . '.xlsx"');
}
header('Content-Length: ' . strlen($data));
header('Cache-Control: no-store');
echo $data;
exit;
