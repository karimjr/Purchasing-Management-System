<?php
// =========================================================
// XlsxWriter - pembuat file .xlsx minimal (tanpa library eksternal)
// ----------------------------------------------------------
// Hanya memakai ekstensi ZipArchive yang tersedia di hosting PHP
// manapun, jadi tidak perlu composer / phpSpreadsheet.
// Mendukung: multi sheet, header tebal, format Rupiah, angka desimal,
// tanggal asli Excel, lebar kolom, baris beku, autofilter, baris total.
// =========================================================

class XlsxWriter
{
    private $sheets = [];

    // Tipe sel -> indeks gaya di cellXfs (lihat buildStyles)
    private static $style = [
        'text' => 0, 'title' => 1, 'subtitle' => 2, 'header' => 3,
        'money' => 4, 'num' => 5, 'int' => 6, 'date' => 7, 'wrap' => 8,
        'tot_text' => 9, 'tot_money' => 10, 'tot_num' => 11, 'tot_int' => 12,
    ];

    public function addSheet($name, array $blocks, array $opts = [])
    {
        $this->sheets[] = [
            'name'       => mb_substr((string)$name, 0, 31),
            'blocks'     => $blocks,
            'freezeRows' => (int)($opts['freezeRows'] ?? 0),
            'autofilter' => $opts['autofilter'] ?? null,
            'widths'     => $opts['widths'] ?? [],
            'landscape'  => !empty($opts['landscape']),
        ];
    }

    private static function colRef($index)
    {
        $s = '';
        $i = (int)$index + 1;
        while ($i > 0) {
            $s = chr(65 + (($i - 1) % 26)) . $s;
            $i = intdiv($i - 1, 26);
        }
        return $s;
    }

    private static function esc($s)
    {
        // Buang karakter kontrol yang membuat XML Excel rusak
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', ' ', (string)$s);
        return str_replace(['&', '<', '>'], ['&amp;', '&lt;', '&gt;'], $s);
    }

    // Serial tanggal Excel: jumlah hari sejak 1899-12-30 (epoch tanggal itu NEGATIF)
    private static function excelSerial($date)
    {
        $date = trim((string)$date);
        if ($date === '' || strlen($date) < 8) return null;
        $ts = strtotime($date . ' 00:00:00 UTC');
        if ($ts === false) return null;
        return (int)round(($ts + 2209161600) / 86400);
    }

    private static function cellOf($cell, $colType = null)
    {
        if (is_array($cell)) {
            return ['v' => $cell['v'] ?? '', 't' => $cell['t'] ?? ($colType ?: 'text')];
        }
        if ($cell === null) return ['v' => '', 't' => $colType ?: 'text'];
        // Nilai mentah mewarisi tipe kolom tabelnya, supaya baris TOTAL
        // tidak perlu ditulis ulang sebagai sel bertipe.
        if ($colType)       return ['v' => $cell, 't' => $colType];
        if (is_bool($cell)) return ['v' => $cell ? 'Ya' : 'Tidak', 't' => 'text'];
        if (is_int($cell))  return ['v' => $cell, 't' => 'int'];
        if (is_float($cell)) return ['v' => $cell, 't' => 'num'];
        return ['v' => $cell, 't' => 'text'];
    }

    // ---------------------------------------------------------
    // Susun satu sheet
    // ---------------------------------------------------------
    private function buildSheet(array $sh)
    {
        $rowsXml = '';
        $rowNum = 1;
        $maxCol = 0;
        $headerRow = null;
        $tableStartRows = [];

        foreach ($sh['blocks'] as $block) {
            $type = $block['type'] ?? 'table';

            if ($type === 'title') {
                $rowsXml .= '<row r="' . $rowNum . '" ht="20" customHeight="1">'
                    . '<c r="A' . $rowNum . '" s="' . self::$style['title'] . '" t="inlineStr"><is><t xml:space="preserve">'
                    . self::esc($block['text']) . '</t></is></c></row>';
                $rowNum++;
                $maxCol = max($maxCol, 1);
                continue;
            }

            if ($type === 'subtitle') {
                $rowsXml .= '<row r="' . $rowNum . '">'
                    . '<c r="A' . $rowNum . '" s="' . self::$style['subtitle'] . '" t="inlineStr"><is><t xml:space="preserve">'
                    . self::esc($block['text']) . '</t></is></c></row>';
                $rowNum++;
                continue;
            }

            if ($type === 'kv') {
                foreach ($block['pairs'] as $pair) {
                    $rowsXml .= '<row r="' . $rowNum . '">'
                        . '<c r="A' . $rowNum . '" s="' . self::$style['subtitle'] . '" t="inlineStr"><is><t xml:space="preserve">' . self::esc($pair[0]) . '</t></is></c>'
                        . '<c r="B' . $rowNum . '" t="inlineStr"><is><t xml:space="preserve">' . self::esc($pair[1]) . '</t></is></c></row>';
                    $rowNum++;
                    $maxCol = max($maxCol, 2);
                }
                continue;
            }

            if ($type === 'spacer') { $rowNum++; continue; }

            // ---------- tabel ----------
            $cells = '';
            foreach ($block['columns'] as $ci => $col) {
                $label = is_array($col) ? ($col['label'] ?? '') : (string)$col;
                $cells .= '<c r="' . self::colRef($ci) . $rowNum . '" s="' . self::$style['header'] . '" t="inlineStr"><is><t xml:space="preserve">'
                    . self::esc($label) . '</t></is></c>';
                $maxCol = max($maxCol, $ci + 1);
            }
            $rowsXml .= '<row r="' . $rowNum . '" ht="26" customHeight="1">' . $cells . '</row>';
            if ($headerRow === null) {
                $headerRow = $rowNum;
                $tableStartRows['header'] = $rowNum;
            }
            $rowNum++;
            $firstDataRow = $rowNum;

            $columns  = $block['columns'];
            $dataRows = array_values($block['rows']);
            $lastIdx = count($dataRows) - 1;
            foreach ($dataRows as $ri => $r) {
                $isTotal = !empty($block['totals_row']) && $ri === $lastIdx;
                if (is_array($r) && isset($r['total'])) unset($r['total']);
                $cells = '';
                $ci = 0;
                foreach ($r as $cell) {
                    if ($ci >= count($columns)) break; // sel ekstra diabaikan
                    $colType = $columns[$ci]['t'] ?? null;
                    $c = self::cellOf($cell, $colType);
                    $type = isset(self::$style[$c['t']]) ? $c['t'] : 'text';
                    if ($isTotal) {
                        $styleKey = isset(self::$style['tot_' . $type]) ? self::$style['tot_' . $type] : self::$style['tot_text'];
                    } else {
                        $styleKey = self::$style[$type];
                    }
                    $ref = self::colRef($ci) . $rowNum;
                    $v = $c['v'];

                    if ($c['t'] === 'date' && ($serial = self::excelSerial((string)$v)) !== null) {
                        $cells .= '<c r="' . $ref . '" s="' . $styleKey . '"><v>' . $serial . '</v></c>';
                    } elseif (in_array($c['t'], ['money', 'num', 'int'], true) && is_numeric($v)) {
                        $cells .= '<c r="' . $ref . '" s="' . $styleKey . '"><v>' . (0 + $v) . '</v></c>';
                    } elseif ((string)$v === '') {
                        $cells .= '<c r="' . $ref . '" s="' . $styleKey . '"/>';
                    } else {
                        $cells .= '<c r="' . $ref . '" s="' . $styleKey . '" t="inlineStr"><is><t xml:space="preserve">'
                            . self::esc(is_string($v) ? $v : (string)$v) . '</t></is></c>';
                    }
                    $maxCol = max($maxCol, $ci + 1);
                    $ci++;
                }
                $rowsXml .= '<row r="' . $rowNum . '">' . $cells . '</row>';
                $rowNum++;
            }

            if (!empty($block['withFilter']) && $sh['autofilter'] === null && $headerRow) {
                $tableStartRows['last'] = $rowNum - 1;
            }
            $rowNum++; // jeda antar blok
        }

        $colsXml = '';
        foreach ($sh['widths'] as $ci => $w) {
            $colsXml .= '<col min="' . ($ci + 1) . '" max="' . ($ci + 1) . '" width="' . round((float)$w, 1) . '" customWidth="1"/>';
        }

        $lastColRef = self::colRef(max(0, $maxCol - 1));
        $dim = 'A1:' . $lastColRef . max(1, $rowNum - 1);

        $after = '';
        if ($sh['autofilter']) {
            $after .= '<autoFilter ref="' . self::esc($sh['autofilter']) . '"/>';
        } elseif ($headerRow && isset($tableStartRows['last'])) {
            $after .= '<autoFilter ref="A' . $headerRow . ':' . $lastColRef . $tableStartRows['last'] . '"/>';
        }
        $after .= '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
                . '<pageSetup paperSize="9" orientation="' . ($sh['landscape'] ? 'landscape' : 'portrait') . '" fitToWidth="1"/>';

        $pane = $sh['freezeRows'] > 0
            ? '<pane ySplit="' . $sh['freezeRows'] . '" topLeftCell="A' . ($sh['freezeRows'] + 1) . '" activePane="bottomLeft" state="frozen"/>'
            : '';
        $views = '<sheetViews><sheetView workbookViewId="0">' . $pane . '</sheetView></sheetViews>';

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . '<dimension ref="' . $dim . '"/>' . $views
            . '<sheetFormatPr defaultRowHeight="14.5"/>'
            . ($colsXml ? '<cols>' . $colsXml . '</cols>' : '')
            . '<sheetData>' . $rowsXml . '</sheetData>' . $after . '</worksheet>';
    }

    // ---------------------------------------------------------
    // styles.xml
    // ---------------------------------------------------------
    private function buildStyles()
    {
        $numFmts = '<numFmts count="4">'
            . '<numFmt numFmtId="164" formatCode="&quot;Rp &quot;#,##0"/>'
            . '<numFmt numFmtId="165" formatCode="#,##0.00"/>'
            . '<numFmt numFmtId="166" formatCode="dd\\.mm\\.yyyy"/>'
            . '<numFmt numFmtId="167" formatCode="#,##0"/>'
            . '</numFmts>';

        // font 0 normal, 1 judul hijau, 2 abu-abu, 3 header putih tebal, 4 tebal gelap (baris total)
        $fonts = '<fonts count="5">'
            . '<font><sz val="10"/><color rgb="FF222222"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="13"/><color rgb="FF1E8449"/><name val="Calibri"/></font>'
            . '<font><sz val="10"/><color rgb="FF666666"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
            . '<font><b/><sz val="10"/><color rgb="FF1B2631"/><name val="Calibri"/></font>'
            . '</fonts>';

        // fill 0 none, 1 gray125 (wajib), 2 hijau header, 3 hijau muda baris total
        $fills = '<fills count="4">'
            . '<fill><patternFill patternType="none"/></fill>'
            . '<fill><patternFill patternType="gray125"/></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FF1E8449"/><bgColor indexed="64"/></patternFill></fill>'
            . '<fill><patternFill patternType="solid"><fgColor rgb="FFE8F6EE"/><bgColor indexed="64"/></patternFill></fill>'
            . '</fills>';

        $borders = '<borders count="2">'
            . '<border><left/><right/><top/><bottom/><diagonal/></border>'
            . '<border>'
            . '<left style="thin"><color rgb="FFD5D8DC"/></left><right style="thin"><color rgb="FFD5D8DC"/></right>'
            . '<top style="thin"><color rgb="FFD5D8DC"/></top><bottom style="thin"><color rgb="FFD5D8DC"/></bottom><diagonal/>'
            . '</border>'
            . '</borders>';

        // [numFmtId, fontId, fillId, borderId, horizontal, wrapText]
        $defs = [
            [0,   0, 0, 1, null,    false], // 0  text
            [0,   1, 0, 0, null,    false], // 1  title
            [0,   2, 0, 0, null,    false], // 2  subtitle
            [0,   3, 2, 1, 'center', true], // 3  header
            [164, 0, 0, 1, 'right', false], // 4  money
            [165, 0, 0, 1, 'right', false], // 5  num
            [167, 0, 0, 1, 'right', false], // 6  int
            [166, 0, 0, 1, 'center', false], // 7 date
            [0,   0, 0, 1, 'left',  true],  // 8  wrap
            [0,   4, 3, 1, null,    false], // 9  tot_text
            [164, 4, 3, 1, 'right', false], // 10 tot_money
            [165, 4, 3, 1, 'right', false], // 11 tot_num
            [167, 4, 3, 1, 'right', false], // 12 tot_int
        ];

        $xfs = '';
        foreach ($defs as $d) {
            [$nf, $fo, $fi, $bo, $ha, $wrap] = $d;
            $xml = '<xf numFmtId="' . $nf . '" fontId="' . $fo . '" fillId="' . $fi . '" borderId="' . $bo . '" xfId="0"';
            if ($nf)  $xml .= ' applyNumberFormat="1"';
            if ($fi)  $xml .= ' applyFill="1"';
            if ($bo)  $xml .= ' applyBorder="1"';
            if ($ha !== null || $wrap) {
                $xml .= ' applyAlignment="1"><alignment'
                    . ($ha !== null ? ' horizontal="' . $ha . '"' : '')
                    . ($wrap ? ' wrapText="1" vertical="top"' : '') . '/></xf>';
            } else {
                $xml .= '/>';
            }
            $xfs .= $xml;
        }

        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            . $numFmts . $fonts . $fills . $borders
            . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            . '<cellXfs count="' . count($defs) . '">' . $xfs . '</cellXfs>'
            . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
            . '</styleSheet>';
    }

    // ---------------------------------------------------------
    private function workbook()
    {
        $sheetsXml = '';
        foreach ($this->sheets as $i => $sh) {
            $id = $i + 1;
            $sheetsXml .= '<sheet name="' . self::esc($sh['name']) . '" sheetId="' . $id . '" r:id="rId' . $id . '"/>';
        }
        return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
            . ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            . '<sheets>' . $sheetsXml . '</sheets></workbook>';
    }

    public function bytes()
    {
        if (!$this->sheets) {
            $this->addSheet('Rekap', [['type' => 'title', 'text' => 'Tidak ada data']]);
        }
        $n = count($this->sheets);

        $zip = new ZipArchive();
        $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');
        if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Gagal membuat file Excel sementara.');
        }

        $overrides = '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>';
        for ($i = 1; $i <= $n; $i++) {
            $overrides .= '<Override PartName="/xl/worksheets/sheet' . $i . '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>';
        }
        $zip->addFromString('[Content_Types].xml',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            . '<Default Extension="xml" ContentType="application/xml"/>' . $overrides . '</Types>');

        $zip->addFromString('_rels/.rels',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
            . '</Relationships>');

        $zip->addFromString('xl/workbook.xml', $this->workbook());

        $rels = '';
        for ($i = 1; $i <= $n; $i++) {
            $rels .= '<Relationship Id="rId' . $i . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' . $i . '.xml"/>';
        }
        $rels .= '<Relationship Id="rId' . ($n + 1) . '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';
        $zip->addFromString('xl/_rels/workbook.xml.rels',
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' . $rels . '</Relationships>');

        $zip->addFromString('xl/styles.xml', $this->buildStyles());
        foreach ($this->sheets as $i => $sh) {
            $zip->addFromString('xl/worksheets/sheet' . ($i + 1) . '.xml', $this->buildSheet($sh));
        }
        $zip->close();

        $data = file_get_contents($tmp);
        @unlink($tmp);
        return $data;
    }

    public function save($path)
    {
        return file_put_contents($path, $this->bytes()) !== false;
    }

    public function download($filename)
    {
        $data = $this->bytes();
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', $filename) . '"');
        header('Content-Length: ' . strlen($data));
        header('Cache-Control: no-store');
        echo $data;
        exit;
    }
}
