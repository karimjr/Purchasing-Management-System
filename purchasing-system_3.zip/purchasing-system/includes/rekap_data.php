<?php
// =========================================================
// Lapisan data REKAPITULASI
// ---------------------------------------------------------
// Dipakai bersama oleh rekap/list.php (tampilan layar) dan
// rekap/export.php (file Excel & PDF). Karena keduanya memakai
// fungsi yang sama, angka yang tampil di layar PERSIS sama dengan
// angka yang ada di file hasil ekspor.
// =========================================================

const REKAP_GRUPS = [
    'tiket'   => 'Per Tiket (rincian)',
    'harian'  => 'Harian (per tanggal)',
    'bulanan' => 'Bulanan (per bulan)',
    'daerah'  => 'Per Daerah',
    'pic'     => 'Per PIC',
    'vendor'  => 'Per Supplier',
    'status'  => 'Per Status Pembayaran',
];

const REKAP_SORTS = [
    'tanggal_desc' => 'Tanggal terbaru dulu',
    'tanggal_asc'  => 'Tanggal terlama dulu',
    'nilai_desc'   => 'Nilai terbesar dulu',
    'nota_desc'    => 'No Nota terbaru',
];

const REKAP_LABEL_PETUGAS = [
    'menunggu' => 'Menunggu Approval', 'disetujui' => 'Disetujui',
    'ditolak' => 'Ditolak', 'revisi_harga' => 'Diminta Revisi Harga',
];
const REKAP_LABEL_SINGKAT = [
    'menunggu' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak',
];
const REKAP_LABEL_BAYAR = [
    'belum_diajukan' => 'Belum Diajukan', 'sudah_diajukan_ho' => 'Sudah Diajukan ke HO',
    'menunggu_pembayaran' => 'Menunggu Pembayaran', 'sedang_diproses' => 'Sedang Diproses',
    'selesai' => 'Selesai / Done', 'gagal' => 'Gagal', 'dibatalkan' => 'Dibatalkan',
];
const REKAP_PERIODE_PESAT = [
    'hari_ini'  => 'Hari Ini',
    'bulan_ini' => 'Bulan Ini',
    'bulan_lalu'=> 'Bulan Lalu',
    '7_hari'    => '7 Hari',
    '30_hari'   => '30 Hari',
    'tahun_ini' => 'Tahun Ini',
    'semua'     => 'Semua Periode',
];

// Rumus nilai yang sama dengan helper total_setelah_pajak(): pakai nilai
// tersimpan, kecuali kalau 0 (data lama sebelum fitur pajak) -> hitung ulang.
function rekap_sql_net() {
    return "COALESCE(NULLIF(p.total_setelah_pajak, 0),"
         . " ROUND(p.total_harga * (1 - COALESCE(NULLIF(p.persentase_pajak, 0), IF(p.punya_npwp = 1, 0.25, 0.5)) / 100), 2))";
}

function rekap_tgl($v) {
    if (!$v) return null;
    $d = DateTime::createFromFormat('!Y-m-d', $v);
    return ($d && $d->format('Y-m-d') === $v) ? $v : null;
}

// ---------------------------------------------------------
// Baca & bersihkan filter dari query string / POST
// ---------------------------------------------------------
function rekap_parse_filters($src, $role = null, $userId = null) {
    $f = [];

    $f['grup'] = (isset($src['grup']) && isset(REKAP_GRUPS[$src['grup']])) ? $src['grup'] : 'tiket';
    $f['sort'] = (isset($src['sort']) && isset(REKAP_SORTS[$src['sort']])) ? $src['sort'] : 'tanggal_desc';

    $quick = isset($src['quick']) ? (string)$src['quick'] : '';
    $dari = null; $sampai = null;
    switch ($quick) {
        case 'hari_ini':   $dari = $sampai = date('Y-m-d'); break;
        case 'bulan_lalu':  $dari = date('Y-m-01', strtotime('first day of last month'));
                            $sampai = date('Y-m-t', strtotime('first day of last month')); break;
        case '7_hari':      $dari = date('Y-m-d', strtotime('-6 days')); $sampai = date('Y-m-d'); break;
        case '30_hari':     $dari = date('Y-m-d', strtotime('-29 days')); $sampai = date('Y-m-d'); break;
        case 'tahun_ini':   $dari = date('Y-01-01'); $sampai = date('Y-12-31'); break;
        case 'semua':       $dari = null; $sampai = null; break;
        case 'bulan_ini':
        default:            $dari = date('Y-m-01'); $sampai = date('Y-m-d'); break;
    }
    // Nilai eksplisit dari form selalu mengalahkan pilihan pesat.
    if (isset($src['dari']) && $src['dari'] !== '') $dari = rekap_tgl($src['dari']);
    if (isset($src['sampai']) && $src['sampai'] !== '') $sampai = rekap_tgl($src['sampai']);
    if ($dari && $sampai && $dari > $sampai) { [$dari, $sampai] = [$sampai, $dari]; }
    $f['dari'] = $dari; $f['sampai'] = $sampai;

    foreach (['daerah', 'pic_id', 'vendor_id', 'status_approval', 'status_finance_approval', 'status_dirops', 'status_pembayaran'] as $k) {
        $f[$k] = isset($src[$k]) ? trim((string)$src[$k]) : '';
    }
    $f['hanya_selesai'] = !empty($src['hanya_selesai']);

    // Kolom & whitelist nilai untuk filter status (hindari nilai sembarang masuk SQL)
    $statusWhitelist = [
        'status_approval'        => ['menunggu', 'disetujui', 'ditolak', 'revisi_harga'],
        'status_finance_approval'=> ['menunggu', 'disetujui', 'ditolak'],
        'status_dirops'          => ['menunggu', 'disetujui', 'ditolak'],
        'status_pembayaran'      => ['belum_diajukan', 'sudah_diajukan_ho', 'menunggu_pembayaran', 'sedang_diproses', 'selesai', 'gagal', 'dibatalkan'],
    ];
    foreach ($statusWhitelist as $k => $allow) {
        if ($f[$k] !== '' && !in_array($f[$k], $allow, true)) $f[$k] = '';
    }
    if (!ctype_digit($f['pic_id']))    $f['pic_id'] = '';
    if (!ctype_digit($f['vendor_id'])) $f['vendor_id'] = '';

    // Pencarian bebas: No Ticket, No Nota, supplier, PIC, catatan
    $q = isset($src['q']) ? trim((string)$src['q']) : '';
    $q = str_replace(['%', '_'], [' ', ' '], $q);
    $f['q'] = $q;

    // PIC hanya boleh melihat datanya sendiri (sama seperti Daftar Pembelian)
    $f['pakai_pic_id'] = ($role === 'pic') ? (int)$userId : (int)($f['pic_id'] ?: 0);

    $f['hal'] = max(1, (int)($src['hal'] ?? 1));
    $perSeite = (int)($src['per_page'] ?? 50);
    $f['per_page'] = in_array($perSeite, [25, 50, 100, 250], true) ? $perSeite : 50;
    $f['semua_baris'] = !empty($src['semua_baris']) || isset($src['export']);

    return $f;
}

// ---------------------------------------------------------
// WHERE + ORDER bersama untuk semua query rekap
// ---------------------------------------------------------
function rekap_where(array $f) {
    $w = ["1 = 1"]; $p = [];
    if ($f['dari'])   { $w[] = "p.tanggal >= ?"; $p[] = $f['dari']; }
    if ($f['sampai']) { $w[] = "p.tanggal <= ?"; $p[] = $f['sampai']; }
    if ($f['daerah'] !== '')   { $w[] = "p.daerah = ?";  $p[] = $f['daerah']; }
    if ($f['pakai_pic_id'])    { $w[] = "p.pic_id = ?";  $p[] = (string)$f['pakai_pic_id']; }
    if ($f['vendor_id'] !== ''){ $w[] = "p.vendor_id = ?"; $p[] = $f['vendor_id']; }
    foreach (['status_approval', 'status_finance_approval', 'status_dirops', 'status_pembayaran'] as $k) {
        if ($f[$k] !== '') { $w[] = "p.$k = ?"; $p[] = $f[$k]; }
    }
    if ($f['hanya_selesai']) { $w[] = "p.status_pembayaran = 'selesai'"; }
    if ($f['q'] !== '') {
        $like = '%' . $f['q'] . '%';
        $w[] = "(p.no_ticket LIKE ? OR p.no_nota LIKE ? OR v.name LIKE ? OR u.name LIKE ?
                OR p.catatan_approval LIKE ? OR p.catatan_finance LIKE ? OR p.catatan_dirops LIKE ?)";
        for ($i = 0; $i < 7; $i++) $p[] = $like;
    }
    return [implode(' AND ', $w), $p];
}

function rekap_order(array $f) {
    switch ($f['sort']) {
        case 'tanggal_asc': return "p.tanggal ASC, p.id ASC";
        case 'nilai_desc':  return "p.total_harga DESC, p.tanggal DESC";
        case 'nota_desc':   return "CAST(p.no_nota AS UNSIGNED) DESC, p.id DESC";
        default:            return "p.tanggal DESC, p.id DESC";
    }
}

function rekap_join() {
    return " FROM purchases p
             JOIN vendors v ON v.id = p.vendor_id
             JOIN users u   ON u.id = p.pic_id
             LEFT JOIN users ap ON ap.id = p.approved_by
             LEFT JOIN users fa ON fa.id = p.finance_approval_by
             LEFT JOIN users dr ON dr.id = p.dirops_by
             LEFT JOIN users fi ON fi.id = p.processed_by ";
}

function rekap_select() {
    $net = rekap_sql_net();
    return "SELECT p.*, v.name AS vendor_name, u.name AS pic_name,
                   ap.name AS petugas_name, fa.name AS finance_appr_name,
                   dr.name AS dirops_by_name, fi.name AS finance_name,
                   $net AS nilai_net, (p.total_harga - $net) AS nilai_potongan
            " . rekap_join();
}

// ---------------------------------------------------------
// Ambil semua data rekap: rincian + total + ringkasan per grup
// ---------------------------------------------------------
function rekap_fetch(PDO $pdo, array $f) {
    [$where, $params] = rekap_where($f);
    $net = rekap_sql_net();

    $total = $pdo->prepare(
        "SELECT COUNT(*) AS n,
                COALESCE(SUM(p.berat_basah),0) AS kg,
                COALESCE(SUM(p.total_harga),0) AS bruto,
                COALESCE(SUM($net),0) AS net
         " . rekap_join() . " WHERE $where"
    , [PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
    $total->execute($params);
    $t = $total->fetch() ?: ['n'=>0,'kg'=>0,'bruto'=>0,'net'=>0];
    $t['pot'] = max(0, (float)$t['bruto'] - (float)$t['net']);

    // Jumlah tiket per status pembayaran (untuk kartu ringkasan alur)
    $perStatus = array_fill_keys(array_keys(REKAP_LABEL_BAYAR), 0);
    $st = $pdo->prepare("SELECT p.status_pembayaran AS s, COUNT(*) AS n " . rekap_join() . " WHERE $where GROUP BY p.status_pembayaran");
    $st->execute($params);
    foreach ($st->fetchAll() as $r) { $perStatus[$r['s']] = (int)$r['n']; }

    $out = ['filters' => $f, 'totals' => $t, 'per_status' => $perStatus];

    // ---------- ringkasan per grup ----------
    if ($f['grup'] === 'tiket') {
        $out['rows'] = [];
        $sql = rekap_select() . " WHERE $where ORDER BY " . rekap_order($f);
        if (!$f['semua_baris']) {
            $cnt = $pdo->prepare("SELECT COUNT(*)" . rekap_join() . " WHERE $where");
            $cnt->execute($params);
            $out['grand_total'] = (int)$cnt->fetchColumn();
            $out['total_hal']   = max(1, (int)ceil($out['grand_total'] / $f['per_page']));
            $f['hal'] = min($f['hal'], $out['total_hal']);
            $out['filters']['hal'] = $f['hal'];
            $offset = ($f['hal'] - 1) * $f['per_page'];
            $sql .= " LIMIT $f[per_page] OFFSET $offset";
        } else {
            $out['grand_total'] = (int)$t['n'];
            $out['total_hal'] = 1;
        }
        $q = $pdo->prepare($sql);
        $q->execute($params);
        $out['rows'] = $q->fetchAll();
        return $out;
    }

    $dims = [
        'harian'  => ["DATE(p.tanggal)", 'p.tanggal'],
        'bulanan' => ["DATE_FORMAT(p.tanggal, '%Y-%m')", "DATE_FORMAT(p.tanggal, '%Y-%m')"],
        'daerah'  => ["p.daerah", "p.daerah"],
        'pic'     => ["u.name", "u.name"],
        'vendor'  => ["v.name", "v.name"],
        'status'  => ["p.status_pembayaran", "FIELD(p.status_pembayaran,'belum_diajukan','sudah_diajukan_ho','menunggu_pembayaran','sedang_diproses','selesai','gagal','dibatalkan')"],
    ];
    [$sel, $ord] = $dims[$f['grup']];
    $g = $pdo->prepare(
        "SELECT $sel AS k, COUNT(*) AS n,
                COALESCE(SUM(p.berat_basah),0) AS kg,
                COALESCE(SUM(p.total_harga),0) AS bruto,
                COALESCE(SUM($net),0) AS net,
                COALESCE(SUM(p.status_pembayaran = 'selesai'),0) AS n_selesai,
                COALESCE(SUM(p.status_approval <> 'disetujui' OR p.status_pembayaran = 'dibatalkan'),0) AS n_masalah
         " . rekap_join() . " WHERE $where
         GROUP BY $sel ORDER BY bruto DESC"
    );
    $g->execute($params);
    $rows = $g->fetchAll();
    foreach ($rows as &$r) {
        $r['pot'] = max(0, (float)$r['bruto'] - (float)$r['net']);
        $r['label'] = rekap_grup_label($f['grup'], $r['k']);
    }
    unset($r);
    $out['group_rows'] = $rows;
    $out['group_total'] = count($rows);
    return $out;
}

function rekap_grup_label($grup, $key) {
    if ($grup === 'harian' && preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$key)) return format_tanggal($key);
    if ($grup === 'bulanan' && preg_match('/^\d{4}-\d{2}$/', (string)$key)) {
        return date('F Y', strtotime($key . '-01'));
    }
    if ($grup === 'status' && isset(REKAP_LABEL_BAYAR[$key])) return REKAP_LABEL_BAYAR[$key];
    return (string)($key === null || $key === '' ? '-' : $key);
}

// ---------------------------------------------------------
// TABEL STANDAR: satu bentuk data untuk layar, Excel, dan PDF.
// Tiap sel = ['v' => nilai mentah, 't' => text|money|int|num|date]
// ---------------------------------------------------------
function rekap_tabel(array $data) {
    $f = $data['filters'];

    if ($f['grup'] !== 'tiket') {
        $cols = [
            ['label' => 'Kelompok',              'pdfLabel' => 'KELOMPOK',        'key' => 'label',     't' => 'text',  'w' => 30, 'pdfW' => 150, 'pdf' => true],
            ['label' => 'Jumlah Tiket',           'pdfLabel' => 'TIKET',           'key' => 'n',         't' => 'int',   'w' => 12, 'pdfW' => 42, 'pdf' => true],
            ['label' => 'Total Berat Basah (KG)', 'pdfLabel' => 'BERAT (KG)',      'key' => 'kg',        't' => 'num',   'w' => 20, 'pdfW' => 62, 'pdf' => true],
            ['label' => 'Total Sebelum Pajak',    'pdfLabel' => 'SEBELUM PAJAK',  'key' => 'bruto',     't' => 'money', 'w' => 22, 'pdfW' => 70, 'pdf' => true],
            ['label' => 'Potongan Pajak',         'pdfLabel' => 'POTONGAN',        'key' => 'pot',       't' => 'money', 'w' => 18, 'pdfW' => 62, 'pdf' => true],
            ['label' => 'Total Setelah Pajak',    'pdfLabel' => 'SETILAH PAJAK',   'key' => 'net',       't' => 'money', 'w' => 22, 'pdfW' => 70, 'pdf' => true],
            ['label' => 'Sudah Dibayar',          'pdfLabel' => 'DIBAYAR',         'key' => 'n_selesai', 't' => 'int',   'w' => 14, 'pdfW' => 46, 'pdf' => true],
            ['label' => 'Ditolak/Dibatalkan',     'pdfLabel' => 'DITOLAK',         'key' => 'n_masalah', 't' => 'int',   'w' => 17, 'pdfW' => 46, 'pdf' => true],
        ];
        $rows = [];
        foreach ($data['group_rows'] as $r) {
            $row = [];
            foreach ($cols as $c) $row[] = ['v' => $r[$c['key']] ?? '', 't' => $c['t']];
            $rows[] = $row;
        }
        $t = $data['totals'];
        $grand = [
            'label' => 'TOTAL', 'n' => (int)$t['n'], 'kg' => $t['kg'],
            'bruto' => $t['bruto'], 'pot' => $t['pot'], 'net' => $t['net'],
            'n_selesai' => (int)($data['per_status']['selesai'] ?? 0), 'n_masalah' => '',
        ];
        $row = [];
        foreach ($cols as $c) $row[] = ['v' => $grand[$c['key']] ?? '', 't' => $c['t']];
        $rows[] = $row;
        return ['columns' => $cols, 'rows' => $rows, 'totals_row' => true];
    }

    // 'pdf' => false berarti kolom tetap ada di Excel tapi tidak dibawa ke PDF
    // (21 kolom tidak akan terbaca di satu halaman A4).
    $cols = [
        ['label' => 'No Ticket',   't' => 'text',  'w' => 17, 'pdf' => true,  'pdfLabel' => 'NO TICKET',     'pdfW' => 64],
        ['label' => 'No Nota',     't' => 'text',  'w' => 8,  'pdf' => true,  'pdfLabel' => 'NOTA',          'pdfW' => 26],
        ['label' => 'Tanggal',     't' => 'date',  'w' => 11, 'pdf' => true,  'pdfLabel' => 'TANGGAL',       'pdfW' => 42],
        ['label' => 'Daerah',      't' => 'text',  'w' => 14, 'pdf' => true,  'pdfLabel' => 'DAERAH',        'pdfW' => 50],
        ['label' => 'PIC',         't' => 'text',  'w' => 14, 'pdf' => true,  'pdfLabel' => 'PIC',           'pdfW' => 50],
        ['label' => 'Supplier',      't' => 'text',  'w' => 20, 'pdf' => true,  'pdfLabel' => 'SUPPLIER',        'pdfW' => 76],
        ['label' => 'Berat Basah (KG)', 't' => 'num', 'w' => 12, 'pdf' => true, 'pdfLabel' => 'BERAT KG',   'pdfW' => 42],
        ['label' => 'Harga Basah', 't' => 'money', 'w' => 14, 'pdf' => true,  'pdfLabel' => 'HARGA BASAH',   'pdfW' => 50],
        ['label' => 'Harga Notaring', 't' => 'money', 'w' => 14, 'pdf' => false],
        ['label' => 'DRC (%)',     't' => 'num',   'w' => 9,  'pdf' => true,  'pdfLabel' => 'DRC %',         'pdfW' => 30],
        ['label' => 'Total Sebelum Pajak', 't' => 'money', 'w' => 18, 'pdf' => true, 'pdfLabel' => 'SEBELUM PAJAK', 'pdfW' => 58],
        ['label' => 'Potongan Pajak', 't' => 'money', 'w' => 15, 'pdf' => true, 'pdfLabel' => 'POTONGAN',    'pdfW' => 48],
        ['label' => 'Total Setelah Pajak', 't' => 'money', 'w' => 18, 'pdf' => true, 'pdfLabel' => 'DIBAYAR', 'pdfW' => 58],
        ['label' => 'Status Petugas', 't' => 'text', 'w' => 16, 'pdf' => false],
        ['label' => 'Status Finance', 't' => 'text', 'w' => 13, 'pdf' => false],
        ['label' => 'Status Dirops', 't' => 'text', 'w' => 13, 'pdf' => false],
        ['label' => 'Status Pembayaran', 't' => 'text', 'w' => 18, 'pdf' => true, 'pdfLabel' => 'STATUS',    'pdfW' => 60],
        ['label' => 'Dibayar Oleh', 't' => 'text', 'w' => 14, 'pdf' => false],
        ['label' => 'Tgl Pembayaran', 't' => 'text', 'w' => 16, 'pdf' => true, 'pdfLabel' => 'TGL BAYAR',    'pdfW' => 52],
        ['label' => 'Catatan Finance', 't' => 'text', 'w' => 28, 'pdf' => false],
        ['label' => 'Catatan Dirops',  't' => 'text', 'w' => 28, 'pdf' => false],
    ];

    $rows = [];
    foreach ($data['rows'] as $r) {
        $rows[] = [
            ['v' => $r['no_ticket'], 't' => 'text'],
            ['v' => $r['no_nota'], 't' => 'text'],
            ['v' => $r['tanggal'], 't' => 'date'],
            ['v' => $r['daerah'], 't' => 'text'],
            ['v' => $r['pic_name'], 't' => 'text'],
            ['v' => $r['vendor_name'], 't' => 'text'],
            ['v' => (float)$r['berat_basah'], 't' => 'num'],
            ['v' => (float)$r['harga_basah'], 't' => 'money'],
            ['v' => (float)$r['harga_notaring'], 't' => 'money'],
            ['v' => (float)$r['drc'], 't' => 'num'],
            ['v' => (float)$r['total_harga'], 't' => 'money'],
            ['v' => (float)$r['nilai_potongan'], 't' => 'money'],
            ['v' => (float)$r['nilai_net'], 't' => 'money'],
            ['v' => REKAP_LABEL_PETUGAS[$r['status_approval']] ?? $r['status_approval'], 't' => 'text'],
            ['v' => REKAP_LABEL_SINGKAT[$r['status_finance_approval']] ?? $r['status_finance_approval'], 't' => 'text'],
            ['v' => REKAP_LABEL_SINGKAT[$r['status_dirops']] ?? $r['status_dirops'], 't' => 'text'],
            ['v' => REKAP_LABEL_BAYAR[$r['status_pembayaran']] ?? $r['status_pembayaran'], 't' => 'text'],
            ['v' => $r['finance_name'] ?? '', 't' => 'text'],
            ['v' => $r['processed_at'] ? format_tanggal_waktu($r['processed_at']) : '', 't' => 'text'],
            ['v' => (string)$r['catatan_finance'], 't' => 'text'],
            ['v' => (string)$r['catatan_dirops'], 't' => 'text'],
        ];
    }

    // Baris TOTAL: angka agregat diletakkan pada kolom yang sama dengan datanya,
    // jadi Excel/PDF tidak perlu dihitung ulang oleh pemakai.
    $t = $data['totals'];
    $grandAt = [
        0  => 'TOTAL (' . (int)$t['n'] . ' tiket)',
        6  => $t['kg'],
        10 => $t['bruto'],
        11 => $t['pot'],
        12 => $t['net'],
    ];
    $totalRow = [];
    foreach ($cols as $ci => $c) {
        $totalRow[] = ['v' => $grandAt[$ci] ?? '', 't' => $c['t']];
    }
    $rows[] = $totalRow;

    return ['columns' => $cols, 'rows' => $rows, 'totals_row' => true];
}

// Susun kolom versi PDF: pakai pdfLabel/pdfW kalau ada; lebar fraksional
// dinormalkan sendiri oleh PdfWriter agar pas satu halaman.
function rekap_pdf_cols(array $cols, $hanyaPdf = false) {
    $out = [];
    foreach ($cols as $c) {
        if ($hanyaPdf && empty($c['pdf'])) continue;
        $t = $c['t'] ?? 'text';
        $out[] = [
            'label' => $c['pdfLabel'] ?? $c['label'],
            't'     => $t,
            'w'     => (float)($c['pdfW'] ?? max(7, (float)($c['w'] ?? 12))),
            'align' => $c['align'] ?? (in_array($t, ['money', 'num', 'int'], true) ? 'right' : 'left'),
        ];
    }
    return $out;
}

// Rincian 21 kolom tidak muat dibaca di satu halaman A4, jadi untuk PDF
// hanya kolom bertanda 'pdf' => true yang dibawa (Excel tetap lengkap 21 kolom).
function rekap_tabel_pdf_detail(array $data) {
    $tabel = rekap_tabel($data);
    $cols = [];
    $idx  = [];
    foreach ($tabel['columns'] as $ci => $c) {
        if (empty($c['pdf'])) continue;
        $cols[] = [
            'label' => $c['pdfLabel'] ?? $c['label'],
            't'     => $c['t'],
            'w'     => (float)($c['pdfW'] ?? 50),
            'align' => in_array($c['t'], ['money', 'num', 'int'], true) ? 'right' : 'left',
        ];
        $idx[] = $ci;
    }
    $rows = [];
    foreach ($tabel['rows'] as $r) {
        $row = [];
        foreach ($idx as $p) $row[] = $r[$p] ?? '';
        $rows[] = $row;
    }
    return ['columns' => $cols, 'rows' => $rows];
}

// Bangun URL yang mempertahankan semua filter aktif (pakai di tautan sort/halaman/ekspor)
function rekap_url(array $f, $script, array $override = []) {
    $keep = array_intersect_key($f, array_flip([
        'dari', 'sampai', 'daerah', 'pic_id', 'vendor_id', 'status_approval',
        'status_finance_approval', 'status_dirops', 'status_pembayaran', 'q',
        'grup', 'sort', 'hal', 'per_page',
    ]));
    foreach ($keep as $k => $v) if ($v === '' || $v === null) unset($keep[$k]);
    if ($f['hanya_selesai']) $keep['hanya_selesai'] = 1;
    $qs = http_build_query(array_merge($keep, $override));
    return $script . ($qs ? "?$qs" : '');
}

function rekap_label_periode(array $f) {
    if ($f['dari'] && $f['sampai']) return format_tanggal($f['dari']) . ' - ' . format_tanggal($f['sampai']);
    if ($f['dari'])   return 'mulai ' . format_tanggal($f['dari']);
    if ($f['sampai']) return 'sampai ' . format_tanggal($f['sampai']);
    return 'semua periode';
}
