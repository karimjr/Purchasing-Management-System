<?php
// =========================================================
// Voucher Pembayaran
// ---------------------------------------------------------
// Satu voucher per tiket pembelian. Tampilan HTML, Excel (.xlsx) dan PDF
// semuanya dibangun dari SATU struktur data (voucher_data) supaya angkanya
// mustahil beda antar format.
//
// Angka (sebelum pajak, potongan, total) DISIMPAN saat voucher dibuat
// (snapshot), jadi voucher yang sudah diterbitkan tidak berubah sendiri
// kalau data tiket berubah belakangan.
//
// No Voucher dibuat OTOMATIS dan berurutan (tidak lagi diketik manual):
//     PV-YYYYMM-0001, PV-YYYYMM-0002, ...  (urutan mulai 1 lagi tiap bulan)
// Counter-nya bisa dilihat / direset / ditentukan Admin di menu
//     Pengaturan No Voucher  (settings/voucher.php)
// =========================================================

// ---------------------------------------------------------
// KETENTUAN AKUN - jangan diubah tanpa persetujuan (sudah baku).
// ---------------------------------------------------------
define('VOUCHER_AKUN_BAHAN_BAKU_NO',   '1-1410');
define('VOUCHER_AKUN_BAHAN_BAKU_NAMA', 'Bahan Baku Bokar');
define('VOUCHER_AKUN_PPH22_NO',        '2-1104');
define('VOUCHER_AKUN_PPH22_NAMA',      'Hutang PPH22');
define('VOUCHER_AKUN_BANK_NO',         '1-1181');
define('VOUCHER_AKUN_BANK_NAMA',       'BSI Bokar Ranger');

// Awalan nomor voucher otomatis: PV-YYYYMM-0001 (urutan mulai 1 lagi tiap bulan)
if (!defined('VOUCHER_PREFIX')) define('VOUCHER_PREFIX', 'PV');

// Identitas pada kop voucher - ubah di sini kalau nama/divisi berbeda.
if (!defined('VOUCHER_PERUSAHAAN'))  define('VOUCHER_PERUSAHAAN', 'PT POTENSI BUMI SAKTI');
if (!defined('VOUCHER_UNIT'))        define('VOUCHER_UNIT', 'Divisi Pembelian Bokar');
if (!defined('VOUCHER_KOTA'))        define('VOUCHER_KOTA', 'Aceh Barat');

function voucher_tersedia($pdo)
{
    static $ada = null;
    if ($ada === null) {
        try {
            $pdo->query("SELECT 1 FROM payment_vouchers LIMIT 1");
            $ada = true;
        } catch (Exception $e) {
            $ada = false;
        }
    }
    return $ada;
}

// Tiket yang boleh dibuatkan voucher: sudah lolos Petugas, Finance, dan Dirops.
function voucher_tiket_layak($p)
{
    return ($p['status_approval'] ?? '') === 'disetujui'
        && ($p['status_finance_approval'] ?? '') === 'disetujui'
        && ($p['status_dirops'] ?? '') === 'disetujui'
        && ($p['status_pembayaran'] ?? '') !== 'dibatalkan';
}

function voucher_ambil_tiket($pdo, $purchaseId)
{
    $stmt = $pdo->prepare("SELECT p.*, v.name AS vendor_name, u.name AS pic_name,
                                  up.name AS petugas_name, uf.name AS finance_name,
                                  ud.name AS dirops_name
                           FROM purchases p
                           JOIN vendors v ON v.id = p.vendor_id
                           JOIN users u ON u.id = p.pic_id
                           LEFT JOIN users up ON up.id = p.approved_by
                           LEFT JOIN users uf ON uf.id = p.finance_approval_by
                           LEFT JOIN users ud ON ud.id = p.dirops_by
                           WHERE p.id = ?");
    $stmt->execute([(int)$purchaseId]);
    return $stmt->fetch() ?: null;
}

function voucher_ambil($pdo, $purchaseId)
{
    if (!voucher_tersedia($pdo)) return null;
    $stmt = $pdo->prepare("SELECT * FROM payment_vouchers WHERE purchase_id = ?");
    $stmt->execute([(int)$purchaseId]);
    return $stmt->fetch() ?: null;
}

function voucher_nama_user($pdo, $userId)
{
    if (!$userId) return '';
    $stmt = $pdo->prepare("SELECT name FROM users WHERE id = ?");
    $stmt->execute([(int)$userId]);
    return (string)$stmt->fetchColumn();
}

// "Nama supplier, No Tiket, Dari Mana"  (Dari Mana = daerah pembelian)
function voucher_deskripsi($p)
{
    $daerah = trim((string)($p['daerah'] ?? ''));
    return trim($p['vendor_name']) . ', ' . $p['no_ticket'] . ($daerah !== '' ? ', ' . $daerah : '');
}

// =========================================================
// NOMOR VOUCHER OTOMATIS
// =========================================================

// Pola nomor voucher. Bawaan: PV-{YYYYMM}-{NNNN} -> PV-202610-0001, 0002, ...
// Bisa diubah Admin lewat app_settings ('voucher_pola'); kalau isinya tidak
// memuat {NNNN} otomatis kembali ke pola bawaan.
function voucher_pola()
{
    $bawaan = VOUCHER_PREFIX . '-{YYYYMM}-{NNNN}';
    $pdo    = (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) ? $GLOBALS['pdo'] : null;
    if (!$pdo) return $bawaan;
    $pola = (string)get_app_setting($pdo, 'voucher_pola', $bawaan);
    if ($pola === '' || !preg_match('/\{N+\}/', $pola)) $pola = $bawaan;
    return $pola;
}

// Nama seri counter per bulan: VOUCHER-202610 (mulai dari 1 lagi tiap bulan).
function voucher_kunci($tanggal)
{
    $ts = $tanggal ? strtotime($tanggal) : time();
    return 'VOUCHER-' . date('Ym', $ts ?: time());
}

function voucher_no_dipakai($pdo, $no)
{
    $stmt = $pdo->prepare("SELECT 1 FROM payment_vouchers WHERE voucher_no = ? LIMIT 1");
    $stmt->execute([$no]);
    return (bool)$stmt->fetchColumn();
}

function voucher_format_nomor($tanggal, $urut)
{
    $ts   = $tanggal ? strtotime($tanggal) : time();
    $ts   = $ts ?: time();
    $pola = strtr(voucher_pola(), [
        '{YYYYMM}' => date('Ym', $ts),
        '{YYYY}'   => date('Y', $ts),
        '{MM}'     => date('m', $ts),
        '{DD}'     => date('d', $ts),
    ]);
    return preg_replace_callback('/\{N+\}/', function ($m) use ($urut) {
        return str_pad((string)$urut, strlen($m[0]) - 2, '0', STR_PAD_LEFT);
    }, $pola);
}

// Angka urut di ujung No Tiket, mis. "Ranger-0005" -> 5.
// Dipakai supaya No Voucher SELALU sejajar dengan No Tiket:
//     Ranger-0005  ->  PV-202610-0005
function voucher_urut_dari_tiket($noTiket)
{
    if (preg_match('/(\d+)\s*$/', (string)$noTiket, $m)) return (int)$m[1];
    return 0;
}

// Nomor voucher yang "sepadan" dengan sebuah No Tiket (belum cek bentrok).
function voucher_nomor_sepadan_tiket($noTiket, $tanggal)
{
    $urut = voucher_urut_dari_tiket($noTiket);
    if ($urut < 1) return '';
    return voucher_format_nomor($tanggal, $urut);
}

// Samakan counter bulan terkait dengan nomor yang baru dipakai, supaya kalau
// nomor otomatis dipakai lagi (mis. saat No Tiket tidak berujung angka),
// urutannya tetap nyambung.
function voucher_sinkron_counter($pdo, $tanggal, $no)
{
    if (!seq_tersedia($pdo)) return;
    $urut = voucher_urut_dari_tiket($no);
    if ($urut < 1) return;
    $kunci = voucher_kunci($tanggal);
    if ((seq_intip($pdo, $kunci) - 1) < $urut) {
        seq_set($pdo, $kunci, $urut + 1);        // counter = nomor terakhir yang dipakai
    }
}

/**
 * Ambil nomor voucher baru yang masih kosong.
 * $noTiket (opsional): kalau diisi, nomor voucher dibuat SAMA dengan nomor tiket
 * (angka urutnya), contoh Ranger-0005 -> PV-202610-0005. Kalau tidak bisa,
 * dipakai counter otomatis seperti sebelumnya.
 */
function voucher_ambil_nomor($pdo, $tanggal, $noTiket = '')
{
    if ($noTiket !== '') {
        $kandidat = voucher_nomor_sepadan_tiket($noTiket, $tanggal);
        if ($kandidat !== '' && !voucher_no_dipakai($pdo, $kandidat)) {
            voucher_sinkron_counter($pdo, $tanggal, $kandidat);
            return $kandidat;
        }
    }
    if (!seq_tersedia($pdo)) return voucher_nomor_berikut($pdo, $tanggal, $noTiket);
    $kunci = voucher_kunci($tanggal);
    for ($i = 0; $i < 500; $i++) {
        $urut = seq_berikut($pdo, $kunci);
        $no   = voucher_format_nomor($tanggal, $urut);
        if (!voucher_no_dipakai($pdo, $no)) return $no;
    }
    return voucher_format_nomor($tanggal, (int)(microtime(true) * 1000) % 10000);
}

/**
 * Nomor voucher berikutnya untuk ditampilkan (pratinjau) - TIDAK menaikkan counter.
 * Kalau $noTiket diisi, yang ditampilkan adalah nomor yang sama dengan No Tiket.
 */
function voucher_nomor_berikut($pdo, $tanggal = null, $noTiket = '')
{
    $tanggal = $tanggal ?: date('Y-m-d');
    if ($noTiket !== '') {
        $kandidat = voucher_nomor_sepadan_tiket($noTiket, $tanggal);
        if ($kandidat !== '' && !voucher_no_dipakai($pdo, $kandidat)) return $kandidat;
    }
    if (!voucher_tersedia($pdo) || !seq_tersedia($pdo)) {
        // Cara lama (nomor terbesar + 1) - jaring pengaman sebelum migrasi jalan.
        $prefix = VOUCHER_PREFIX . '-' . date('Ym', strtotime($tanggal)) . '-';
        $stmt = $pdo->prepare("SELECT voucher_no FROM payment_vouchers WHERE voucher_no LIKE ? ORDER BY voucher_no DESC LIMIT 1");
        $stmt->execute([$prefix . '%']);
        $last = $stmt->fetchColumn();
        $next = $last ? ((int)substr($last, -4)) + 1 : 1;
        return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
    }
    $kunci = voucher_kunci($tanggal);
    $urut  = seq_intip($pdo, $kunci);
    for ($i = 0; $i < 500; $i++) {
        $no = voucher_format_nomor($tanggal, $urut);
        if (!voucher_no_dipakai($pdo, $no)) return $no;
        $urut++;
    }
    return voucher_format_nomor($tanggal, $urut);
}

// Info counter untuk Pengaturan No Voucher.
function voucher_counter_info($pdo, $bulan = null)
{
    $bulan = $bulan ?: date('Ym');
    $awal  = substr($bulan, 0, 4) . '-' . substr($bulan, 4, 2) . '-01';
    $info  = [
        'bulan'      => $bulan,
        'label'      => date('F Y', strtotime($awal)),
        'tersedia'   => seq_tersedia($pdo),
        'terakhir'   => 0,
        'berikutnya' => 1,
        'contoh'     => '',
        'jumlah'     => 0,
    ];
    if (!voucher_tersedia($pdo)) return $info;
    $stmt = $pdo->prepare("SELECT COUNT(*), COALESCE(MAX(CAST(SUBSTRING_INDEX(voucher_no, '-', -1) AS UNSIGNED)), 0)
                           FROM payment_vouchers
                           WHERE voucher_no REGEXP ? AND voucher_date BETWEEN ? AND LAST_DAY(?)");
    $pola = '^' . preg_quote(VOUCHER_PREFIX, '/') . '-[0-9]{6}-[0-9]+$';
    $stmt->execute([$pola, $awal, $awal]);
    [$jml, $max] = array_pad($stmt->fetch(PDO::FETCH_NUM) ?: [], 2, 0);
    $info['jumlah'] = (int)$jml;
    if ($info['tersedia']) {
        $kunci = 'VOUCHER-' . $bulan;
        $info['terakhir'] = max((int)$max, seq_intip($pdo, $kunci) - 1);
        $urut = max(1, $info['terakhir'] + 1);
        for ($i = 0; $i < 500; $i++) {
            $no = voucher_format_nomor($awal, $urut);
            if (!voucher_no_dipakai($pdo, $no)) break;
            $urut++;
        }
        $info['berikutnya'] = $urut;
        $info['contoh']     = voucher_format_nomor($awal, $urut);
    }
    return $info;
}

// Admin: tetapkan nomor voucher berikutnya untuk sebuah bulan.
function voucher_set_berikutnya($pdo, $nomor, $bulan = null)
{
    if (!seq_tersedia($pdo)) return false;
    $bulan = $bulan ?: date('Ym');
    seq_set($pdo, 'VOUCHER-' . $bulan, max(1, (int)$nomor));
    return true;
}

// Admin: reset counter voucher bulan tertentu -> nomor berikutnya mulai dari 1.
function voucher_reset_counter($pdo, $bulan = null)
{
    if (!seq_tersedia($pdo)) return false;
    $bulan = $bulan ?: date('Ym');
    seq_reset($pdo, 'VOUCHER-' . $bulan);
    return true;
}

/**
 * Buat voucher untuk satu tiket.
 * Mengembalikan ['ok'=>bool, 'voucher'=>row|null, 'pesan'=>string].
 * No Voucher SELALU otomatis (berurutan). Parameter $noManual dipertahankan
 * hanya supaya pemanggil lama tidak error - nilainya diabaikan.
 */
function voucher_buat($pdo, $purchaseId, $userId, $noManual = '')
{
    if (!voucher_tersedia($pdo)) {
        return ['ok' => false, 'voucher' => null,
                'pesan' => 'Tabel voucher belum ada. Jalankan migration_v13_voucher.sql di phpMyAdmin dulu.'];
    }
    $p = voucher_ambil_tiket($pdo, $purchaseId);
    if (!$p) return ['ok' => false, 'voucher' => null, 'pesan' => 'Tiket tidak ditemukan.'];
    if (!voucher_tiket_layak($p)) {
        return ['ok' => false, 'voucher' => null,
                'pesan' => 'Voucher hanya bisa dibuat untuk tiket yang sudah disetujui Petugas, Finance, dan Dirops.'];
    }
    $ada = voucher_ambil($pdo, $purchaseId);
    if ($ada) return ['ok' => true, 'voucher' => $ada, 'pesan' => 'Voucher untuk tiket ini sudah ada.'];

    $tanggal   = date('Y-m-d');
    $sebelum   = round((float)$p['total_harga'], 2);
    $potongan  = round((float)total_potongan_pajak($p), 2);
    $total     = round($sebelum - $potongan, 2);
    $deskripsi = voucher_deskripsi($p);

    $ins = $pdo->prepare("INSERT INTO payment_vouchers
        (purchase_id, voucher_no, voucher_date, deskripsi, total_sebelum_pajak, total_potongan, total_bersih, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

    // Nomor sudah atomik, tapi kalau tetap bentrok (mis. bersamaan dengan
    // Admin yang menurunkan counter) -> ambil nomor berikutnya dan coba lagi.
    for ($try = 0; $try < 10; $try++) {
        $no = voucher_ambil_nomor($pdo, $tanggal, (string)$p['no_ticket']);
        try {
            $ins->execute([(int)$purchaseId, $no, $tanggal, $deskripsi, $sebelum, $potongan, $total, (int)$userId]);
            $v = voucher_ambil($pdo, $purchaseId);
            log_activity($pdo, (int)$purchaseId, 'Voucher Pembayaran dibuat', 'No Voucher: ' . $no);
            return ['ok' => true, 'voucher' => $v, 'pesan' => 'Voucher ' . $no . ' berhasil dibuat.'];
        } catch (PDOException $e) {
            if ($e->getCode() !== '23000') throw $e;
            if (($v = voucher_ambil($pdo, $purchaseId))) {      // tiket ini keburu dibuatkan
                return ['ok' => true, 'voucher' => $v, 'pesan' => 'Voucher untuk tiket ini sudah ada.'];
            }
        }
    }
    return ['ok' => false, 'voucher' => null, 'pesan' => 'Gagal membuat nomor voucher otomatis. Coba lagi.'];
}

// ---------- label & angka ----------

function voucher_status_label($p)
{
    $peta = [
        'belum_diajukan'      => 'Belum Diajukan',
        'sudah_diajukan_ho'   => 'Sudah Diajukan ke HO',
        'menunggu_pembayaran' => 'Menunggu Pembayaran',
        'sedang_diproses'     => 'Sedang Diproses',
        'selesai'             => 'Selesai / Done',
        'gagal'               => 'Gagal',
        'dibatalkan'          => 'Dibatalkan',
    ];
    $kunci = $p['status_pembayaran'] ?? '';
    return $peta[$kunci] ?? ($kunci !== '' ? ucfirst(str_replace('_', ' ', $kunci)) : '-');
}

// Ubah angka jadi kalimat rupiah: 5685750 -> "Lima juta enam ratus delapan puluh lima ribu tujuh ratus lima puluh rupiah"
function terbilang_rupiah($angka)
{
    // Dibulatkan ke rupiah penuh, sama seperti format_rupiah() (number_format 0 desimal),
    // supaya terbilang selalu sama dengan angka "Total Amount" yang tampil di voucher.
    $angka = round((float)$angka, 0);
    $bulat = (int)abs($angka);

    $satuan = ['', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan', 'sepuluh', 'sebelas'];

    $ucap = function ($n) use (&$ucap, $satuan) {
        $n = (int)$n;
        if ($n < 12) return $satuan[$n];
        if ($n < 20) return $ucap($n - 10) . ' belas';
        if ($n < 100) return $ucap(intdiv($n, 10)) . ' puluh ' . $ucap($n % 10);
        if ($n < 200) return 'seratus ' . $ucap($n - 100);
        if ($n < 1000) return $ucap(intdiv($n, 100)) . ' ratus ' . $ucap($n % 100);
        if ($n < 2000) return 'seribu ' . $ucap($n - 1000);
        if ($n < 1000000) return $ucap(intdiv($n, 1000)) . ' ribu ' . $ucap($n % 1000);
        if ($n < 1000000000) return $ucap(intdiv($n, 1000000)) . ' juta ' . $ucap($n % 1000000);
        if ($n < 1000000000000) return $ucap(intdiv($n, 1000000000)) . ' miliar ' . $ucap($n % 1000000000);
        return $ucap(intdiv($n, 1000000000000)) . ' triliun ' . $ucap($n % 1000000000000);
    };

    $teks = trim(preg_replace('/\s+/', ' ', $ucap($bulat)));
    if ($teks === '') $teks = 'nol';
    if ($angka < 0) $teks = 'minus ' . $teks;
    $teks .= ' rupiah';
    return ucfirst($teks);
}

/**
 * Struktur data tunggal untuk HTML / Excel / PDF.
 * $v     = baris payment_vouchers.
 * $tiket = baris pembelian (opsional) - dipakai untuk melengkapi kop voucher.
 * $dibuatOleh = nama pembuat voucher (opsional).
 */
function voucher_data($v, $tiket = null, $dibuatOleh = '')
{
    $sebelum  = (float)$v['total_sebelum_pajak'];
    $potongan = (float)$v['total_potongan'];
    $tiket    = $tiket ?: [];
    return [
        'no'        => $v['voucher_no'],
        'tanggal'   => $v['voucher_date'],
        'deskripsi' => $v['deskripsi'],
        'sebelum'   => $sebelum,
        'potongan'  => $potongan,
        'total'     => (float)$v['total_bersih'],
        'terbilang' => terbilang_rupiah((float)$v['total_bersih']),
        'status'    => voucher_status_label($tiket),
        'perusahaan'=> VOUCHER_PERUSAHAAN,
        'unit'      => VOUCHER_UNIT,
        'kota'      => VOUCHER_KOTA,
        'info'      => [
            'No Tiket'    => (string)($tiket['no_ticket'] ?? ''),
            'No Nota'     => (string)($tiket['no_nota'] ?? ''),
            'Supplier'      => (string)($tiket['vendor_name'] ?? ''),
            'Daerah'      => (string)($tiket['daerah'] ?? ''),
            'PIC'         => (string)($tiket['pic_name'] ?? ''),
            'Tanggal Tiket' => !empty($tiket['tanggal']) ? format_tanggal($tiket['tanggal']) : '',
        ],
        // rincian perhitungan tiket (pelengkap voucher)
        'rincian'   => array_values(array_filter([
            !empty($tiket['berat_basah'])    ? ['Berat Basah', number_format((float)$tiket['berat_basah'], 2, ',', '.') . ' kg'] : null,
            !empty($tiket['harga_basah'])    ? ['Harga Basah', format_rupiah($tiket['harga_basah']) . ' / kg'] : null,
            !empty($tiket['harga_notaring']) ? ['Harga Notaring', format_rupiah($tiket['harga_notaring']) . ' / kg'] : null,
            (isset($tiket['drc']) && $tiket['drc'] !== null && $tiket['drc'] !== '')
                ? ['DRC', number_format((float)$tiket['drc'], 2, ',', '.') . ' %'] : null,
            ['Total Sebelum Pajak', format_rupiah($sebelum)],
            ['Potongan PPh 22', '- ' . format_rupiah($potongan)],
        ])),
        // baris tabel: [No Akun, Nama Akun, Amount|null]
        'baris' => [
            [VOUCHER_AKUN_BAHAN_BAKU_NO, VOUCHER_AKUN_BAHAN_BAKU_NAMA, $sebelum],
            [VOUCHER_AKUN_PPH22_NO,      VOUCHER_AKUN_PPH22_NAMA,      $potongan],
            [VOUCHER_AKUN_BANK_NO,       VOUCHER_AKUN_BANK_NAMA,       null],
            ['',                         '',                           null],
        ],
        // Catatan: blok tanda tangan (Dibuat / Diperiksa / Disetujui / Diterima oleh)
        // sudah dihapus dari voucher sesuai permintaan.
    ];
}

function voucher_nama_berkas($v)
{
    return 'Voucher_' . preg_replace('/[^A-Za-z0-9\-_]/', '-', $v['voucher_no']);
}

// Path logo untuk HTML/PDF (kalau berkasnya tidak ada, kop tetap rapi tanpa logo)
function voucher_logo_url()
{
    return BASE_URL . '/assets/icons/icon-192.png';
}

function voucher_logo_path()
{
    return __DIR__ . '/../assets/icons/logo-pt.jpg';
}

// ---------------------------------------------------------
// HTML (dipakai halaman lihat & halaman cetak)
// ---------------------------------------------------------
function voucher_css()
{
    return '
.vc-wrap{--vc-green:#1e8449;--vc-green-dk:#14532d;--vc-tint:#eaf5ee;--vc-line:#bcd9c6;
         --vc-ink:#132b1e;--vc-muted:#5d7a69;max-width:840px;margin:0 auto;background:#fff;
         color:var(--vc-ink);font-family:"Segoe UI",Calibri,Arial,Helvetica,sans-serif;font-size:13px;line-height:1.45}
.vc-head{display:flex;justify-content:space-between;align-items:center;gap:18px;padding-bottom:12px;border-bottom:3px solid var(--vc-green)}
.vc-brand{display:flex;align-items:center;gap:12px;min-width:0}
.vc-logo{width:54px;height:54px;object-fit:contain;flex:0 0 auto}
.vc-pt{font-size:17px;font-weight:800;letter-spacing:.4px;color:var(--vc-green-dk);line-height:1.2}
.vc-unit{font-size:11.5px;color:var(--vc-muted);margin-top:3px}
.vc-doc{text-align:right;flex:0 0 auto}
.vc-doc-title{font-size:21px;font-weight:800;letter-spacing:2.2px;color:var(--vc-green-dk);line-height:1.1}
.vc-doc-sub{font-size:10.5px;letter-spacing:1.6px;text-transform:uppercase;color:var(--vc-muted);margin-top:4px}
.vc-meta{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:10px;margin:14px 0 12px}
.vc-meta>div{background:var(--vc-tint);border:1px solid var(--vc-line);border-left:4px solid var(--vc-green);border-radius:6px;padding:7px 12px}
.vc-meta span{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.9px;color:var(--vc-muted);margin-bottom:1px}
.vc-meta b{font-size:15px;font-variant-numeric:tabular-nums;letter-spacing:.3px}
.vc-info{display:grid;grid-template-columns:1fr 1fr;border:1px solid var(--vc-line);border-radius:8px;overflow:hidden;margin-bottom:14px}
.vc-info>div{display:flex;gap:10px;padding:6px 12px;border-bottom:1px solid #e8f1eb;font-size:12.5px}
.vc-info>div:nth-child(4n+1),.vc-info>div:nth-child(4n+2){background:#fbfdfb}
.vc-info em{font-style:normal;color:var(--vc-muted);flex:0 0 108px}
.vc-info b{font-weight:600}
.vc-rinc{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px}
.vc-rinc>div{border:1px solid var(--vc-line);border-radius:6px;padding:6px 10px;background:#fff}
.vc-rinc span{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.7px;color:var(--vc-muted)}
.vc-rinc b{font-size:12.5px;font-variant-numeric:tabular-nums}
.vc-table{width:100%;border-collapse:collapse;table-layout:fixed;font-size:13px}
.vc-table th{background:var(--vc-green);color:#fff;font-weight:700;text-align:center;border:1px solid var(--vc-green-dk);padding:8px;letter-spacing:.3px}
.vc-table td{background:#fff;border:1px solid var(--vc-line);text-align:center;vertical-align:middle;padding:6px 9px;word-wrap:break-word}
.vc-table tbody tr:nth-child(even) td{background:#f7fbf8}
.vc-table td.vc-desc{font-weight:600;color:var(--vc-green-dk);padding:8px 12px}
.vc-table td.vc-money{text-align:right;font-variant-numeric:tabular-nums;padding-right:14px}
.vc-table tr.vc-total td{background:var(--vc-green-dk);color:#fff;border-color:var(--vc-green-dk);font-weight:700;font-size:14px}
.vc-terbilang{display:flex;gap:10px;align-items:baseline;background:var(--vc-tint);border:1px dashed var(--vc-line);
              border-radius:8px;padding:8px 12px;margin-top:10px;font-size:12px}
.vc-terbilang span{text-transform:uppercase;letter-spacing:.8px;font-size:10px;color:var(--vc-muted);flex:0 0 auto}
.vc-terbilang b{font-weight:600;font-style:italic;text-transform:capitalize}
.vc-foot{display:flex;justify-content:space-between;gap:12px;margin-top:16px;padding-top:8px;border-top:1px solid #e2ece6;
         font-size:10.5px;color:var(--vc-muted)}
@media print{.vc-wrap{max-width:none}}
';
}

function voucher_html($v, $tiket = null, $dibuatOleh = '')
{
    $d = voucher_data($v, $tiket, $dibuatOleh);
    $rp = function ($n) { return e(format_rupiah($n)); };
    ob_start(); ?>
<div class="vc-wrap">
  <div class="vc-head">
    <div class="vc-brand">
      <img class="vc-logo" src="<?= e(voucher_logo_url()) ?>" alt="Logo">
      <div>
        <div class="vc-pt"><?= e($d['perusahaan']) ?></div>
        <div class="vc-unit"><?= e($d['unit']) ?> &middot; <?= e($d['kota']) ?></div>
      </div>
    </div>
    <div class="vc-doc">
      <div class="vc-doc-title">PAYMENT VOUCHER</div>
      <div class="vc-doc-sub">Voucher Pembayaran</div>
    </div>
  </div>

  <div class="vc-meta">
    <div><span>Voucher No</span><b><?= e($d['no']) ?></b></div>
    <div><span>Tanggal</span><b><?= e(format_tanggal($d['tanggal'])) ?></b></div>
    <div><span>Status</span><b><?= e($d['status']) ?></b></div>
  </div>

  <?php if (array_filter($d['info'])): ?>
  <div class="vc-info">
    <?php foreach ($d['info'] as $label => $isi): ?>
      <div><em><?= e($label) ?></em><b><?= e($isi !== '' ? $isi : '-') ?></b></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <?php if ($d['rincian']): ?>
  <div class="vc-rinc">
    <?php foreach ($d['rincian'] as $r): ?>
      <div><span><?= e($r[0]) ?></span><b><?= e($r[1]) ?></b></div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

  <table class="vc-table">
    <colgroup><col style="width:30%"><col style="width:15%"><col style="width:25%"><col style="width:30%"></colgroup>
    <thead><tr><th>Description</th><th>Account No.</th><th>Account Name</th><th>Amount</th></tr></thead>
    <tbody>
      <tr>
        <td class="vc-desc" rowspan="5"><?= e($d['deskripsi']) ?></td>
        <td><?= e($d['baris'][0][0]) ?></td><td><?= e($d['baris'][0][1]) ?></td><td class="vc-money"><?= $rp($d['baris'][0][2]) ?></td>
      </tr>
      <tr>
        <td><?= e($d['baris'][1][0]) ?></td><td><?= e($d['baris'][1][1]) ?></td><td class="vc-money"><?= $rp($d['baris'][1][2]) ?></td>
      </tr>
      <tr>
        <td><?= e($d['baris'][2][0]) ?></td><td><?= e($d['baris'][2][1]) ?></td><td rowspan="2"></td>
      </tr>
      <tr>
        <td rowspan="2"></td><td></td>
      </tr>
      <tr class="vc-total">
        <td>Total Amount</td><td><?= $rp($d['total']) ?></td>
      </tr>
    </tbody>
  </table>

  <div class="vc-terbilang"><span>Terbilang</span><b><?= e($d['terbilang']) ?></b></div>

  <div class="vc-foot">
    <div><?= e($d['perusahaan']) ?> &middot; <?= e($d['unit']) ?></div>
    <div>Dicetak <?= e(format_tanggal_waktu(date('Y-m-d H:i:s'))) ?> &middot; Purchasing System</div>
  </div>
</div>
<?php
    return ob_get_clean();
}

// ---------------------------------------------------------
// Excel (.xlsx) - dibuat tanpa library, warna & tata letak sama dengan tampilan
// ---------------------------------------------------------
function voucher_xlsx_bytes($v, $tiket = null, $dibuatOleh = '')
{
    $d = voucher_data($v, $tiket, $dibuatOleh);
    $esc = function ($s) {
        $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/u', ' ', (string)$s);
        return str_replace(['&', '<', '>'], ['&amp;', '&lt;', '&gt;'], $s);
    };

    // daftar gaya (index mengikuti urutan <cellXfs> di bawah)
    $S = [
        'pt'      => 1,  'unit'    => 2,  'doctitle' => 3, 'metaLbl' => 4, 'metaVal' => 5,
        'infoLbl' => 6,  'infoVal' => 7,  'head'     => 8, 'desc'    => 9, 'txt'     => 10,
        'money'   => 11, 'totLbl'  => 12, 'totMoney' => 13, 'terbilang' => 14,
        'signLbl' => 15, 'signNm'  => 16, 'note'     => 17,
    ];

    // grid[baris][kolom] = [nilai, gaya, 'n' angka | 's' teks]
    $g = [];
    $g[1][0] = [$d['perusahaan'], $S['pt'], 's'];
    $g[2][0] = [$d['unit'] . ' - ' . $d['kota'], $S['unit'], 's'];
    $g[1][3] = ['PAYMENT VOUCHER', $S['doctitle'], 's'];
    $g[2][3] = ['Voucher Pembayaran', $S['unit'], 's'];

    $g[4][2] = ['Voucher No', $S['metaLbl'], 's'];  $g[4][3] = [$d['no'], $S['metaVal'], 's'];
    $g[5][2] = ['Tanggal', $S['metaLbl'], 's'];     $g[5][3] = [format_tanggal($d['tanggal']), $S['metaVal'], 's'];
    $g[6][2] = ['Status', $S['metaLbl'], 's'];      $g[6][3] = [$d['status'], $S['metaVal'], 's'];

    $info = [];
    foreach ($d['info'] as $label => $isi) { if ($isi !== '') $info[] = [$label, $isi]; }
    $r = 8;
    for ($i = 0; $i < count($info); $i += 2) {
        $g[$r][0] = [$info[$i][0], $S['infoLbl'], 's'];
        $g[$r][1] = [$info[$i][1], $S['infoVal'], 's'];
        if (!empty($info[$i + 1])) {
            $g[$r][2] = [$info[$i + 1][0], $S['infoLbl'], 's'];
            $g[$r][3] = [$info[$i + 1][1], $S['infoVal'], 's'];
        }
        $r++;
    }
    if ($d['rincian']) {
        $r++;
        for ($i = 0; $i < count($d['rincian']); $i += 2) {
            $g[$r][0] = [$d['rincian'][$i][0], $S['infoLbl'], 's'];
            $g[$r][1] = [$d['rincian'][$i][1], $S['infoVal'], 's'];
            if (!empty($d['rincian'][$i + 1])) {
                $g[$r][2] = [$d['rincian'][$i + 1][0], $S['infoLbl'], 's'];
                $g[$r][3] = [$d['rincian'][$i + 1][1], $S['infoVal'], 's'];
            }
            $r++;
        }
    }

    $rHead = max($r + 1, 12);
    foreach (['Description', 'Account No.', 'Account Name', 'Amount'] as $c => $h) $g[$rHead][$c] = [$h, $S['head'], 's'];
    $g[$rHead + 1][0] = [$d['deskripsi'], $S['desc'], 's'];
    foreach ($d['baris'] as $i => $b) {
        $row = $rHead + 1 + $i;
        $g[$row][1] = [$b[0], $S['txt'], 's'];
        $g[$row][2] = [$b[1], $S['txt'], 's'];
        $g[$row][3] = $b[2] === null ? ['', $S['txt'], 's'] : [$b[2], $S['money'], 'n'];
    }
    $rTotal = $rHead + 5;
    for ($i = 0; $i < 4; $i++) if (!isset($g[$rTotal][$i])) $g[$rTotal][$i] = ['', $S['totLbl'], 's'];
    $g[$rTotal][2] = ['Total Amount', $S['totLbl'], 's'];
    $g[$rTotal][3] = [$d['total'], $S['totMoney'], 'n'];

    $rTerbilang = $rTotal + 2;
    $g[$rTerbilang][0] = ['Terbilang: ' . $d['terbilang'], $S['terbilang'], 's'];

    $rowsXml = '';
    ksort($g);
    foreach ($g as $rowNum => $cols) {
        ksort($cols);
        $tinggi = '';
        if ($rowNum === 1) $tinggi = ' ht="24" customHeight="1"';
        elseif ($rowNum === 2) $tinggi = ' ht="14" customHeight="1"';
        elseif ($rowNum === $rHead) $tinggi = ' ht="22" customHeight="1"';
        elseif ($rowNum === $rTotal) $tinggi = ' ht="24" customHeight="1"';
        elseif ($rowNum === $rTerbilang) $tinggi = ' ht="30" customHeight="1"';
        $rowsXml .= '<row r="' . $rowNum . '"' . $tinggi . '>';
        foreach ($cols as $c => $cell) {
            if (!$cell) continue;
            $ref = chr(65 + $c) . $rowNum;
            [$val, $st, $typ] = $cell;
            if ($typ === 'n') {
                $rowsXml .= '<c r="' . $ref . '" s="' . $st . '"><v>' . (0 + $val) . '</v></c>';
            } elseif ($val === '') {
                $rowsXml .= '<c r="' . $ref . '" s="' . $st . '"/>';
            } else {
                $rowsXml .= '<c r="' . $ref . '" s="' . $st . '" t="inlineStr"><is><t xml:space="preserve">' . $esc($val) . '</t></is></c>';
            }
        }
        $rowsXml .= '</row>';
    }

    $merge = ['A' . ($rHead + 1) . ':A' . $rTotal];
    $merge[] = 'A' . $rTerbilang . ':D' . $rTerbilang;
    $mergeXml = '';
    foreach ($merge as $m) $mergeXml .= '<mergeCell ref="' . $m . '"/>';

    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
        . '<sheetViews><sheetView workbookViewId="0" showGridLines="0"/></sheetViews>'
        . '<cols><col min="1" max="1" width="38" customWidth="1"/><col min="2" max="2" width="15" customWidth="1"/>'
        . '<col min="3" max="3" width="26" customWidth="1"/><col min="4" max="4" width="26" customWidth="1"/></cols>'
        . '<sheetData>' . $rowsXml . '</sheetData>'
        . '<mergeCells count="' . count($merge) . '">' . $mergeXml . '</mergeCells>'
        . '<pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>'
        . '<pageSetup paperSize="9" orientation="portrait" fitToWidth="1" fitToHeight="0"/>'
        . '</worksheet>';

    $garis = '<left style="thin"><color rgb="FFB7D7C2"/></left><right style="thin"><color rgb="FFB7D7C2"/></right>'
           . '<top style="thin"><color rgb="FFB7D7C2"/></top><bottom style="thin"><color rgb="FFB7D7C2"/></bottom><diagonal/>';
    $garisTebal = '<left style="thin"><color rgb="FF14532D"/></left><right style="thin"><color rgb="FF14532D"/></right>'
           . '<top style="thin"><color rgb="FF14532D"/></top><bottom style="thin"><color rgb="FF14532D"/></bottom><diagonal/>';
    $tengah = '<alignment horizontal="center" vertical="center"/>';
    $tengahWrap = '<alignment horizontal="center" vertical="center" wrapText="1"/>';
    $kanan = '<alignment horizontal="right" vertical="center"/>';
    $kiri = '<alignment horizontal="left" vertical="center" wrapText="1"/>';

    $styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        . '<numFmts count="1"><numFmt numFmtId="164" formatCode="&quot;Rp &quot;#,##0"/></numFmts>'
        // font: 0 normal, 1 judul perusahaan, 2 subtitle, 3 doc title, 4 label, 5 value bold,
        //       6 putih tebal (header/total), 7 italic (terbilang)
        . '<fonts count="8">'
        . '<font><sz val="10"/><color rgb="FF132B1E"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="16"/><color rgb="FF14532D"/><name val="Calibri"/></font>'
        . '<font><sz val="10"/><color rgb="FF5D7A69"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="15"/><color rgb="FF14532D"/><name val="Calibri"/></font>'
        . '<font><sz val="9"/><color rgb="FF5D7A69"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="11"/><color rgb="FF132B1E"/><name val="Calibri"/></font>'
        . '<font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>'
        . '<font><i/><sz val="10"/><color rgb="FF14532D"/><name val="Calibri"/></font>'
        . '</fonts>'
        // fill: 0 none, 1 gray125, 2 hijau (header), 3 hijau tua (total), 4 hijau muda (tint)
        . '<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF1E8449"/><bgColor indexed="64"/></patternFill></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FF14532D"/><bgColor indexed="64"/></patternFill></fill>'
        . '<fill><patternFill patternType="solid"><fgColor rgb="FFEAF5EE"/><bgColor indexed="64"/></patternFill></fill></fills>'
        // border: 0 none, 1 tipis hijau, 2 tipis hijau tua
        . '<borders count="3"><border><left/><right/><top/><bottom/><diagonal/></border>'
        . '<border>' . $garis . '</border><border>' . $garisTebal . '</border></borders>'
        . '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        . '<cellXfs count="18">'
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'                                                       // 0
        . '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf>' // 1 pt
        . '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf>' // 2 unit
        . '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>' // 3 doctitle
        . '<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">' . $kanan . '</xf>'      // 4 metaLbl
        . '<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">' . $kanan . '</xf>'      // 5 metaVal
        . '<xf numFmtId="0" fontId="4" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $kiri . '</xf>'  // 6 infoLbl
        . '<xf numFmtId="0" fontId="5" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $kiri . '</xf>'  // 7 infoVal
        . '<xf numFmtId="0" fontId="6" fillId="2" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $tengah . '</xf>'// 8 head
        . '<xf numFmtId="0" fontId="5" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $kiri . '</xf>'  // 9 desc
        . '<xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1">' . $tengahWrap . '</xf>'                        // 10 txt
        . '<xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1" applyAlignment="1">' . $kanan . '</xf>'     // 11 money
        . '<xf numFmtId="0" fontId="6" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $tengah . '</xf>'// 12 totLbl
        . '<xf numFmtId="164" fontId="6" fillId="3" borderId="2" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $kanan . '</xf>' // 13 totMoney
        . '<xf numFmtId="0" fontId="7" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">' . $kiri . '</xf>'  // 14 terbilang
        . '<xf numFmtId="0" fontId="4" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">' . $tengah . '</xf>'    // 15 signLbl
        . '<xf numFmtId="0" fontId="5" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">' . $tengah . '</xf>'    // 16 signNm
        . '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1">' . $tengah . '</xf>'    // 17 note
        . '</cellXfs>'
        . '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
        . '</styleSheet>';

    $zip = new ZipArchive();
    $tmp = tempnam(sys_get_temp_dir(), 'vc_');
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new RuntimeException('Gagal membuat file Excel sementara.');
    }
    $zip->addFromString('[Content_Types].xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '</Types>');
    $zip->addFromString('_rels/.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/workbook.xml',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Voucher" sheetId="1" r:id="rId1"/></sheets></workbook>');
    $zip->addFromString('xl/_rels/workbook.xml.rels',
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/styles.xml', $styles);
    $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
    $zip->close();
    $data = file_get_contents($tmp);
    @unlink($tmp);
    return $data;
}

// ---------------------------------------------------------
// PDF (A4 portrait) - digambar langsung dengan PdfWriter
// ---------------------------------------------------------
function voucher_pdf_bytes($v, $tiket = null, $dibuatOleh = '')
{
    require_once __DIR__ . '/pdf_writer.php';
    $d   = voucher_data($v, $tiket, $dibuatOleh);
    $pdf = new PdfWriter(false);                 // A4 portrait
    $x0  = 40;
    $W   = $pdf->pageWidth() + 2 * 26 - 2 * $x0;
    $top = $pdf->topY();

    $hijau   = [0.118, 0.518, 0.286];            // #1E8449
    $hijauTk = [0.078, 0.325, 0.176];            // #14532D
    $tint    = [0.918, 0.961, 0.933];            // #EAF5EE
    $tintDk  = [0.965, 0.984, 0.973];            // #F7FBF8
    $putih   = 1;

    // ---------- kop ----------
    $yKop = $top - 8;
    $logoAda = false;
    $logoPath = voucher_logo_path();
    if (is_file($logoPath)) {
        $logoAda = $pdf->imageJpeg($x0, $yKop - 30, 30, 30, file_get_contents($logoPath));
    }
    $xTeks = $x0 + ($logoAda ? 38 : 0);
    $pdf->text($xTeks, $yKop - 12, $d['perusahaan'], 13.5, true, 0.08);
    $pdf->text($xTeks, $yKop - 24, $d['unit'] . '  |  ' . $d['kota'], 8.5, false, 0.42);

    $judul  = 'PAYMENT VOUCHER';
    $pdf->text($x0 + $W - PdfWriter::width($judul, 17, true), $yKop - 12, $judul, 17, true, 0.08);
    $sub    = 'VOUCHER PEMBAYARAN';
    $pdf->text($x0 + $W - PdfWriter::width($sub, 8, false), $yKop - 24, $sub, 8, false, 0.45);

    $y = $yKop - 36;
    $pdf->rectRgb($x0, $y, $W, 2.2, $hijau[0], $hijau[1], $hijau[2]);

    // ---------- kotak meta (No Voucher / Tanggal / Status) ----------
    $y -= 40;
    $lebar = ($W - 20) / 3;
    $meta  = [
        ['VOUCHER NO', $d['no']],
        ['TANGGAL', format_tanggal($d['tanggal'])],
        ['STATUS', $d['status']],
    ];
    foreach ($meta as $i => $m) {
        $mx = $x0 + $i * ($lebar + 10);
        $pdf->rectRgb($mx, $y, $lebar, 34, $tint[0], $tint[1], $tint[2]);
        $pdf->rectRgb($mx, $y, 3.4, 34, $hijau[0], $hijau[1], $hijau[2]);
        $pdf->text($mx + 9, $y + 22, $m[0], 6.8, false, 0.42);
        $pdf->text($mx + 9, $y + 10, PdfWriter::fit($m[1], $lebar - 16, 12, true), 12, true, 0.1);
    }

    // ---------- info tiket ----------
    $y -= 30;
    $info = [];
    foreach ($d['info'] as $k => $val) { if ($val !== '') $info[] = [$k, $val]; }
    if ($info) {
        $baris = array_chunk($info, 2);
        $tinggiBaris = 16;
        $pdf->rectRgb($x0, $y - count($baris) * $tinggiBaris, $W, count($baris) * $tinggiBaris, 0.984, 0.992, 0.987);
        $yy = $y;
        foreach ($baris as $b) {
            $yy -= $tinggiBaris;
            foreach ($b as $i => $pair) {
                $bx = $x0 + 8 + $i * ($W / 2);
                $pdf->text($bx, $yy + 5, $pair[0] . ' :', 8.2, false, 0.45);
                $pdf->text($bx + PdfWriter::width($pair[0] . ' : ', 8.2) , $yy + 5,
                           PdfWriter::fit($pair[1], $W / 2 - 90, 8.8, true), 8.8, true, 0.15);
            }
            $pdf->line($x0, $yy, $x0 + $W, $yy, 0.88, 0.4);
        }
        $y -= count($baris) * $tinggiBaris;
        $pdf->line($x0, $y, $x0 + $W, $y, 0.88, 0.4);
    }

    // ---------- rincian perhitungan tiket ----------
    if ($d['rincian']) {
        $y -= 8;
        $besi = 15;
        $baris = array_chunk($d['rincian'], 2);
        foreach ($baris as $b) {
            $y -= $besi;
            foreach ($b as $i => $pair) {
                $bx = $x0 + 8 + $i * ($W / 2);
                $pdf->text($bx, $y + 4.5, $pair[0] . ' :', 8, false, 0.45);
                $pdf->text($bx + PdfWriter::width($pair[0] . ' : ', 8), $y + 4.5,
                           PdfWriter::fit($pair[1], $W / 2 - 90, 8.6, true), 8.6, true, 0.15);
            }
            $pdf->line($x0, $y, $x0 + $W, $y, 0.9, 0.4);
        }
    }

    // ---------- tabel ----------
    $cw = [$W * 0.30, $W * 0.15, $W * 0.25, $W * 0.30];
    $cx = [$x0, $x0 + $cw[0], $x0 + $cw[0] + $cw[1], $x0 + $cw[0] + $cw[1] + $cw[2]];
    $yT   = $y - 16;                 // atas header tabel
    $hH   = 22;                      // tinggi header
    $rH   = 22;                      // tinggi baris isi
    $yB   = $yT - $hH;               // atas baris isi pertama
    $yTot = $yB - 4 * $rH;           // atas baris TOTAL
    $yEnd = $yTot - $rH;             // bawah tabel

    // badan tabel (garis-garis selang-seling)
    for ($i = 0; $i < 4; $i++) {
        $warna = ($i % 2 === 1) ? $tintDk : [1, 1, 1];
        $pdf->rectRgb($x0, $yB - ($i + 1) * $rH, $W, $rH, $warna[0], $warna[1], $warna[2]);
    }
    $pdf->rectRgb($x0, $yTot - $rH, $W, $rH, $hijauTk[0], $hijauTk[1], $hijauTk[2]);
    $pdf->rectRgb($x0, $yT - $hH, $W, $hH, $hijau[0], $hijau[1], $hijau[2]);

    // judul kolom
    foreach (['Description', 'Account No.', 'Account Name', 'Amount'] as $i => $h) {
        $pdf->text($cx[$i] + ($cw[$i] - PdfWriter::width($h, 9, true)) / 2, $yT - $hH + 7, $h, 9, true, $putih);
    }

    $tengah = function ($i, $yY, $str, $bold = false, $size = 9, $gray = 0.12) use ($pdf, $cx, $cw) {
        if ($str === '' || $str === null) return;
        $str = PdfWriter::fit((string)$str, $cw[$i] - 8, $size, $bold);
        $pdf->text($cx[$i] + ($cw[$i] - PdfWriter::width($str, $size, $bold)) / 2, $yY, $str, $size, $bold, $gray);
    };
    $kanan = function ($i, $yY, $str, $bold = false, $size = 9, $gray = 0.12) use ($pdf, $cx, $cw) {
        $str = PdfWriter::fit((string)$str, $cw[$i] - 12, $size, $bold);
        $pdf->text($cx[$i] + $cw[$i] - 10 - PdfWriter::width($str, $size, $bold), $yY, $str, $size, $bold, $gray);
    };

    $yy = function ($row) use ($yB, $rH) { return $yB - ($row + 0.6) * $rH + 2; };
    foreach ($d['baris'] as $i => $b) {
        $tengah(1, $yy($i), $b[0], false, 9);
        $tengah(2, $yy($i), $b[1], false, 9);
        if ($b[2] !== null) $kanan(3, $yy($i), format_rupiah($b[2]), false, 9);
    }
    $tengah(2, $yTot - $rH + 7, 'Total Amount', true, 10, $putih);
    $kanan(3, $yTot - $rH + 7, format_rupiah($d['total']), true, 10, $putih);

    // deskripsi (sel gabungan kolom 1, baris 1-4) - di tengah
    $words = preg_split('/\s+/', trim((string)$d['deskripsi']));
    $lines = []; $cur = '';
    foreach ($words as $wd) {
        $try = $cur === '' ? $wd : $cur . ' ' . $wd;
        if (PdfWriter::width($try, 9.5, true) > $cw[0] - 14 && $cur !== '') { $lines[] = $cur; $cur = $wd; }
        else $cur = $try;
    }
    if ($cur !== '') $lines[] = $cur;
    $lines = array_slice($lines, 0, 5);
    $blokH = count($lines) * 12;
    $ly    = $yB - (4 * $rH) / 2 + $blokH / 2 - 9;
    foreach ($lines as $i => $ln) $tengah(0, $ly - $i * 12, $ln, true, 9.5, 0.08);

    // garis tabel
    $xr = $x0 + $W;
    foreach ([$yT, $yB, $yTot, $yEnd] as $gy) $pdf->line($x0, $gy, $xr, $gy, 0.82, 0.6);
    $pdf->line($x0, $yT, $x0, $yEnd, 0.82, 0.6);
    $pdf->line($xr, $yT, $xr, $yEnd, 0.82, 0.6);
    foreach ([1, 2, 3] as $i) $pdf->line($cx[$i], $yT, $cx[$i], $yEnd, 0.82, 0.6);
    $rowY = function ($k) use ($yB, $rH) { return $yB - $k * $rH; };
    $pdf->line($cx[1], $rowY(1), $xr, $rowY(1), 0.82, 0.6);
    $pdf->line($cx[1], $rowY(2), $xr, $rowY(2), 0.82, 0.6);
    $pdf->line($cx[1], $rowY(3), $cx[3], $rowY(3), 0.82, 0.6);
    $pdf->line($cx[1], $rowY(4), $xr, $rowY(4), 0.82, 0.6);

    // ---------- terbilang (dibungkus maksimal 2 baris supaya tidak terpotong) ----------
    $xLabel = $x0 + 9;
    $xTeks  = $xLabel + PdfWriter::width('TERBILANG :', 6.8) + 8;
    $lebarTeks = $W - ($xTeks - $x0) - 10;
    $kata = preg_split('/\s+/', trim((string)$d['terbilang']));
    $b1 = ''; $b2 = '';
    foreach ($kata as $k) {
        if ($b2 === '' && PdfWriter::width(($b1 === '' ? '' : $b1 . ' ') . $k, 8.4, true) <= $lebarTeks) {
            $b1 = $b1 === '' ? $k : $b1 . ' ' . $k;
        } else {
            $b2 = $b2 === '' ? $k : $b2 . ' ' . $k;
        }
    }
    $tinggiTer = $b2 !== '' ? 30 : 24;
    $yTer = $yEnd - ($tinggiTer + 6);
    $pdf->rectRgb($x0, $yTer, $W, $tinggiTer, $tint[0], $tint[1], $tint[2]);
    $yLabel = $yTer + ($tinggiTer / 2) - 3;
    $pdf->text($xLabel, $yLabel, 'TERBILANG :', 6.8, false, 0.42);
    $pdf->text($xTeks, $yTer + ($b2 !== '' ? 17 : 9), $b1, 8.4, true, 0.15);
    if ($b2 !== '') {
        $b2 = PdfWriter::fit($b2, $lebarTeks, 8.4, true);
        $pdf->text($xTeks, $yTer + 7, $b2, 8.4, true, 0.15);
    }

    $catatan = 'Dokumen ini dibuat otomatis oleh Purchasing System - ' . $d['perusahaan']
             . '. Voucher tanpa tanda tangan basah tetap sah selama tercatat di sistem.';
    $pdf->text($x0, 30, PdfWriter::fit($catatan, $W, 6.5), 6.5, false, 0.55);

    return $pdf->bytes('Voucher Pembayaran ' . $d['no']);
}