<?php
// =========================================================
// PdfWriter - pembuat file .pdf minimal (tanpa library eksternal)
// ----------------------------------------------------------
// Sengaja TIDAK memakai DomPDF/tcpdf agar tidak perlu composer dan
// tetap jalan di shared hosting manapun. Hasilnya file PDF sungguhan
// (bukan halaman cetak), berisi:
//   - kop laporan + keterangan periode/filter
//   - blok ringkasan angka
//   - tabel bergaris, header diulang di tiap halaman, baris TOTAL
// Kertas A4, pilihan landscape (bawaan) atau portrait.
// =========================================================

class PdfWriter
{
    private $w = 841.89;
    private $h = 595.28;
    private $margin = 26;
    private $pages = [];
    private $cur = '';
    private $started = false;
    private $y = 0;

    // Lebar karakter Helvetica (AFM) per kode ASCII, untuk mengukur teks
    private static $hw = [
        32=>278,33=>278,34=>355,35=>556,36=>556,37=>889,38=>667,39=>191,40=>333,41=>333,
        42=>389,43=>584,44=>278,45=>333,46=>278,47=>278,48=>556,49=>556,50=>556,51=>556,
        52=>556,53=>556,54=>556,55=>556,56=>556,57=>556,58=>278,59=>278,60=>584,61=>584,
        62=>584,63=>556,64=>1015,65=>667,66=>667,67=>722,68=>722,69=>667,70=>611,71=>778,
        72=>722,73=>278,74=>500,75=>667,76=>556,77=>833,78=>722,79=>778,80=>667,81=>778,
        82=>722,83=>667,84=>611,85=>722,86=>667,87=>944,88=>667,89=>667,90=>611,91=>278,
        92=>278,93=>333,94=>469,95=>556,96=>333,97=>556,98=>556,99=>500,100=>556,101=>556,
        102=>278,103=>556,104=>556,105=>222,106=>222,107=>500,108=>222,109=>833,110=>556,
        111=>556,112=>556,113=>556,114=>333,115=>500,116=>278,117=>556,118=>500,119=>722,
        120=>500,121=>500,122=>500,123=>334,124=>260,125=>334,126=>584,
    ];

    public function __construct($landscape = true)
    {
        if (!$landscape) {
            $this->w = 595.28;
            $this->h = 841.89;
        }
        $this->y = $this->h - $this->margin;
        $this->started = true;
    }

    public function pageWidth() { return $this->w - 2 * $this->margin; }
    public function topY()      { return $this->h - $this->margin; }
    public function y()         { return $this->y; }
    public function setY($v)    { $this->y = (float)$v; }
    public function moveUp($n)  { $this->y -= (float)$n; }

    public function newPage()
    {
        $this->pages[] = $this->cur;
        $this->cur = '';
        $this->y = $this->h - $this->margin;
    }

    public function need($n)
    {
        return ($this->y - $n) >= ($this->margin + 20);
    }

    public function page_count()
    {
        return count($this->pages) + ($this->cur !== '' ? 1 : 1);
    }

    // ---------- primitif ----------
    private function op($s) { $this->cur .= $s . "\n"; }

    public function text($x, $y, $str, $size = 8, $bold = false, $gray = 0.1)
    {
        $this->op(sprintf('BT /%s %F Tf %F g 1 0 0 1 %F %F Tm (%s) Tj ET',
            $bold ? 'F2' : 'F1', (float)$size, (float)$gray, (float)$x, (float)$y, self::esc($str)));
    }

    public function rect($x, $y, $w, $h, $grayFill = 0.93)
    {
        $this->op(sprintf('%F g %F %F %F %F re f',
            (float)$grayFill, (float)$x, (float)$y, (float)$w, (float)$h));
    }

    // Isi persegi berwarna (RGB 0..1) - dipakai voucher pembayaran
    public function rectRgb($x, $y, $w, $h, $r, $g, $b)
    {
        $this->op(sprintf('%F %F %F rg %F %F %F %F re f',
            (float)$r, (float)$g, (float)$b, (float)$x, (float)$y, (float)$w, (float)$h));
    }

    public function line($x1, $y1, $x2, $y2, $gray = 0.8, $width = 0.4)
    {
        $this->op(sprintf('%F G %F w %F %F m %F %F l S',
            (float)$gray, (float)$width, (float)$x1, (float)$y1, (float)$x2, (float)$y2));
    }

    // ---------- gambar (JPEG saja) ----------
    // Dipakai untuk kop voucher. Tanpa library eksternal, jadi hanya JPEG
    // yang didukung (ditempel apa adanya, Filter /DCTDecode) dan diletakkan
    // di halaman pertama - cukup untuk kop satu halaman.
    private $imgJpeg = null;

    public function imageJpeg($x, $y, $w, $h, $data)
    {
        $data = (string)$data;
        $ukuran = self::jpegSize($data);
        if (!$ukuran) return false;
        $this->imgJpeg = ['data' => $data, 'w' => (int)$ukuran[0], 'h' => (int)$ukuran[1]];
        $this->op(sprintf('q %F 0 0 %F %F %F cm /Im1 Do Q', (float)$w, (float)$h, (float)$x, (float)$y));
        return true;
    }

    // Baca lebar/tinggi piksel dari header JPEG (marker SOFn).
    public static function jpegSize($data)
    {
        $len = strlen($data);
        if ($len < 4 || substr($data, 0, 2) !== "\xFF\xD8") return null;
        $i = 2;
        while ($i + 9 < $len) {
            if (ord($data[$i]) !== 0xFF) { $i++; continue; }
            $marker = ord($data[$i + 1]);
            if ($marker === 0xD8 || $marker === 0x01 || ($marker >= 0xD0 && $marker <= 0xD7)) { $i += 2; continue; }
            if ($i + 3 >= $len) return null;
            $blok = unpack('n', substr($data, $i + 2, 2))[1];
            if ($marker >= 0xC0 && $marker <= 0xCF && $marker !== 0xC4 && $marker !== 0xC8 && $marker !== 0xCC) {
                if ($i + 9 >= $len) return null;
                $tinggi = unpack('n', substr($data, $i + 5, 2))[1];
                $lebar  = unpack('n', substr($data, $i + 7, 2))[1];
                return [$lebar, $tinggi];
            }
            if ($blok < 2) return null;
            $i += 2 + $blok;
        }
        return null;
    }

    public static function width($str, $size = 8, $bold = false)
    {
        $str = (string)$str;
        $acc = 0;
        for ($i = 0, $len = strlen($str); $i < $len; $i++) {
            $acc += self::$hw[ord($str[$i])] ?? 556;
        }
        return $acc * $size / 1000.0 * ($bold ? 1.05 : 1.0);
    }

    // Potong teks supaya pas di kolom, diberi akhiran ".."
    public static function fit($str, $maxWidth, $size = 8, $bold = false)
    {
        $str = (string)$str;
        if ($str === '' || $maxWidth <= 0) return '';
        if (self::width($str, $size, $bold) <= $maxWidth) return $str;
        $tail = '..';
        $limit = $maxWidth - self::width($tail, $size, $bold);
        $out = '';
        for ($i = 0, $len = strlen($str); $i < $len; $i++) {
            $try = $out . $str[$i];
            if (self::width($try, $size, $bold) > $limit) break;
            $out = $try;
        }
        return $out . $tail;
    }

    // ---------- blok siap pakai ----------
    public function heading($title, $subtitleLines = [])
    {
        $subtitleLines = array_values(array_filter((array)$subtitleLines, function ($v) { return $v !== ''; }));
        $bandH = 30 + count($subtitleLines) * 9.5;
        $x = $this->margin;
        $y = $this->topY();
        $this->rect($x, $y - $bandH, $this->pageWidth(), $bandH, 0.95);
        $this->rect($x, $y - $bandH, 3, $bandH, 0.12);
        $this->text($x + 10, $y - 15, self::fit($title, $this->pageWidth() - 22, 12, true), 12, true);
        foreach ($subtitleLines as $i => $ln) {
            $this->text($x + 10, $y - 26 - $i * 9.5, self::fit($ln, $this->pageWidth() - 22, 7.2, false, 0.3), 7.2, false, 0.3);
        }
        $this->setY($y - $bandH - 9);
    }

    public function sectionTitle($label, $right = '')
    {
        if (!$this->need(16)) $this->newPage();
        $y = $this->y() - 12;
        $this->text($this->margin, $y + 3, self::fit($label, $this->pageWidth() * 0.7, 9, true), 9, true);
        if ($right !== '') {
            $this->text($this->margin + $this->pageWidth() - self::width($right, 8), $y + 3, $right, 8, false, 0.3);
        }
        $this->setY($y);
    }

    public function kvBlock(array $pairs, $labelFrac = 0.16)
    {
        $x0 = $this->margin;
        $lw = $this->pageWidth() * $labelFrac;
        foreach ($pairs as $p) {
            if (!$this->need(9.5)) $this->newPage();
            $y = $this->y() - 9.5;
            $this->text($x0, $y + 2.4, self::fit((string)$p[0], $lw - 6, 7.4, false, 0.35), 7.4, false, 0.35);
            $this->text($x0 + $lw, $y + 2.4, self::fit((string)$p[1], $this->pageWidth() - $lw - 6, 7.4, true), 7.4, true);
            $this->setY($y);
        }
        $this->moveUp(5);
    }

    public function footnote($text)
    {
        if (!$this->need(11)) $this->newPage();
        $y = $this->y() - 9;
        $this->text($this->margin, $y + 2, self::fit($text, $this->pageWidth(), 6.8, false, 0.4), 6.8, false, 0.4);
        $this->setY($y);
    }

    /**
     * $columns: [['label'=>, 'w'=>fraksi|poin, 'align'=>'left|right|center', 't'=>'text|money|num|int|date']]
     * $rows:    array of arrays of nilai mentah
     * $opts:    ['totals_row'=>bool, 'fontSize'=>, 'rowHeight'=>, 'showHeader'=>bool]
     */
    public function table($columns, $rows, array $opts = [])
    {
        $fs     = (float)($opts['fontSize'] ?? 7);
        $rowH   = (float)($opts['rowHeight'] ?? 11.5);
        $headH  = (float)($opts['headHeight'] ?? 13);
        $pad    = 3.2;
        $x0     = $this->margin;
        $avail  = $this->pageWidth();
        $showHeader = !array_key_exists('showHeader', $opts) || $opts['showHeader'];

        $widths = [];
        foreach ($columns as $c) {
            $w = (float)($c['w'] ?? 1);
            $widths[] = $w <= 1 ? $w * $avail : $w;
        }
        $sum = array_sum($widths);
        if ($sum > 0 && abs($sum - $avail) > 0.01) {
            $scale = $avail / $sum;
            foreach ($widths as $i => $wd) $widths[$i] = $wd * $scale;
        }
        $tableW = array_sum($widths);

        $drawHeader = function () use ($columns, $widths, $x0, $tableW, $headH, $fs, $pad) {
            $y = $this->y() - $headH;
            $this->rect($x0, $y, $tableW, $headH, 0.55);
            $cx = $x0;
            foreach ($columns as $i => $col) {
                $label = self::fit(strtoupper((string)($col['label'] ?? '')), $widths[$i] - 2 * $pad, $fs, true);
                $type = $col['t'] ?? 'text';
                $align = $col['align'] ?? (in_array($type, ['money', 'num', 'int'], true) ? 'right' : 'left');
                $tw = self::width($label, $fs, true);
                $tx = $cx + $pad;
                if ($align === 'right')  $tx = $cx + $widths[$i] - $pad - $tw;
                if ($align === 'center') $tx = $cx + ($widths[$i] - $tw) / 2;
                $this->text($tx, $y + $headH / 2 - $fs / 2 - 1, $label, $fs, true, 1.0);
                $cx += $widths[$i];
            }
            $this->setY($y);
        };

        if ($showHeader) $drawHeader();

        $lastIdx = count($rows) - 1;
        foreach ($rows as $ri => $row) {
            $isTotal = !empty($opts['totals_row']) && $ri === $lastIdx;
            if (!$this->need($rowH)) {
                $this->newPage();
                if ($showHeader) $drawHeader();
            }
            $y = $this->y() - $rowH;
            if ($isTotal) {
                $this->rect($x0, $y, $tableW, $rowH, 0.90);
            } elseif ($ri % 2 === 1) {
                $this->rect($x0, $y, $tableW, $rowH, 0.985);
            }

            $cx = $x0;
            foreach ($columns as $ci => $col) {
                $raw = $row[$ci] ?? '';
                if (is_array($raw)) $raw = $raw['v'] ?? '';
                $type = $col['t'] ?? (is_float($raw) ? 'money' : 'text');

                if ($type === 'money')     $txt = number_format((float)$raw, 0, ',', '.');
                elseif ($type === 'num')   $txt = number_format((float)$raw, 2, ',', '.');
                elseif ($type === 'int')   $txt = number_format((float)$raw, 0, ',', '.');
                elseif ($type === 'date')  $txt = (is_string($raw) && $raw !== '' && strtotime($raw)) ? date('d.m.Y', strtotime($raw)) : (string)$raw;
                else                        $txt = (string)$raw;

                $align = $col['align'] ?? (in_array($type, ['money', 'num', 'int'], true) ? 'right' : 'left');
                $txt = self::fit($txt, $widths[$ci] - 2 * $pad, $fs, $isTotal);
                $tw = self::width($txt, $fs, $isTotal);
                $tx = $cx + $pad;
                if ($align === 'right')  $tx = $cx + $widths[$ci] - $pad - $tw;
                if ($align === 'center') $tx = $cx + ($widths[$ci] - $tw) / 2;
                $this->text($tx, $y + $rowH / 2 - $fs / 2 - 0.5, $txt, $fs, $isTotal, $isTotal ? 0.05 : 0.15);
                $cx += $widths[$ci];
            }

            $cx = $x0;
            foreach ($widths as $wd) {
                $this->line($cx, $y, $cx, $y + $rowH, 0.86, 0.3);
                $cx += $wd;
            }
            $this->line($x0, $y, $x0 + $tableW, $y, 0.86, 0.3);
            $this->setY($y);
        }

        $this->line($x0, $this->y(), $x0 + $tableW, $this->y(), 0.4, 0.7);
        $this->moveUp(7);
    }

    // ---------- keluaran ----------
    private static function esc($s)
    {
        $s = (string)$s;
        if (function_exists('mb_convert_encoding')) {
            $conv = @mb_convert_encoding($s, 'Windows-1252', 'UTF-8');
            if (is_string($conv) && $conv !== '') $s = $conv;
        }
        $s = preg_replace('/[^\x20-\x7E\xA0-\xFF]/', '?', (string)$s);
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }

    public function bytes($title = 'Rekapitulasi', $author = 'Purchasing System')
    {
        $pages = $this->pages;
        $pages[] = $this->cur;
        $n = count($pages);

        for ($i = 0; $i < $n; $i++) {
            $right = 'Halaman ' . ($i + 1) . ' dari ' . $n . '   -   dicetak ' . date('d.m.Y H:i');
            $pages[$i] .= sprintf("BT /F1 6.5 Tf 0.45 g 1 0 0 1 %F %F Tm (%s) Tj ET\n",
                $this->margin, 12, self::esc($title));
            $pages[$i] .= sprintf("BT /F1 6.5 Tf 0.45 g 1 0 0 1 %F %F Tm (%s) Tj ET\n",
                max($this->margin, $this->w - $this->margin - self::width($right, 6.5)), 12, self::esc($right));
        }

        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = '';
        for ($i = 0; $i < $n; $i++) $kids .= (6 + $i * 2) . ' 0 R ';
        $objs[2] = '<< /Type /Pages /Kids [' . trim($kids) . '] /Count ' . $n
                 . ' /MediaBox [0 0 ' . rtrim(rtrim(number_format($this->w, 2, '.', ''), '0'), '.') . ' '
                 . rtrim(rtrim(number_format($this->h, 2, '.', ''), '0'), '.') . '] >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        $objs[5] = '<< /Title (' . self::esc($title) . ') /Author (' . self::esc($author) . ')'
                 . ' /Producer (Purchasing Management System) /CreationDate (D:' . date('YmdHis') . ') >>';
        for ($i = 0; $i < $n; $i++) {
            $idPage = 6 + $i * 2;
            $idCont = $idPage + 1;
            $xobj   = $this->imgJpeg ? ' /XObject << /Im1 ' . (6 + $n * 2) . ' 0 R >>' : '';
            $objs[$idPage] = '<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 3 0 R /F2 4 0 R >>' . $xobj . ' >> /Contents ' . $idCont . ' 0 R >>';
            $objs[$idCont] = '<< /Length ' . strlen($pages[$i]) . " >>\nstream\n" . $pages[$i] . "\nendstream";
        }
        if ($this->imgJpeg) {
            $idImg = 6 + $n * 2;
            $objs[$idImg] = '<< /Type /XObject /Subtype /Image /Width ' . $this->imgJpeg['w']
                          . ' /Height ' . $this->imgJpeg['h']
                          . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode'
                          . ' /Length ' . strlen($this->imgJpeg['data'])
                          . " >>\nstream\n" . $this->imgJpeg['data'] . "\nendstream";
        }
        ksort($objs);

        $out = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objs as $id => $body) {
            $offsets[$id] = strlen($out);
            $out .= $id . " 0 obj\n" . $body . "\nendobj\n";
        }
        $size = count($objs) + 1;
        $xrefPos = strlen($out);
        $out .= "xref\n0 $size\n0000000000 65535 f \n";
        for ($id = 1; $id < $size; $id++) {
            $out .= sprintf("%010d 00000 n \n", isset($offsets[$id]) ? $offsets[$id] : 0);
        }
        $out .= "trailer\n<< /Size $size /Root 1 0 R /Info 5 0 R >>\nstartxref\n$xrefPos\n%%EOF\n";
        return $out;
    }

    public function save($path, $title = 'Rekapitulasi')
    {
        return file_put_contents($path, $this->bytes($title)) !== false;
    }

    public function download($filename, $title = 'Rekapitulasi')
    {
        $data = $this->bytes($title);
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', $filename) . '"');
        header('Content-Length: ' . strlen($data));
        header('Cache-Control: no-store');
        echo $data;
        exit;
    }
}
