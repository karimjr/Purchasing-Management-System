<?php if (current_user()): ?>
    </main>
  </div>
</div>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= defined('BASE_URL') ? BASE_URL : '' ?>/assets/js/mobile-tables.js"></script>
</body>
</html>
