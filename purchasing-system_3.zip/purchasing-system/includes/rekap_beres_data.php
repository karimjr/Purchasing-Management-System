<?php
// =========================================================
// Lapisan data REKAPITULASI BERES
// ---------------------------------------------------------
// Dipakai bersama oleh rekap-beres/list.php (tampilan layar)
// dan rekap-beres/export.php (file Excel & PDF). Karena kedua
// halaman memakai fungsi yang sama, angka di layar PERSIS sama
// dengan angka di file hasil ekspor (konvensi yang sama dengan
// rekap_data.php).
//
// Halaman ini HANYA menampilkan transaksi yang sudah "beres":
// status_pembayaran = 'selesai' (Selesai / Done).
//
// Filter utama sekarang SUPPLIER (vendor_id), bukan lagi
// kelompok PIC. Ringkasan per PIC tetap ada dan mengikuti
// filter yang aktif.
// =========================================================

require_once __DIR__ . '/rekap_data.php'; // rekap_sql_net(), rekap_tgl(), rekap_label_periode()

const RB_SORTS = [
    'tanggal_desc' => 'Tanggal terbaru dulu',
    'tanggal_asc'  => 'Tanggal terlama dulu',
    'nilai_desc'   => 'Nilai terbesar dulu',
];

// Label filter supplier untuk judul halaman / file ekspor.
// (Nama supplier diisi oleh rb_fetch() ke $f['supplier_nama'].)
function rb_label_grup(array $f) {
    if (!empty($f['supplier'])) {
        return !empty($f['supplier_nama'])
            ? 'Supplier: ' . $f['supplier_nama']
            : 'Supplier terpilih';
    }
    return 'Semua supplier';
}

// ---------------------------------------------------------
// Baca & bersihkan filter dari query string
// ---------------------------------------------------------
function rb_parse_filters($src, $role = null, $userId = null) {
    $f = [];

    $f['supplier']      = max(0, (int)($src['supplier'] ?? 0));
    $f['supplier_nama'] = '';
    $f['sort']          = (isset($src['sort']) && isset(RB_SORTS[$src['sort']])) ? $src['sort'] : 'tanggal_desc';

    // Periode: pilihan pesat + tanggal eksplisit (logika sama dengan rekap)
    $quick = isset($src['quick']) ? (string)$src['quick'] : '';
    list($dari, $sampai) = rb_quick_range($quick);
    if (isset($src['dari']) && $src['dari'] !== '') $dari = rekap_tgl($src['dari']);
    if (isset($src['sampai']) && $src['sampai'] !== '') $sampai = rekap_tgl($src['sampai']);
    if ($dari && $sampai && $dari > $sampai) { [$dari, $sampai] = [$sampai, $dari]; }
    $f['dari'] = $dari; $f['sampai'] = $sampai;

    $f['daerah'] = isset($src['daerah']) ? trim((string)$src['daerah']) : '';

    $q = isset($src['q']) ? trim((string)$src['q']) : '';
    $q = str_replace(['%', '_'], [' ', ' '], $q);
    $f['q'] = $q;

    // PIC hanya boleh melihat datanya sendiri (sama seperti halaman lain)
    $f['pakai_pic_id'] = ($role === 'pic') ? (int)$userId : 0;

    $f['hal'] = max(1, (int)($src['hal'] ?? 1));
    $pp = (int)($src['per_page'] ?? 25);
    $f['per_page'] = in_array($pp, [25, 50, 100], true) ? $pp : 25;
    $f['semua_baris'] = !empty($src['semua_baris']) || isset($src['export']);

    return $f;
}

// Rentang tanggal untuk tiap pilihan pesat (dipakai untuk
// merender tombolnya dan menandai yang sedang aktif).
function rb_quick_range($quick) {
    switch ($quick) {
        case 'hari_ini':   return [date('Y-m-d'), date('Y-m-d')];
        case 'bulan_lalu': return [
            date('Y-m-01', strtotime('first day of last month')),
            date('Y-m-t',  strtotime('first day of last month')),
        ];
        case '7_hari':     return [date('Y-m-d', strtotime('-6 days')), date('Y-m-d')];
        case '30_hari':    return [date('Y-m-d', strtotime('-29 days')), date('Y-m-d')];
        case 'tahun_ini':  return [date('Y-01-01'), date('Y-12-31')];
        case 'semua':      return [null, null];
        case 'bulan_ini':
        default:           return [date('Y-m-01'), date('Y-m-d')];
    }
}

// ---------------------------------------------------------
// WHERE bersama: SELALU hanya yang sudah beres (dibayar)
// ---------------------------------------------------------
function rb_where(array $f) {
    $w = ["p.status_pembayaran = 'selesai'"];
    $p = [];
    if ($f['dari'])   { $w[] = "p.tanggal >= ?"; $p[] = $f['dari']; }
    if ($f['sampai']) { $w[] = "p.tanggal <= ?"; $p[] = $f['sampai']; }
    if ($f['daerah'] !== '') { $w[] = "p.daerah = ?"; $p[] = $f['daerah']; }
    if ($f['pakai_pic_id'])  { $w[] = "p.pic_id = ?"; $p[] = (string)$f['pakai_pic_id']; }
    if (!empty($f['supplier'])) { $w[] = "p.vendor_id = ?"; $p[] = (string)$f['supplier']; }
    if ($f['q'] !== '') {
        $like = '%' . $f['q'] . '%';
        $w[] = "(p.no_ticket LIKE ? OR p.no_nota LIKE ? OR v.name LIKE ?)";
        array_push($p, $like, $like, $like);
    }
    return [implode(' AND ', $w), $p];
}

function rb_order(array $f) {
    switch ($f['sort']) {
        case 'tanggal_asc': return "p.tanggal ASC, p.id ASC";
        case 'nilai_desc':  return "p.total_harga DESC, p.tanggal DESC";
        default:            return "p.tanggal DESC, p.id DESC";
    }
}

function rb_join() {
    return " FROM purchases p
             JOIN vendors v ON v.id = p.vendor_id
             JOIN users u   ON u.id = p.pic_id ";
}

function rb_select() {
    $net = rekap_sql_net();
    return "SELECT p.*, v.name AS vendor_name, u.name AS pic_name,
                   $net AS nilai_net, (p.total_harga - $net) AS nilai_potongan
            " . rb_join();
}

// ---------------------------------------------------------
// Daftar supplier untuk dropdown (hanya yang punya transaksi
// beres; PIC hanya melihat supplier dari transaksinya sendiri)
// ---------------------------------------------------------
function rb_supplier_list(PDO $pdo, $role = null, $userId = null) {
    $sql = "SELECT DISTINCT v.id, v.name
            FROM purchases p
            JOIN vendors v ON v.id = p.vendor_id
            WHERE p.status_pembayaran = 'selesai'";
    $params = [];
    if ($role === 'pic') { $sql .= " AND p.pic_id = ?"; $params[] = (string)(int)$userId; }
    $sql .= " ORDER BY v.name";
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

// ---------------------------------------------------------
// Ambil semua data: rincian + total + ringkasan per PIC
// ---------------------------------------------------------
function rb_fetch(PDO $pdo, array $f) {
    // Nama supplier terpilih (untuk label judul/ekspor)
    if (!empty($f['supplier'])) {
        $st = $pdo->prepare("SELECT name FROM vendors WHERE id = ?");
        $st->execute([$f['supplier']]);
        $f['supplier_nama'] = (string)$st->fetchColumn();
    }

    list($where, $params) = rb_where($f);
    $net = rekap_sql_net();

    $total = $pdo->prepare(
        "SELECT COUNT(*) AS n,
                COALESCE(SUM(p.berat_basah),0) AS kg,
                COALESCE(SUM(p.total_harga),0) AS bruto,
                COALESCE(SUM($net),0) AS net
         " . rb_join() . " WHERE $where"
    );
    $total->execute($params);
    $t = $total->fetch() ?: ['n' => 0, 'kg' => 0, 'bruto' => 0, 'net' => 0];
    $t['pot'] = max(0, (float)$t['bruto'] - (float)$t['net']);

    // Ringkasan per PIC (mengikuti filter yang aktif)
    $g = $pdo->prepare(
        "SELECT u.name AS pic, COUNT(*) AS n,
                COALESCE(SUM(p.berat_basah),0) AS kg,
                COALESCE(SUM(p.total_harga),0) AS bruto,
                COALESCE(SUM($net),0) AS net
         " . rb_join() . " WHERE $where GROUP BY u.name ORDER BY net DESC"
    );
    $g->execute($params);
    $perPic = $g->fetchAll();
    foreach ($perPic as &$r) {
        $r['pot'] = max(0, (float)$r['bruto'] - (float)$r['net']);
    }
    unset($r);

    $out = ['filters' => $f, 'totals' => $t, 'per_pic' => $perPic, 'rows' => []];

    // Baris rincian
    $sql = rb_select() . " WHERE $where ORDER BY " . rb_order($f);
    if (!$f['semua_baris']) {
        $cnt = $pdo->prepare("SELECT COUNT(*)" . rb_join() . " WHERE $where");
        $cnt->execute($params);
        $out['grand_total'] = (int)$cnt->fetchColumn();
        $out['total_hal']   = max(1, (int)ceil($out['grand_total'] / $f['per_page']));
        $f['hal'] = min($f['hal'], $out['total_hal']);
        $out['filters']['hal'] = $f['hal'];
        $offset = ($f['hal'] - 1) * $f['per_page'];
        $sql .= " LIMIT {$f['per_page']} OFFSET $offset";
    } else {
        $out['grand_total'] = (int)$t['n'];
        $out['total_hal'] = 1;
    }
    $q = $pdo->prepare($sql);
    $q->execute($params);
    $out['rows'] = $q->fetchAll();

    return $out;
}

// ---------------------------------------------------------
// Bangun URL yang mempertahankan semua filter aktif
// ---------------------------------------------------------
function rb_url(array $f, $script, array $override = []) {
    $keep = array_intersect_key($f, array_flip([
        'dari', 'sampai', 'daerah', 'supplier', 'q', 'sort', 'hal', 'per_page',
    ]));
    foreach ($keep as $k => $v) if ($v === '' || $v === null || $v === 0) unset($keep[$k]);
    $qs = http_build_query(array_merge($keep, $override));
    return $script . ($qs ? "?" . $qs : '');
}