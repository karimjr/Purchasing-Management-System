<?php
$role = current_user()['role'] ?? null;
$current = basename($_SERVER['PHP_SELF']);
$currentDir = basename(dirname($_SERVER['PHP_SELF']));
function nav_active($dir, $file, $currentDir, $current) {
    return ($currentDir === $dir && $current === $file) ? 'active' : '';
}
?>
<div class="offcanvas-lg offcanvas-start bg-dark text-white col-lg-2 sidebar" tabindex="-1" id="sidebarOffcanvas">
  <div class="offcanvas-header d-lg-none">
    <h5 class="offcanvas-title text-white">Menu</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#sidebarOffcanvas"></button>
  </div>
  <div class="offcanvas-body d-flex flex-column p-0">
    <ul class="nav nav-pills flex-column mb-auto pt-3">

      <li class="nav-item">
        <a href="<?= BASE_URL ?>/dashboard.php" class="nav-link text-white <?= $current === 'dashboard.php' ? 'active' : '' ?>">
          <i class="bi bi-speedometer2"></i> Dashboard
        </a>
      </li>

      <?php if (in_array($role, ['admin', 'pic', 'petugas', 'finance', 'dirops', 'manajemen'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/pembelian/list.php" class="nav-link text-white <?= nav_active('pembelian', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-cart3"></i> Daftar Pembelian
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'petugas'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/approval/list.php" class="nav-link text-white <?= nav_active('approval', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-check2-square"></i> Approval Pembelian
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'dirops'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/dirops/list.php" class="nav-link text-white <?= nav_active('dirops', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-person-check"></i> Approval Dirops
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'finance'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/finance/list.php" class="nav-link text-white <?= nav_active('finance', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-cash-coin"></i> Pembayaran (Finance)
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'finance', 'dirops'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/voucher/list.php" class="nav-link text-white <?= $currentDir === 'voucher' ? 'active' : '' ?>">
          <i class="bi bi-receipt"></i> Voucher Pembayaran
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'petugas', 'pic', 'finance', 'dirops', 'manajemen'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/harga-harian/list.php" class="nav-link text-white <?= nav_active('harga-harian', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-tag"></i> Harga Harian
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'petugas', 'pic', 'finance', 'dirops', 'manajemen'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/rekap/list.php" class="nav-link text-white <?= nav_active('rekap', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-clipboard-data"></i> Rekapitulasi
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/rekap-beres/list.php" class="nav-link text-white <?= nav_active('rekap-beres', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-patch-check"></i> Rekap Beres
        </a>
      </li>
      <?php endif; ?>

      <?php if (in_array($role, ['admin', 'petugas', 'pic', 'finance', 'manajemen'])): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/vendors/list.php" class="nav-link text-white <?= nav_active('vendors', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-building"></i> Data Supplier
        </a>
      </li>
      <?php endif; ?>

      <?php if ($role === 'admin'): ?>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/users/list.php" class="nav-link text-white <?= nav_active('users', 'list.php', $currentDir, $current) ?>">
          <i class="bi bi-people"></i> Manajemen User
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/settings/whatsapp.php" class="nav-link text-white <?= nav_active('settings', 'whatsapp.php', $currentDir, $current) ?>">
          <i class="bi bi-whatsapp"></i> Pengaturan WhatsApp
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/settings/email-laporan.php" class="nav-link text-white <?= nav_active('settings', 'email-laporan.php', $currentDir, $current) ?>">
          <i class="bi bi-envelope-paper"></i> Pengaturan Email Laporan
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/settings/no-nota.php" class="nav-link text-white <?= nav_active('settings', 'no-nota.php', $currentDir, $current) ?>">
          <i class="bi bi-123"></i> Pengaturan No Nota
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/settings/no-tiket.php" class="nav-link text-white <?= nav_active('settings', 'no-tiket.php', $currentDir, $current) ?>">
          <i class="bi bi-ticket-perforated"></i> Pengaturan No Tiket
        </a>
      </li>
      <li class="nav-item">
        <a href="<?= BASE_URL ?>/settings/voucher.php" class="nav-link text-white <?= nav_active('settings', 'voucher.php', $currentDir, $current) ?>">
          <i class="bi bi-receipt"></i> Pengaturan No Voucher
        </a>
      </li>
      <?php endif; ?>

    </ul>
    <div class="p-3 text-white-50 small border-top border-secondary d-lg-none">
      Masuk sebagai <strong class="text-white"><?= e(current_user()['name']) ?></strong>
    </div>
  </div>
</div>
