<?php
// =========================================================
// Fungsi-fungsi bantuan (helper)
// =========================================================

function redirect($path) {
    header("Location: " . BASE_URL . $path);
    exit;
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function require_login() {
    if (isset($_SESSION['user'])) return;

    // Sesi PHP sudah habis (atau baru buka app lagi setelah lama offline) -
    // coba pulihkan lewat device token yang tersimpan di HP, supaya PIC/Petugas
    // tidak perlu login ulang selama masih memakai HP yang sama.
    global $pdo;
    $token = $_COOKIE['device_token'] ?? null;
    $u = $token ? get_user_by_device_token($pdo, $token) : null;
    if ($u) {
        $_SESSION['user'] = [
            'id' => $u['id'], 'name' => $u['name'],
            'username' => $u['username'], 'role' => $u['role'],
        ];
        renew_device_token($pdo, $token);
        return;
    }

    redirect('/auth/login.php');
}

function require_role($roles) {
    require_login();
    if (!in_array($_SESSION['user']['role'], (array)$roles)) {
        set_flash('danger', 'Anda tidak punya akses ke halaman tersebut.');
        redirect('/dashboard.php');
    }
}

function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function format_rupiah($number) {
    return 'Rp ' . number_format((float)$number, 0, ',', '.');
}

function format_tanggal($date) {
    if (!$date) return '-';
    $ts = strtotime($date);
    return date('d.m.Y', $ts);
}

function format_tanggal_waktu($datetime) {
    if (!$datetime) return '-';
    $ts = strtotime($datetime);
    return date('d.m.Y H:i', $ts);
}

// =========================================================
// URUTAN NOMOR OTOMATIS (No Tiket & No Voucher)
// ---------------------------------------------------------
// Nomor urut disimpan di tabel `number_sequences` (satu baris per seri) dan
// dinaikkan secara ATOMIK memakai trik LAST_INSERT_ID(), jadi tetap benar
// walau beberapa PIC menyimpan bersamaan (nomor tidak pernah kembar).
//
//   name = 'TIKET'             -> No Tiket mode "lanjut terus" (tidak reset sendiri)
//   name = 'TIKET-20261004'    -> No Tiket mode "reset tiap hari"
//   name = 'VOUCHER-202610'    -> No Voucher per bulan
//
// Admin bisa mengatur / mereset counter ini dari menu:
//   Pengaturan No Tiket   (settings/no-tiket.php)
//   Pengaturan No Voucher (settings/voucher.php)
//
// Kalau tabel `number_sequences` belum ada (migrasi belum dijalankan),
// aplikasi TIDAK error - otomatis kembali memakai cara lama
// (nomor terbesar yang ada + 1).
// =========================================================

function seq_tersedia($pdo) {
    static $ada = null;
    if ($ada === null) {
        try {
            $pdo->query("SELECT 1 FROM number_sequences LIMIT 1");
            $ada = true;
        } catch (Exception $e) {
            $ada = false;
        }
    }
    return $ada;
}

// Ambil nomor berikutnya SEKALIGUS menaikkan counter (aman dari race condition).
function seq_berikut($pdo, $name) {
    $stmt = $pdo->prepare("INSERT INTO number_sequences (name, counter) VALUES (?, LAST_INSERT_ID(1))
                            ON DUPLICATE KEY UPDATE counter = LAST_INSERT_ID(counter + 1)");
    $stmt->execute([$name]);
    return (int)$pdo->query("SELECT LAST_INSERT_ID()")->fetchColumn();
}

// Intip nomor berikutnya TANPA menaikkan counter (untuk tampilan/pratinjau).
function seq_intip($pdo, $name) {
    $stmt = $pdo->prepare("SELECT counter FROM number_sequences WHERE name = ?");
    $stmt->execute([$name]);
    $last = $stmt->fetchColumn();
    return ($last === false || $last === null) ? 1 : ((int)$last + 1);
}

// Tentukan nomor berikutnya (mis. Admin ingin lanjut dari 100 -> isi 101).
function seq_set($pdo, $name, $berikutnya) {
    $berikutnya = max(1, (int)$berikutnya);
    $stmt = $pdo->prepare("INSERT INTO number_sequences (name, counter) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE counter = VALUES(counter)");
    $stmt->execute([$name, $berikutnya - 1]);
}

// Kembalikan counter ke 0 -> nomor berikutnya mulai dari 1 lagi.
function seq_reset($pdo, $name) {
    $stmt = $pdo->prepare("INSERT INTO number_sequences (name, counter) VALUES (?, 0)
                            ON DUPLICATE KEY UPDATE counter = 0");
    $stmt->execute([$name]);
}

// ---------- No Tiket ----------

// Pengaturan pola & mode No Tiket (diatur Admin di Pengaturan No Tiket).
function no_ticket_pengaturan($pdo) {
    $mode = (string)get_app_setting($pdo, 'no_ticket_mode', 'lanjut');
    if (!in_array($mode, ['lanjut', 'harian'], true)) $mode = 'lanjut';
    // Pola bawaan: Ranger-0001, Ranger-0002, ... (tanpa kode tanggal).
    $pola = (string)get_app_setting($pdo, 'no_ticket_pola', 'Ranger-{NNNN}');
    if (!no_ticket_pola_valid($pola)) $pola = 'Ranger-{NNNN}';
    return ['mode' => $mode, 'pola' => $pola];
}

// Pola wajib memuat {NNNN} (jumlah N = jumlah digit, mis. {NNNNN} = 5 digit).
// Kode tanggal yang dikenal: {YYYYMMDD} {DDMMYYYY} {YYYYMM} {YYYY} {MM} {DD}
function no_ticket_pola_valid($pola) {
    $pola = trim((string)$pola);
    if ($pola === '' || strlen($pola) > 60) return false;
    if (!preg_match('/\{N+\}/', $pola)) return false;
    $sisa = preg_replace('/\{(YYYYMMDD|DDMMYYYY|YYYYMM|YYYY|MM|DD|N+)\}/', '', $pola);
    if (strpos($sisa, '{') !== false || strpos($sisa, '}') !== false) return false;
    return (bool)preg_match('/^[A-Za-z0-9\._\-\/ ]*$/', $sisa);
}

// Susun nomor tiket dari pola, mis. Ranger-{NNNN} -> Ranger-0007, atau
// TCK-{YYYYMMDD}-{NNNN} -> TCK-20261004-0007 (kalau pola lama masih dipakai)
function no_ticket_format($pola, $ts, $urut) {
    $out = strtr((string)$pola, [
        '{YYYYMMDD}' => date('Ymd', $ts),
        '{DDMMYYYY}' => date('dmY', $ts),
        '{YYYYMM}'   => date('Ym', $ts),
        '{YYYY}'     => date('Y', $ts),
        '{MM}'       => date('m', $ts),
        '{DD}'       => date('d', $ts),
    ]);
    return preg_replace_callback('/\{N+\}/', function ($m) use ($urut) {
        $lebar = strlen($m[0]) - 2;                 // {NNNN} -> 4 digit
        return str_pad((string)$urut, $lebar, '0', STR_PAD_LEFT);
    }, $out);
}

// Nama seri counter: satu seri untuk semua hari, atau satu seri per hari.
function no_ticket_kunci($mode, $ts) {
    return $mode === 'harian' ? 'TIKET-' . date('Ymd', $ts) : 'TIKET';
}

function no_ticket_dipakai($pdo, $no) {
    $stmt = $pdo->prepare("SELECT 1 FROM purchases WHERE no_ticket = ? LIMIT 1");
    $stmt->execute([$no]);
    return (bool)$stmt->fetchColumn();
}

// Nomor tiket berikutnya yang benar-benar masih kosong (melewati nomor
// yang sudah terpakai, mis. setelah Admin menurunkan counter).
function no_ticket_urut_kosong($pdo, $kunci, $pola, $ts, $mulai) {
    $urut = (int)$mulai;
    for ($i = 0; $i < 500; $i++) {
        if (!no_ticket_dipakai($pdo, no_ticket_format($pola, $ts, $urut))) return $urut;
        $urut++;
    }
    return $urut;
}

// Cara lama (nomor terbesar + 1) - dipakai kalau tabel number_sequences belum ada.
// Contoh pola "Ranger-{NNNN}" -> mencari angka terbesar dari nomor Ranger-xxxx
// yang sudah ada, lalu menambah 1.
function generate_no_ticket_lama($pdo, $ts = null) {
    $ts  = $ts ?: time();
    $set = no_ticket_pengaturan($pdo);
    // Pola dijadikan pola pencarian LIKE: placeholder tanggal & {N+} -> '%'
    $like = preg_replace('/\{(?:YYYYMMDD|DDMMYYYY|YYYYMM|YYYY|MM|DD|N+)\}/', '%', $set['pola']);
    $stmt = $pdo->prepare("SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(no_ticket, '-', -1) AS UNSIGNED)), 0)
                             FROM purchases WHERE no_ticket LIKE ?");
    $stmt->execute([$like]);
    $urut = ((int)$stmt->fetchColumn()) + 1;
    return no_ticket_format($set['pola'], $ts, $urut);
}

/**
 * Nomor tiket baru: otomatis, berurutan, tidak reset sendiri.
 * $tanggal = tanggal tiket (bawaan: hari ini) untuk bagian tanggal pada pola.
 */
function generate_no_ticket($pdo, $tanggal = null) {
    $ts = $tanggal ? strtotime($tanggal) : time();
    if (!$ts) $ts = time();
    if (!seq_tersedia($pdo)) return generate_no_ticket_lama($pdo, $ts);

    $set   = no_ticket_pengaturan($pdo);
    $kunci = no_ticket_kunci($set['mode'], $ts);
    for ($coba = 0; $coba < 100; $coba++) {
        $urut = seq_berikut($pdo, $kunci);
        $no   = no_ticket_format($set['pola'], $ts, $urut);
        if (!no_ticket_dipakai($pdo, $no)) return $no;
    }
    return generate_no_ticket_lama($pdo, $ts);   // jaring pengaman
}

// Info counter untuk halaman Pengaturan No Tiket / pratinjau di form input.
function no_ticket_info($pdo, $tanggal = null) {
    $ts = $tanggal ? strtotime($tanggal) : time();
    if (!$ts) $ts = time();
    $set   = no_ticket_pengaturan($pdo);
    $kunci = no_ticket_kunci($set['mode'], $ts);
    $info  = [
        'mode'       => $set['mode'],
        'pola'       => $set['pola'],
        'kunci'      => $kunci,
        'tersedia'   => seq_tersedia($pdo),
        'terakhir'   => 0,
        'berikutnya' => 1,
        'contoh'     => '',
    ];
    if ($info['tersedia']) {
        $info['terakhir'] = max(0, seq_intip($pdo, $kunci) - 1);
        $urut = no_ticket_urut_kosong($pdo, $kunci, $set['pola'], $ts, seq_intip($pdo, $kunci));
        $info['berikutnya'] = $urut;
        $info['contoh']     = no_ticket_format($set['pola'], $ts, $urut);
    } else {
        $info['contoh'] = generate_no_ticket_lama($pdo, $ts);
    }
    return $info;
}

// Admin: tetapkan nomor tiket berikutnya.
function no_ticket_set_berikutnya($pdo, $nomor, $tanggal = null) {
    if (!seq_tersedia($pdo)) return false;
    $ts    = $tanggal ? strtotime($tanggal) : time();
    $set   = no_ticket_pengaturan($pdo);
    seq_set($pdo, no_ticket_kunci($set['mode'], $ts), max(1, (int)$nomor));
    return true;
}

// Admin: reset counter -> nomor berikutnya mulai dari 1.
function no_ticket_reset_counter($pdo, $tanggal = null) {
    if (!seq_tersedia($pdo)) return false;
    $ts  = $tanggal ? strtotime($tanggal) : time();
    $set = no_ticket_pengaturan($pdo);
    seq_reset($pdo, no_ticket_kunci($set['mode'], $ts));
    return true;
}

function log_activity($pdo, $purchase_id, $action, $keterangan = null) {
    $userId = current_user()['id'] ?? null;
    if (!$userId) return;
    // purchase_logs punya foreign key ke purchases(id): kalau id tiket tidak valid
    // (mis. lastInsertId dibaca setelah pernyataan lain), INSERT akan melempar
    // PDOException dan mengubah halaman yang sudah sukses jadi HTTP 500.
    // Catatan aktivitas tidak boleh menjatuhkan transaksi, jadi dijaga di sini.
    if ((int)$purchase_id <= 0) return;
    $stmt = $pdo->prepare("INSERT INTO purchase_logs (purchase_id, user_id, action, keterangan) VALUES (?, ?, ?, ?)");
    $stmt->execute([$purchase_id, $userId, $action, $keterangan]);
}

function total_setelah_pajak($row) {
    $gross = (float)($row['total_harga'] ?? 0);
    $stored = (float)($row['total_setelah_pajak'] ?? 0);
    if ($stored > 0) return $stored;
    $rate = isset($row['persentase_pajak']) && (float)$row['persentase_pajak'] > 0
        ? (float)$row['persentase_pajak']
        : (!empty($row['punya_npwp']) ? 0.25 : 0.50);
    return round($gross * (1 - $rate / 100), 2);
}

function total_potongan_pajak($row) {
    return max(0, (float)($row['total_harga'] ?? 0) - total_setelah_pajak($row));
}

function badge_approval($status) {
    $map = [
        'menunggu'  => ['secondary', 'Menunggu Approval'],
        'disetujui' => ['success', 'Disetujui'],
        'ditolak'   => ['danger', 'Ditolak'],
        'revisi_harga' => ['warning', 'Diminta Revisi Harga'],
    ];
    [$color, $label] = $map[$status] ?? ['secondary', $status];
    return "<span class=\"badge text-bg-$color\">$label</span>";
}

function badge_pembayaran($status) {
    $map = [
        'belum_diajukan'      => ['secondary', 'Belum Diajukan'],
        'sudah_diajukan_ho'   => ['primary', 'Sudah Diajukan ke HO'],
        'menunggu_pembayaran' => ['warning', 'Menunggu Pembayaran'],
        'sedang_diproses'     => ['info', 'Sedang Diproses'],
        'selesai'             => ['success', 'Selesai / Done'],
        'gagal'               => ['danger', 'Gagal'],
        'dibatalkan'          => ['dark', 'Dibatalkan'],
    ];
    [$color, $label] = $map[$status] ?? ['secondary', $status];
    return "<span class=\"badge text-bg-$color\">$label</span>";
}

function badge_finance_approval($status) {
    $map = [
        'menunggu' => ['secondary', 'Menunggu Approval Finance'],
        'disetujui' => ['success', 'Disetujui Finance'],
        'ditolak' => ['danger', 'Ditolak Finance'],
    ];
    [$color, $label] = $map[$status] ?? ['secondary', $status];
    return "<span class=\"badge text-bg-$color\">$label</span>";
}

function badge_dirops($status) {
    $map = [
        'menunggu'  => ['secondary', 'Menunggu Approval Dirops'],
        'disetujui' => ['success', 'Disetujui Dirops'],
        'ditolak'   => ['danger', 'Ditolak Dirops'],
    ];
    [$color, $label] = $map[$status] ?? ['secondary', $status];
    return "<span class=\"badge text-bg-$color\">$label</span>";
}

function role_label($role) {
    $map = [
        'admin'   => 'Administrator',
        'petugas' => 'Petugas (Approval)',
        'pic'     => 'PIC',
        'finance' => 'Finance',
        'dirops'  => 'Direktur Operasional',
        'manajemen' => 'Manajemen (View Only)',
    ];
    return $map[$role] ?? $role;
}

// Upload foto pembelian, mengembalikan nama file atau null
// ------------------------------------------------------------
// Foto "Bokar & Dokumen Pendukung" - satu tiket boleh banyak foto (v12)
//
// Aturan yang dipakai bersama semua halaman (tambah, edit, sync offline, galeri):
//   * purchases.foto            = FOTO UTAMA, tidak berubah perannya -> daftar,
//                                 approval, Dirops, rekap, dan ekspor lama tetap jalan.
//   * purchase_fotos (tabel baru) = dokumen tambahan. Kalau migrasi v12 belum
//                                 dijalankan, kode otomatis mundur ke mode satu foto
//                                 (tidak error, hanya tambahan yang tidak tersimpan).
//   * validasi SATU path saja: ekstensi, ukuran (FOTO_MAKS_BYTES), dan penamaan berkas ada di
//     foto_simpan_satuan() - handle_photo_upload() (lama) dan mode banyak berkas
//     memakai fungsi yang sama, jadi aturannya tidak bisa berbeda.
// ------------------------------------------------------------
define('FOTO_MAKS_TAMBAHAN', 8);
// Batas ukuran PER BERKAS di sisi aplikasi (byte). 0 = aplikasi tidak membatasi sama sekali
// (yang tersisa hanya batas server: upload_max_filesize & post_max_size di PHP).
// Mau membatasi lagi? Ganti angkanya, mis. 20 * 1024 * 1024 untuk 20 MB.
if (!defined('FOTO_MAKS_BYTES')) define('FOTO_MAKS_BYTES', 0);

function foto_ekstensi_diizinkan()
{
    return ['jpg', 'jpeg', 'png', 'webp'];
}

// uniqid() saja bisa bentrok kalau beberapa berkas diproses pada microsecond yang
// sama (upload banyak foto = perulangan), jadi ditambah acakan 3 byte.
function foto_nama_baru($ext)
{
    return 'foto_' . uniqid() . bin2hex(random_bytes(3)) . '.' . strtolower($ext);
}

function foto_pesan_upload_error($code)
{
    $messages = [
        UPLOAD_ERR_INI_SIZE   => 'Ukuran foto melebihi batas yang diizinkan server hosting. Coba pilih foto lain atau pastikan aplikasi sudah versi terbaru (foto seharusnya otomatis dikompres sebelum dikirim).',
        UPLOAD_ERR_FORM_SIZE  => 'Ukuran foto melebihi batas maksimal formulir.',
        UPLOAD_ERR_PARTIAL    => 'Foto hanya terunggah sebagian. Coba unggah ulang (mungkin koneksi terputus di tengah proses).',
        UPLOAD_ERR_NO_TMP_DIR => 'Server tidak punya folder sementara untuk upload. Hubungi administrator hosting.',
        UPLOAD_ERR_CANT_WRITE => 'Server gagal menyimpan foto ke disk. Hubungi administrator hosting.',
        UPLOAD_ERR_EXTENSION  => 'Upload foto dihentikan oleh pengaturan server (ekstensi PHP).',
    ];
    return $messages[$code] ?? ('Gagal mengunggah foto (kode error: ' . $code . ').');
}

// Simpan SATU berkas upload ke folder uploads. null = memang tidak ada berkas.
function foto_simpan_satuan($file, $uploadDir)
{
    if (!is_array($file) || !isset($file['error']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception(foto_pesan_upload_error($file['error']));
    }
    $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    if (!in_array($ext, foto_ekstensi_diizinkan(), true)) {
        throw new Exception('Format foto harus JPG, JPEG, PNG, atau WEBP.');
    }
    if (FOTO_MAKS_BYTES > 0 && (int)$file['size'] > FOTO_MAKS_BYTES) {
        throw new Exception('Ukuran foto maksimal ' . round(FOTO_MAKS_BYTES / 1048576) . ' MB.');
    }
    $newName = foto_nama_baru($ext);
    $target = rtrim($uploadDir, '/') . '/' . $newName;
    if (!move_uploaded_file($file['tmp_name'], $target)) {
        throw new Exception('Gagal menyimpan file foto ke server.');
    }
    return $newName;
}

// Kalau kiriman POST lebih besar dari post_max_size server, PHP membuang $_POST dan
// $_FILES seluruhnya (bukan hanya fotonya) - tanpa penjaga ini PIC melihat error
// "Tanggal wajib diisi" padahal yang bermasalah ukuran fotonya. Karena upload
// banyak berkas melipatgandakan ukuran, kasus ini nyata di shared hosting 2 MB.
// php.ini menulis ukuran dengan akhiran (post_max_size = 8M), BUKAN angka murni,
// jadi '8M' harus diurai sendiri - is_numeric('8M') itu false.
function upload_ukuran_php($nilai)
{
    $nilai = trim((string)$nilai);
    if ($nilai === '') {
        return 0;
    }
    $kali = ['K' => 1024, 'M' => 1048576, 'G' => 1073741824];
    $unit = strtoupper(substr($nilai, -1));
    if (isset($kali[$unit])) {
        return is_numeric(substr($nilai, 0, -1)) ? (int)((float)substr($nilai, 0, -1) * $kali[$unit]) : 0;
    }
    return is_numeric($nilai) ? (int)$nilai : 0;
}

// Pengaturan kompres foto di HP mengikuti batas kiriman server yang SEBENARNYA.
// Server longgar (post_max_size >= 32 MB, atau tanpa batas) -> foto dipertahankan tajam.
// Server masih ketat (mis. hosting 2 MB) -> tetap dikecilkan agresif seperti sebelumnya,
// jadi tidak ada yang rusak kalau hosting ternyata mengabaikan pengaturan baru.
// 'postMax' = batas kiriman dalam byte (0 = tanpa batas) untuk peringatan di layar.
function foto_kompres_opsi($banyak = true)
{
    $postMax = upload_ukuran_php(ini_get('post_max_size'));
    $longgar = ($postMax === 0 || $postMax >= 32 * 1048576);
    if ($longgar) {
        return ['maxDimension' => 2400, 'quality' => 0.88, 'postMax' => $postMax];
    }
    return $banyak
        ? ['maxDimension' => 1400, 'quality' => 0.68, 'postMax' => $postMax]
        : ['maxDimension' => 1600, 'quality' => 0.75, 'postMax' => $postMax];
}

function upload_pesan_post_kebesaran()
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        return null;
    }
    $panjang = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    $batas = upload_ukuran_php(ini_get('post_max_size'));
    // Hanya dituduh kalau panjang kiriman memang mencapai batasnya. Tanpa pembanding ini,
    // POST kosong yang kecil (misal form terkirim tanpa field) ikut dibilang kebesaran.
    if ($panjang <= 0 || !empty($_POST) || !empty($_FILES) || $batas <= 0 || $panjang < $batas) {
        return null;
    }
    $batas = (string)(ini_get('post_max_size') ?: '');
    $upload = (string)(ini_get('upload_max_filesize') ?: '');
    return 'Total kiriman ' . round($panjang / 1048576, 1) . ' MB melebihi batas server'
         . ($batas !== '' ? ' (post_max_size: ' . $batas . ($upload !== '' ? ', upload_max_filesize: ' . $upload : '') . ')' : '')
         . ', sehingga PHP menolak seluruh data (tidak ada satu pun field yang tersisa). '
         . 'Kurangi jumlah foto dalam satu kali simpan - misalnya simpan tiketnya dengan 2 foto lebih dulu, '
         . 'sisa dokumennya tambahkan lewat tombol "Tambah Foto Bokar / Dokumen Pendukung" di halaman detail tiket.';
}

// PHP memberi bentuk berbeda untuk <input name="foto"> dan <input name="fotos[]">.
// Diseragamkan jadi daftar berkas supaya satu kode memproses keduanya.
function foto_files_normalisasi($inputName)
{
    $out = [];
    if (!isset($_FILES[$inputName])) {
        return $out;
    }
    $f = $_FILES[$inputName];
    if (!is_array($f['name'])) {
        return [$f];
    }
    foreach (array_keys($f['name']) as $i) {
        $out[] = [
            'name'     => $f['name'][$i],
            'type'     => $f['type'][$i] ?? '',
            'tmp_name' => $f['tmp_name'][$i] ?? '',
            'error'    => $f['error'][$i] ?? UPLOAD_ERR_NO_FILE,
            'size'     => $f['size'][$i] ?? 0,
        ];
    }
    return $out;
}

// Versi lama (satu foto) - tetap dipakai halaman edit untuk mengganti foto utama.
function handle_photo_upload($fileInputName, $uploadDir)
{
    $daftar = foto_files_normalisasi($fileInputName);
    return foto_simpan_satuan($daftar[0] ?? null, $uploadDir);
}

// Versi banyak foto. Mengembalikan ['files' => [nama berkas...], 'errors' => [pesan...]].
// Berkas yang gagal tidak membatalkan berkas lain (misal 1 dari 3 salah format:
// dua tetap tersimpan, yang salah dilaporkan) - supaya PIC tidak perlu mengulang
// seluruh formulir kalau ada satu foto yang bermasalah.
// Field lama name="foto" tetap diterima, jadi HP yang masih membuka halaman
// versi lama (cache) tidak kehilangan foto.
// $maks = berapa berkas yang masih boleh diterima (di halaman tambah = 1 foto utama
// + FOTO_MAKS_TAMBAHAN, di halaman tambah-belakangan = sisanya saja), dan
// $pesanLebihan dipakai kalau pemanggil punya kalimat yang lebih pas daripada
// "maksimal N dokumen per tiket" (mis. "sisa kuota tiket ini 2 berkas").
function handle_photo_upload_multi($uploadDir, $maks = FOTO_MAKS_TAMBAHAN, $pesanLebihan = null)
{
    $hasil = ['files' => [], 'errors' => []];
    $daftar = foto_files_normalisasi('fotos');
    if (!$daftar) {
        $daftar = foto_files_normalisasi('foto');
    }
    foreach ($daftar as $f) {
        if (isset($f['error']) && $f['error'] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if (count($hasil['files']) >= $maks) {
            $hasil['errors'][] = $pesanLebihan ?: ('Maksimal ' . $maks . ' dokumen per tiket - berkas sisanya tidak disimpan.');
            break;
        }
        try {
            $nama = foto_simpan_satuan($f, $uploadDir);
            if ($nama !== null) {
                $hasil['files'][] = $nama;
            }
        } catch (Exception $e) {
            $hasil['errors'][] = 'Foto "' . (string)($f['name'] ?? 'tanpa nama') . '" tidak disimpan: ' . $e->getMessage();
        }
    }
    return $hasil;
}

function purchase_fotos_tersedia($pdo)
{
    static $ada = null;
    if ($ada === null) {
        try {
            $pdo->query("SELECT 1 FROM purchase_fotos LIMIT 1");
            $ada = true;
        } catch (Exception $e) {
            $ada = false;
        }
    }
    return $ada;
}

// Catat dokumen tambahan sebuah tiket. ['tersimpan' => n, 'pesan' => string|null]
function purchase_fotos_simpan($pdo, $purchaseId, array $names, $userId, $uploadDir = null)
{
    $hasil = ['tersimpan' => 0, 'pesan' => null];
    if (!$names) {
        return $hasil;
    }
    $purchaseId = (int)$purchaseId;
    if ($purchaseId <= 0 || !purchase_fotos_tersedia($pdo)) {
        if ($uploadDir !== null) {
            foreach ($names as $nm) {
                @unlink(rtrim($uploadDir, '/') . '/' . $nm);
            }
        }
        $hasil['pesan'] = 'Dokumen tambahan belum bisa disimpan: tabel purchase_fotos belum ada. '
                        . 'Jalankan migration_v12_foto_multi.sql di phpMyAdmin (foto utama tetap tersimpan seperti biasa).';
        return $hasil;
    }
    $stmt = $pdo->prepare("INSERT INTO purchase_fotos (purchase_id, file, uploaded_by, created_at) VALUES (?, ?, ?, NOW())");
    foreach ($names as $nm) {
        $stmt->execute([$purchaseId, $nm, (int)$userId]);
        $hasil['tersimpan']++;
    }
    return $hasil;
}

// Isi galeri: foto utama lebih dulu, lalu dokumen tambahan urut masuk.
// Unsur foto utama selalu 'id' => 0 dan tidak bisa dihapus dari galeri
// (untuk menggantinya: tombol Edit, sesuai perilaku lama).
function purchase_fotos($pdo, $purchase)
{
    $fotos = [];
    if (!empty($purchase['foto'])) {
        $fotos[] = [
            'id' => 0, 'file' => $purchase['foto'], 'utama' => 1,
            'oleh' => null, 'waktu' => $purchase['created_at'] ?? null,
        ];
    }
    if (!empty($purchase['id']) && purchase_fotos_tersedia($pdo)) {
        $stmt = $pdo->prepare("SELECT f.id, f.file, f.created_at, u.name AS user_name
                                FROM purchase_fotos f
                                LEFT JOIN users u ON u.id = f.uploaded_by
                                WHERE f.purchase_id = ?
                                ORDER BY f.id ASC");
        $stmt->execute([(int)$purchase['id']]);
        foreach ($stmt->fetchAll() as $r) {
            $fotos[] = [
                'id' => (int)$r['id'], 'file' => $r['file'], 'utama' => 0,
                'oleh' => $r['user_name'], 'waktu' => $r['created_at'],
            ];
        }
    }
    return $fotos;
}

function purchase_fotos_jumlah($pdo, array $purchaseIds)
{
    $jumlah = [];
    $purchaseIds = array_values(array_unique(array_map('intval', $purchaseIds)));
    if (!$purchaseIds || !purchase_fotos_tersedia($pdo)) {
        return $jumlah;
    }
    $placeholder = implode(',', array_fill(0, count($purchaseIds), '?'));
    $stmt = $pdo->prepare("SELECT purchase_id, COUNT(*) AS n FROM purchase_fotos
                            WHERE purchase_id IN ($placeholder) GROUP BY purchase_id");
    $stmt->execute($purchaseIds);
    foreach ($stmt->fetchAll() as $r) {
        $jumlah[(int)$r['purchase_id']] = (int)$r['n'];
    }
    return $jumlah;
}

// Versi hemat-query untuk halaman daftar: sekali query IN(...) untuk semua tiket
// di halaman itu, hasilnya dipetakan per purchase_id (foto utama tetap paling dulu).
function purchase_fotos_batch($pdo, array $purchases)
{
    $hasil = [];
    $ids = [];
    foreach ($purchases as $p) {
        $pid = (int)($p['id'] ?? 0);
        if ($pid <= 0) continue;
        $ids[] = $pid;
        if (!empty($p['foto'])) {
            $hasil[$pid][] = ['id' => 0, 'file' => $p['foto'], 'utama' => 1, 'oleh' => null, 'waktu' => $p['created_at'] ?? null];
        }
    }
    // Daftar kosong bukan berarti tidak ada dokumen: foto utama bisa saja tidak ada
    // (mis. tiket lama tanpa foto) sementara tambahanannya ada, jadi query tetap jalan.
    if (!$ids || !purchase_fotos_tersedia($pdo)) {
        return $hasil;
    }
    $placeholder = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT f.purchase_id, f.id, f.file, f.created_at, u.name AS user_name
                            FROM purchase_fotos f
                            LEFT JOIN users u ON u.id = f.uploaded_by
                            WHERE f.purchase_id IN ($placeholder)
                            ORDER BY f.purchase_id ASC, f.id ASC");
    $stmt->execute($ids);
    foreach ($stmt->fetchAll() as $r) {
        $hasil[(int)$r['purchase_id']][] = [
            'id' => (int)$r['id'], 'file' => $r['file'], 'utama' => 0,
            'oleh' => $r['user_name'], 'waktu' => $r['created_at'],
        ];
    }
    return $hasil;
}

// Kartu galeri yang sama dipakai detail.php, approval/process.php, dirops/process.php,
// finance (lewat detail) - supaya tampilan & aturan "boleh hapus" tidak berbeda antar halaman.
function foto_galeri_html($photos, $opts = [])
{
    if (!$photos) {
        return '';
    }
    $bolehHapus  = !empty($opts['boleh_hapus']);
    $purchaseId  = (int)($opts['purchase_id'] ?? 0);
    $judulSeksi  = $opts['judul'] ?? 'Foto Bokar &amp; Dokumen Pendukung';
    $out  = '<div class="mt-3">';
    $out .= '<span class="label d-block text-success fw-semibold mb-2"><i class="bi bi-images"></i> ' . $judulSeksi
           . ' <span class="badge text-bg-light">' . count($photos) . '</span></span>';
    $out .= '<div class="row g-2">';
    $nomor = 1;
    foreach ($photos as $p) {
        $url = BASE_URL . '/uploads/' . e($p['file']);
        $label = !empty($p['utama']) ? 'Foto utama' : 'Dokumen ' . (++$nomor);
        $ket = [];
        if (!empty($p['oleh']))  $ket[] = e($p['oleh']);
        if (!empty($p['waktu'])) $ket[] = e(format_tanggal_waktu($p['waktu']));
        $bawah = '<span class="text-truncate">' . $label . ($ket ? ' &middot; ' . implode(' &middot; ', $ket) : '') . '</span>';
        if ($bolehHapus && empty($p['utama']) && $purchaseId > 0) {
            $bawah .= '<form method="post" action="' . BASE_URL . '/pembelian/foto-hapus.php" class="d-inline flex-shrink-0"'
                    . ' onsubmit="return confirm(\'Hapus dokumen ini dari tiket?\')">'
                    . '<input type="hidden" name="id" value="' . $purchaseId . '">'
                    . '<input type="hidden" name="foto_id" value="' . (int)$p['id'] . '">'
                    . '<button type="submit" class="btn btn-sm btn-link text-danger p-0" title="Hapus dokumen ini"><i class="bi bi-trash"></i></button>'
                    . '</form>';
        }
        $out .= '<div class="col-6 col-md-3">'
              .   '<div class="border rounded p-1 h-100 bg-white">'
              .     '<a href="' . $url . '" target="_blank" rel="noopener" class="d-block" title="Klik untuk memperbesar">'
              .       '<img src="' . $url . '" class="foto-thumb w-100" style="height:104px" alt="' . $label . '">'
              .     '</a>'
              .     '<div class="small text-muted d-flex justify-content-between align-items-center gap-1 mt-1">' . $bawah . '</div>'
              .   '</div>'
              . '</div>';
    }
    $out .= '</div>';
    $out .= '<div class="form-text mt-1">Klik foto untuk membuka ukuran penuh. '
           . 'Kamera HP yang menghasilkan berkas besar aman: foto dikompres di HP sebelum dikirim.</div>';
    $out .= '</div>';
    return $out;
}

// DRC = (Harga Basah / Harga Notaring/Harga Harian Kering) x 100, dalam persen
function calculate_drc($hargaBasah, $hargaNotaring) {
    if (!$hargaNotaring || (float)$hargaNotaring <= 0) return null;
    return round(((float)$hargaBasah / (float)$hargaNotaring) * 100, 2);
}

// =========================================================
// Device Token (untuk mode offline / PWA di HP PIC)
// =========================================================

// Dibuat saat login berhasil, disimpan sebagai cookie yang bisa dibaca JS
// (bukan httponly) supaya bisa dilampirkan sebagai header saat auto-sync,
// dan tetap berlaku walau sesi PHP di server sudah kadaluarsa karena PIC
// lama tidak ada sinyal di lapangan.
function issue_device_token($pdo, $userId, $days = 90) {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime("+{$days} days"));
    $stmt = $pdo->prepare("INSERT INTO device_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$userId, $token, $expires]);

    $cookiePath = defined('BASE_URL') && BASE_URL !== '' ? BASE_URL . '/' : '/';
    setcookie('device_token', $token, [
        'expires'  => time() + ($days * 86400),
        'path'     => $cookiePath,
        'secure'   => true,
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
    return $token;
}

// "Sliding expiration": setiap kali token dipakai (buka app / sync), masa
// berlakunya digeser maju lagi. Jadi selama HP dibuka minimal sekali setiap
// ~90 hari, PIC/Petugas praktis TIDAK PERNAH ke-logout otomatis.
function renew_device_token($pdo, $token, $days = 90) {
    if (!$token) return;
    $expires = date('Y-m-d H:i:s', strtotime("+{$days} days"));
    $stmt = $pdo->prepare("UPDATE device_tokens SET expires_at = ? WHERE token = ?");
    $stmt->execute([$expires, $token]);

    $cookiePath = defined('BASE_URL') && BASE_URL !== '' ? BASE_URL . '/' : '/';
    setcookie('device_token', $token, [
        'expires'  => time() + ($days * 86400),
        'path'     => $cookiePath,
        'secure'   => true,
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
}

function revoke_device_token($pdo, $token) {
    if (!$token) return;
    $stmt = $pdo->prepare("DELETE FROM device_tokens WHERE token = ?");
    $stmt->execute([$token]);
}

function get_user_by_device_token($pdo, $token) {
    if (!$token) return null;
    $stmt = $pdo->prepare("SELECT u.id, u.name, u.username, u.role FROM device_tokens t
                            JOIN users u ON u.id = t.user_id
                            WHERE t.token = ? AND t.expires_at > NOW() AND u.is_active = 1");
    $stmt->execute([$token]);
    return $stmt->fetch() ?: null;
}

// Autentikasi untuk endpoint API (dipakai saat auto-sync data offline).
// Coba sesi browser biasa dulu; kalau tidak ada / sudah kadaluarsa, coba
// device token yang dikirim lewat header X-Device-Token atau field POST.
function api_auth($pdo) {
    $user = current_user();
    if ($user) return $user;

    $token = $_SERVER['HTTP_X_DEVICE_TOKEN'] ?? ($_POST['device_token'] ?? null);
    $u = get_user_by_device_token($pdo, $token);
    if ($u) {
        $_SESSION['user'] = [
            'id' => $u['id'], 'name' => $u['name'],
            'username' => $u['username'], 'role' => $u['role'],
        ];
        renew_device_token($pdo, $token);
        return $_SESSION['user'];
    }
    return null;
}

// Kirim response JSON dan langsung berhenti
function json_response($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function e($str) {
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

// =========================================================
// Notifikasi
// =========================================================

// Kirim notifikasi ke satu user tertentu
function create_notification($pdo, $userId, $message, $url = null, $purchaseId = null, $type = 'info') {
    if (!$userId) return;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, purchase_id, type, message, url) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$userId, $purchaseId, $type, $message, $url]);
}

// Kirim notifikasi ke semua user dengan role tertentu (bisa lebih dari satu role).
// $excludeUserId dipakai supaya user yang sedang melakukan aksi (mis. admin
// yang bertindak sebagai petugas) tidak dikirimi notifikasi atas aksinya sendiri.
function notify_role($pdo, $roles, $message, $url = null, $purchaseId = null, $type = 'info', $excludeUserId = null) {
    $roles = (array)$roles;
    $placeholders = implode(',', array_fill(0, count($roles), '?'));
    $sql = "SELECT id FROM users WHERE role IN ($placeholders) AND is_active = 1";
    $params = $roles;
    if ($excludeUserId) {
        $sql .= " AND id != ?";
        $params[] = $excludeUserId;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $userIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($userIds as $uid) {
        create_notification($pdo, $uid, $message, $url, $purchaseId, $type);
    }
}

// Jumlah notifikasi belum dibaca milik user yang sedang login
function count_unread_notifications($pdo, $userId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

// Notifikasi terbaru milik user (untuk dropdown lonceng di navbar)
function get_recent_notifications($pdo, $userId, $limit = 8) {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT " . (int)$limit);
    $stmt->execute([$userId]);
    return $stmt->fetchAll();
}

// Waktu relatif sederhana (mis. "5 menit lalu") untuk tampilan notifikasi
function time_ago($datetime) {
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'Baru saja';
    if ($diff < 3600) return floor($diff / 60) . ' menit lalu';
    if ($diff < 86400) return floor($diff / 3600) . ' jam lalu';
    if ($diff < 2592000) return floor($diff / 86400) . ' hari lalu';
    return format_tanggal($datetime);
}

// =========================================================
// Pengaturan Aplikasi (app_settings) - dipakai untuk konfigurasi
// gateway WhatsApp, disimpan di DB supaya bisa diatur lewat Admin
// tanpa perlu edit file/kode.
// =========================================================

function get_app_settings($pdo) {
    static $cache = null;
    if ($cache !== null) return $cache;
    $cache = [];
    try {
        $rows = $pdo->query("SELECT setting_key, setting_value FROM app_settings")->fetchAll();
        foreach ($rows as $r) {
            $cache[$r['setting_key']] = $r['setting_value'];
        }
    } catch (Exception $e) {
        // Tabel belum ada (migrasi belum dijalankan) - anggap kosong,
        // supaya halaman lain tetap jalan tanpa fitur WA.
        $cache = [];
    }
    return $cache;
}

function get_app_setting($pdo, $key, $default = null) {
    $settings = get_app_settings($pdo);
    return $settings[$key] ?? $default;
}

function set_app_setting($pdo, $key, $value) {
    $stmt = $pdo->prepare("INSERT INTO app_settings (setting_key, setting_value) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    $stmt->execute([$key, $value]);
}

// =========================================================
// Notifikasi WhatsApp
// =========================================================

// Rapikan nomor WA ke format internasional 62xxxxxxxxxx (tanpa spasi/simbol/+),
// supaya cocok dengan format yang diminta kebanyakan gateway WA Indonesia.
function normalize_wa_number($phone) {
    $phone = trim((string)$phone);
    if ($phone === '') return null;
    $digits = preg_replace('/\D+/', '', $phone);
    if ($digits === '') return null;
    if (substr($digits, 0, 1) === '0') {
        $digits = '62' . substr($digits, 1);
    } elseif (substr($digits, 0, 2) !== '62') {
        $digits = '62' . $digits;
    }
    return $digits;
}

// Kirim satu pesan WhatsApp lewat gateway yang dikonfigurasi Admin
// (menu Pengaturan > WhatsApp). Gagal kirim TIDAK melempar exception -
// supaya proses approval/pembayaran di aplikasi tetap lanjut & tersimpan
// walau WA-nya gagal terkirim (misal kuota gateway habis/token salah).
// Semua percobaan kirim (sukses/gagal) dicatat di tabel wa_logs.
function send_whatsapp($pdo, $phone, $message, $purchaseId = null, $userId = null) {
    $enabled = get_app_setting($pdo, 'wa_enabled', '0');
    $target = normalize_wa_number($phone);

    if (!$target) {
        return false; // tidak ada nomor WA yang valid untuk user ini
    }

    if ($enabled !== '1') {
        log_wa($pdo, $userId, $purchaseId, $target, $message, 'nonaktif', 'Notifikasi WhatsApp belum diaktifkan di Pengaturan.');
        return false;
    }

    $apiUrl = get_app_setting($pdo, 'wa_api_url', '');
    $apiToken = get_app_setting($pdo, 'wa_api_token', '');

    if ($apiUrl === '' || $apiToken === '') {
        log_wa($pdo, $userId, $purchaseId, $target, $message, 'gagal', 'API URL / Token gateway WhatsApp belum diisi di Pengaturan.');
        return false;
    }

    try {
        // Format request kompatibel dengan gateway WA Indonesia gaya
        // Fonnte/Wablas: POST target=<no_hp>&message=<pesan>, header token/Authorization.
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query([
                'target' => $target,
                'message' => $message,
                'countryCode' => '62',
            ]),
            CURLOPT_HTTPHEADER => [
                'Authorization: ' . $apiToken,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            log_wa($pdo, $userId, $purchaseId, $target, $message, 'gagal', 'cURL error: ' . $curlError);
            return false;
        }

        $status = ($httpCode >= 200 && $httpCode < 300) ? 'sukses' : 'gagal';
        log_wa($pdo, $userId, $purchaseId, $target, $message, $status, "HTTP $httpCode: " . substr((string)$response, 0, 500));
        return $status === 'sukses';
    } catch (Exception $e) {
        log_wa($pdo, $userId, $purchaseId, $target, $message, 'gagal', $e->getMessage());
        return false;
    }
}

function log_wa($pdo, $userId, $purchaseId, $phone, $message, $status, $response = null) {
    try {
        $stmt = $pdo->prepare("INSERT INTO wa_logs (user_id, purchase_id, phone, message, status, response) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $purchaseId, $phone, $message, $status, $response]);
    } catch (Exception $e) {
        // Tabel wa_logs belum ada (migrasi belum dijalankan) - abaikan saja.
    }
}

// Kirim WA ke semua user aktif dengan role tertentu yang punya nomor WA
// terdaftar. Dipakai di setiap tahap alur approval supaya orang yang
// berikutnya harus bertindak langsung dapat pengingat di WhatsApp-nya.
function notify_role_wa($pdo, $roles, $message, $purchaseId = null, $excludeUserId = null) {
    $roles = (array)$roles;
    $placeholders = implode(',', array_fill(0, count($roles), '?'));
    $sql = "SELECT id, whatsapp FROM users WHERE role IN ($placeholders) AND is_active = 1 AND whatsapp IS NOT NULL AND whatsapp <> ''";
    $params = $roles;
    if ($excludeUserId) {
        $sql .= " AND id != ?";
        $params[] = $excludeUserId;
    }
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
    foreach ($users as $u) {
        send_whatsapp($pdo, $u['whatsapp'], $message, $purchaseId, $u['id']);
    }
}

// Kirim WA ke satu user tertentu (mis. PIC pemilik data), kalau dia
// punya nomor WA terdaftar.
function notify_user_wa($pdo, $userId, $message, $purchaseId = null) {
    if (!$userId) return;
    $stmt = $pdo->prepare("SELECT id, whatsapp FROM users WHERE id = ? AND is_active = 1");
    $stmt->execute([$userId]);
    $u = $stmt->fetch();
    if ($u && !empty($u['whatsapp'])) {
        send_whatsapp($pdo, $u['whatsapp'], $message, $purchaseId, $u['id']);
    }
}

// =========================================================
// Reminder WhatsApp berjenjang (PIC -> Petugas -> Dirops -> Finance)
// Dipanggil oleh cron/wa_reminder.php (dijadwalkan via Cron Job hosting)
// atau tombol "Kirim Reminder Sekarang" di halaman Pengaturan WhatsApp.
// Mengingatkan ULANG pihak yang belum bertindak kalau sudah lebih lama
// dari ambang batas jam (wa_reminder_hours) sejak tahap sebelumnya
// selesai / sejak reminder terakhir dikirim untuk tahap yang sama.
// =========================================================
function run_wa_reminders($pdo) {
    $hours = (int)get_app_setting($pdo, 'wa_reminder_hours', 4);
    if ($hours < 1) $hours = 4;
    $result = ['petugas' => 0, 'finance' => 0, 'dirops' => 0];
    $stages = [
        ['petugas', "status_approval = 'menunggu'", 'created_at', 'petugas', 'Permisi Bapak/Ibu Petugas, mohon kesediaannya untuk memeriksa dan memberikan persetujuan atas pembelian %s dari PIC %s. Apabila data dan dokumen sudah sesuai, mohon kiranya dapat diproses. Terima kasih atas bantuan dan waktunya.'],
        ['finance', "status_approval = 'disetujui' AND status_finance_approval = 'menunggu'", 'approved_at', 'finance', 'Permisi Bapak/Ibu Finance, mohon dibantu verifikasi dan approval pembelian %s dari PIC %s yang telah disetujui Petugas. Setelah itu mohon dilanjutkan permintaan approval kepada Direktur Operasional. Terima kasih.'],
        ['dirops', "status_finance_approval = 'disetujui' AND status_dirops = 'menunggu'", 'finance_approval_at', 'dirops', 'Permisi Bapak/Ibu Direktur Operasional, mohon dibantu approval pembelian %s dari PIC %s yang telah diverifikasi Petugas dan disetujui Finance. Mohon disertakan catatan apabila belum dapat disetujui. Terima kasih.'],
        ['finance', "status_dirops = 'disetujui' AND status_pembayaran IN ('sudah_diajukan_ho','menunggu_pembayaran','sedang_diproses')", 'dirops_at', 'finance', 'Permisi Bapak/Ibu Finance, mohon dibantu menindaklanjuti pembelian %s yang telah disetujui Direktur Operasional. Mohon diperbarui statusnya apakah sudah diajukan ke HO, sedang diproses, selesai, batal, atau gagal. Terima kasih.'],
    ];
    foreach ($stages as [$role, $where, $dateCol, $stage, $template]) {
        $stmt = $pdo->prepare("SELECT p.*, u.name AS pic_name FROM purchases p JOIN users u ON u.id = p.pic_id WHERE $where AND $dateCol IS NOT NULL AND $dateCol <= DATE_SUB(NOW(), INTERVAL ? HOUR) AND (last_reminder_stage IS NULL OR last_reminder_stage <> ? OR last_reminder_at <= DATE_SUB(NOW(), INTERVAL ? HOUR))");
        $stmt->execute([$hours, $stage, $hours]);
        foreach ($stmt->fetchAll() as $p) {
            $msg = sprintf($template, $p['no_ticket'], $p['pic_name']);
            notify_role_wa($pdo, [$role], $msg, $p['id']);
            mark_reminder($pdo, $p['id'], $stage);
            $result[$role]++;
        }
    }
    return $result;
}

// Bangun link wa.me dengan pesan yang sudah terisi otomatis, dipakai
// untuk tombol "Kirim WA" manual (klik tombol -> buka WhatsApp dengan
// pesan siap kirim, tanpa lewat gateway API).
function wa_link($phone, $message) {
    $target = normalize_wa_number($phone);
    if (!$target) return null;
    return 'https://wa.me/' . $target . '?text=' . rawurlencode($message);
}

// Ambil daftar user aktif dengan role tertentu yang punya nomor WA
// terdaftar, dipakai untuk menampilkan tombol WA manual per-orang di
// halaman detail pembelian.
function get_users_with_wa($pdo, $roles) {
    $roles = (array)$roles;
    $placeholders = implode(',', array_fill(0, count($roles), '?'));
    // Jangan tampilkan tombol reminder ke akun yang sedang login sendiri.
    // User tidak perlu mengirim pengingat WhatsApp kepada dirinya sendiri.
    $currentUser = current_user();
    $sql = "SELECT id, name, whatsapp FROM users
            WHERE role IN ($placeholders) AND is_active = 1
            AND whatsapp IS NOT NULL AND whatsapp <> ''";
    $params = $roles;
    if ($currentUser && !empty($currentUser['id'])) {
        $sql .= " AND id <> ?";
        $params[] = $currentUser['id'];
    }
    $sql .= " ORDER BY name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

// =========================================================
// No Nota Otomatis
// Nomor urut sederhana (1, 2, 3, ...) dibuat otomatis oleh sistem
// memakai AUTO_INCREMENT tabel no_nota_sequence (supaya aman dari race
// condition kalau ada beberapa PIC input bersamaan). Admin bisa reset
// balik ke 0 dari menu Pengaturan No Nota.
// =========================================================
function generate_no_nota($pdo) {
    $pdo->exec("INSERT INTO no_nota_sequence (created_at) VALUES (NOW())");
    return (string) $pdo->lastInsertId();
}

function reset_no_nota_counter($pdo, $startAt = 0) {
    $pdo->exec("DELETE FROM no_nota_sequence");
    $next = max(1, (int)$startAt + 1);
    $pdo->exec("ALTER TABLE no_nota_sequence AUTO_INCREMENT = $next");
}

function get_no_nota_counter_info($pdo) {
    $last = $pdo->query("SELECT MAX(id) FROM no_nota_sequence")->fetchColumn();
    $last = $last ? (int)$last : 0;
    $row = $pdo->query("SHOW TABLE STATUS LIKE 'no_nota_sequence'")->fetch();
    $nextAuto = $row ? (int)$row['Auto_increment'] : $last + 1;
    return ['last' => $last, 'next' => $nextAuto];
}

function mark_reminder($pdo, $purchaseId, $stage) {
    $stmt = $pdo->prepare("UPDATE purchases SET last_reminder_stage = ?, last_reminder_at = NOW() WHERE id = ?");
    $stmt->execute([$stage, $purchaseId]);
}
// terhadap sebuah pembelian, mengikuti alur PIC -> Petugas -> Dirops -> Finance.
// Dipakai bersama oleh halaman list (Daftar Pembelian, Approval, Approval
// Dirops, Pembayaran Finance) untuk menampilkan tombol WA manual yang konsisten.
// Return: ['role' => 'petugas'|'dirops'|'finance'|null, 'message' => string]
function wa_next_stage($row) {
    if ($row['status_approval'] === 'menunggu') return ['role'=>'petugas', 'message'=>"Permisi Bapak/Ibu Petugas, mohon kesediaannya untuk memeriksa dan memberikan persetujuan atas pembelian {$row['no_ticket']} dari PIC {$row['pic_name']} (Supplier: {$row['vendor_name']}, Nilai: " . format_rupiah($row['total_harga']) . "). Apabila data sudah sesuai, mohon kiranya dapat diproses. Terima kasih atas bantuan dan waktunya."];
    if ($row['status_approval'] === 'disetujui' && ($row['status_finance_approval'] ?? 'menunggu') === 'menunggu') return ['role'=>'finance', 'message'=>"Permisi Bapak/Ibu Finance, mohon dibantu verifikasi dan approval pembelian {$row['no_ticket']} dari PIC {$row['pic_name']} (Supplier: {$row['vendor_name']}, Nilai: " . format_rupiah($row['total_harga']) . "). Setelah disetujui, mohon dilanjutkan permintaan approval kepada Direktur Operasional. Terima kasih."];
    if (($row['status_finance_approval'] ?? 'menunggu') === 'disetujui' && $row['status_dirops'] === 'menunggu') return ['role'=>'dirops', 'message'=>"Permisi Bapak/Ibu Direktur Operasional, mohon dibantu approval pembelian {$row['no_ticket']} dari PIC {$row['pic_name']} yang telah diverifikasi Petugas dan disetujui Finance. Mohon diberikan keputusan beserta catatan bila belum disetujui. Terima kasih."];
    if ($row['status_dirops'] === 'disetujui' && !in_array($row['status_pembayaran'], ['selesai','dibatalkan'])) return ['role'=>'finance', 'message'=>"Permisi Bapak/Ibu Finance, terkait tiket pembelian {$row['no_ticket']} dari PIC {$row['pic_name']} (Supplier: {$row['vendor_name']}, Nilai: " . format_rupiah($row['total_harga']) . "), telah saya setujui. Silakan dilanjutkan ke proses pembayaran sesuai prosedur. Mohon dibantu untuk memperbarui statusnya apabila sudah diajukan ke HO, sedang diproses, selesai, atau terdapat kendala. Terima kasih."];
    return ['role'=>null, 'message'=>''];
}

// Render tombol/dropdown WA manual (HTML) untuk satu baris pembelian,
// berdasar $waUsersByRole yang sudah di-cache (get_users_with_wa per role).
function render_wa_button($row, $waUsersByRole) {
    $next = wa_next_stage($row);
    if (!$next['role'] || empty($waUsersByRole[$next['role']])) return '';
    $currentUser = current_user();
    $currentUserId = $currentUser['id'] ?? null;
    $candidates = array_values(array_filter(
        $waUsersByRole[$next['role']],
        static function ($candidate) use ($currentUserId) {
            return !$currentUserId || (int)$candidate['id'] !== (int)$currentUserId;
        }
    ));
    if (empty($candidates)) return '';
    $msg = $next['message'];
    if (count($candidates) === 1) {
        $link = e(wa_link($candidates[0]['whatsapp'], $msg));
        $name = e($candidates[0]['name']);
        return "<a href=\"$link\" target=\"_blank\" rel=\"noopener\" class=\"btn btn-sm btn-success\" title=\"Kirim WA ke $name\"><i class=\"bi bi-whatsapp\"></i></a>";
    }
    $items = '';
    foreach ($candidates as $c) {
        $link = e(wa_link($c['whatsapp'], $msg));
        $name = e($c['name']);
        $items .= "<li><a class=\"dropdown-item\" href=\"$link\" target=\"_blank\" rel=\"noopener\">WA ke $name</a></li>";
    }
    return "<div class=\"dropdown d-inline-block\">
        <button class=\"btn btn-sm btn-success dropdown-toggle\" type=\"button\" data-bs-toggle=\"dropdown\" title=\"Kirim WA\"><i class=\"bi bi-whatsapp\"></i></button>
        <ul class=\"dropdown-menu\">$items</ul>
    </div>";
}

// =========================================================
// DATA SUPPLIER
// =========================================================
// Label supplier untuk dropdown / tampilan: "Nama (No. ID)".
// No. ID dibuat manual (kolom `kode`), jadi kalau belum diisi
// cukup tampilkan namanya saja.
function supplier_label($nama, $kode = '') {
    $nama = (string)$nama;
    $kode = trim((string)$kode);
    return $kode === '' ? $nama : $nama . ' (' . $kode . ')';
}

// Apakah kolom `kode` (No. ID Supplier) sudah ada di database?
// Dipakai supaya aplikasi tetap jalan walau migrasi v17 belum dijalankan.
function supplier_kode_tersedia($pdo) {
    static $ada = null;
    if ($ada === null) {
        try {
            $pdo->query("SELECT kode FROM vendors LIMIT 1");
            $ada = true;
        } catch (Exception $e) {
            $ada = false;
        }
    }
    return $ada;
}
