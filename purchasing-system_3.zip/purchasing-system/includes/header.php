<?php
// Expects $pageTitle to be set before including this file
$user = current_user();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<?php
// ---- aset khusus iPhone / iPad (Add to Home Screen) ----
// Gambar-gambar ini dibangun oleh purchasing-system-apk/make-ios-assets.py.
// Kalau salah satu berkas belum ada di server, tag-nya tidak merusak apa pun:
// iOS hanya gagal memuat gambar itu lalu memakai tampilan bawaan.
$iosV     = '11';
$iosIkon  = [180 => 'apple-touch-icon.png', 152 => 'apple-touch-icon-152.png', 167 => 'apple-touch-icon-167.png'];
// (berkas, lebar pt, tinggi pt, skala) -> media query persis seperti yang diminta iOS
$iosSplash = [
    ['750x1334',  375,  667, 2], ['828x1792',  414,  896, 2], ['1170x2532',  390,  844, 3],
    ['1179x2556', 393,  852, 3], ['1284x2778', 428,  926, 3], ['1290x2796', 430,  932, 3],
    ['1320x2868', 440,  956, 3], ['1668x2388', 834, 1194, 2], ['2048x2732', 1024, 1366, 2],
];
?>
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<meta name="app-base-url" content="<?= BASE_URL ?>">
<meta name="theme-color" content="#1e8449">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Purchasing CBS">
<link rel="manifest" href="<?= BASE_URL ?>/manifest.json">
<?php foreach ($iosIkon as $pt => $nama): ?>
<link rel="apple-touch-icon" sizes="<?= $pt ?>x<?= $pt ?>" href="<?= BASE_URL ?>/assets/icons/<?= $nama ?>?v=<?= $iosV ?>">
<?php endforeach; ?>
<?php foreach ($iosSplash as $sp): list($ukuran, $w, $h, $dpr) = $sp; ?>
<link rel="apple-touch-startup-image" media="(device-width: <?= $w ?>px) and (device-height: <?= $h ?>px) and (-webkit-device-pixel-ratio: <?= $dpr ?>) and (orientation: portrait)" href="<?= BASE_URL ?>/assets/icons/splash-<?= $ukuran ?>.png?v=<?= $iosV ?>">
<?php endforeach; ?>
    <link rel="icon" type="image/png" sizes="48x48" href="<?= BASE_URL ?>/assets/icons/favicon-48.png?v=10">
<title><?= isset($pageTitle) ? e($pageTitle) . ' - ' : '' ?>Purchasing Management System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css?v=<?= @filemtime(__DIR__ . '/../assets/css/style.css') ?: time() ?>">
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('<?= BASE_URL ?>/service-worker.js', { scope: '<?= BASE_URL ?>/' })
      .catch(function (err) { console.warn('SW register gagal:', err); });
  });
}
</script>
</head>
<body>
<?php if ($user): ?>
<nav class="navbar navbar-expand-lg navbar-dark app-navbar sticky-top">
  <div class="container-fluid">
    <button class="btn btn-link text-white d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebarOffcanvas">
      <i class="bi bi-list fs-3"></i>
    </button>
    <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/dashboard.php">
      <i class="bi bi-truck"></i> Purchasing System
    </a>
    <div class="ms-auto d-flex align-items-center gap-3">
      <?php
        $notifUnreadCount = count_unread_notifications($pdo, $user['id']);
        $notifRecent = get_recent_notifications($pdo, $user['id'], 8);
      ?>
      <div class="dropdown">
        <a href="#" class="notif-bell" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          <i class="bi bi-bell fs-5"></i>
          <?php if ($notifUnreadCount > 0): ?>
            <span class="notif-dot"><?= $notifUnreadCount > 9 ? '9+' : $notifUnreadCount ?></span>
          <?php endif; ?>
        </a>
        <ul class="dropdown-menu dropdown-menu-end notif-dropdown shadow">
          <li class="px-3 py-2 border-bottom d-flex justify-content-between align-items-center">
            <span class="fw-bold">Notifikasi</span>
            <?php if ($notifUnreadCount > 0): ?>
              <a href="<?= BASE_URL ?>/notifications/mark_all.php" class="small text-decoration-none">Tandai semua dibaca</a>
            <?php endif; ?>
          </li>
          <?php if (!$notifRecent): ?>
            <li class="px-3 py-4 text-center text-muted small">Belum ada notifikasi.</li>
          <?php endif; ?>
          <?php foreach ($notifRecent as $n): ?>
            <li>
              <a class="dropdown-item notif-item <?= $n['is_read'] ? '' : 'unread' ?> px-3 py-2" href="<?= BASE_URL ?>/notifications/read.php?id=<?= $n['id'] ?>">
                <span class="<?= $n['is_read'] ? '' : 'fw-semibold' ?>"><?= e($n['message']) ?></span>
                <small><?= time_ago($n['created_at']) ?></small>
              </a>
            </li>
          <?php endforeach; ?>
          <li class="border-top">
            <a href="<?= BASE_URL ?>/notifications/list.php" class="dropdown-item text-center py-2 small fw-semibold">
              Lihat semua notifikasi
            </a>
          </li>
        </ul>
      </div>
      <span class="text-white-50 d-none d-sm-inline">
        <?= e($user['name']) ?> &middot; <span class="badge text-bg-light text-dark"><?= e(role_label($user['role'])) ?></span>
      </span>
      <a href="<?= BASE_URL ?>/auth/logout.php" class="btn btn-outline-light btn-sm">
        <i class="bi bi-box-arrow-right"></i> Keluar
      </a>
    </div>
  </div>
</nav>
<div class="container-fluid">
  <div class="row">
    <?php include __DIR__ . '/sidebar.php'; ?>
    <main class="col-lg-10 ms-sm-auto px-md-4 py-4">
      <?php $flash = get_flash(); if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
          <?= e($flash['message']) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
<?php endif; ?>
