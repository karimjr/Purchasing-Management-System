<?php
// =========================================================
// Laporan pembayaran selesai ke HO (email -> Outlook)
// ---------------------------------------------------------
// Setelah sebuah tiket selesai diproses (status pembayaran =
// "Selesai / Done"), Finance (Pak Sabar) tinggal klik satu tombol
// dan Outlook terbuka dengan email yang sudah terisi otomatis
// untuk diteruskan ke Pak Arnold.
//
// Bawaannya TIDAK ada pengiriman email dari server (tidak butuh SMTP/mail()
// yang sering diblokir shared hosting) - tombol hanya menyiapkan mailto: dan
// menyediakan berkas .eml, sehingga mengikuti aplikasi email di HP/laptop
// pemakainya. Admin boleh mengaktifkan kirim lewat mail() (kunci
// ho_email_kirim_server) untuk pemakaian dari PWA/APK yang tidak bisa
// membuka aplikasi email; selain itu tidak ada email yang dikirim diam-diam.
// =========================================================

const HO_EMAIL_DEFAULTS = [
    'ho_email_enabled'  => '1',
    'ho_email_kirim_server' => '0',
    'ho_email_dari'     => '',
    'ho_email_to'       => 'arnold.parulian@arsari.co.id',
    'ho_email_cc'       => '',
    'ho_email_nama'     => 'Pak Arnold',
    'ho_email_scheme'   => 'mailto',
    // Rute khusus laptop/komputer:
    //   'auto'    = coba New Outlook (ms-outlook://) -> mailto: -> Outlook di browser,
    //               yang berhasil diingat di perangkat itu (bawaan)
    //   'outlook' = paksa New Outlook saja (ms-outlook://)
    //   'web'     = langsung Outlook di browser (deep link compose)
    //   'mailto'  = serahkan ke aplikasi email default Windows
    //   'pilih'   = tawarkan pilihan tiap kali
    'ho_email_laptop'   => 'auto',
    'ho_email_web_host' => 'outlook.office.com',
    'ho_email_subjek'   => 'Laporan Pembayaran Selesai - No Tiket {no_ticket} (No Nota {no_nota})',
    'ho_email_badan'    => "Dengan hormat {ho_nama},\r\n\r\n"
        . "Menyusul selesainya seluruh proses approval, kami sampaikan bahwa tiket pembelian berikut SUDAH DILAKUKAN TRANSAKSI dan SUDAH DIBAYAR:\r\n\r\n"
        . "No. Tiket     : {no_ticket}\r\n"
        . "No. Nota      : {no_nota}\r\n"
        . "Tanggal/Daerah: {tanggal} / {daerah}\r\n"
        . "PIC / Supplier  : {pic} / {vendor}\r\n"
        . "Berat / Harga : {berat} KG x {harga_basah}\r\n"
        . "Notaring / DRC: {harga_notaring} / {drc}\r\n"
        . "Nilai transaksi : {bruto}\r\n"
        . "Pajak {pajak} : {potongan}\r\n"
        . "DIBAYARKAN    : {netto}\r\n"
        . "Terbilang      : {netto_terbilang}\r\n\r\n"
        . "Approval      : Petugas {petugas} -> Finance {finance_appr} -> Dirops {dirops}\r\n"
        . "Status / tgl  : {status} per {dibayar_pada}\r\n"
        . "Catatan Dirops: {catatan_dirops}\r\n"
        . "Catatan Finance: {catatan_finance}\r\n\r\n"
        . "Rincian tiket: {app_url}\r\n\r\n"
        . "Demikian laporan ini kami sampaikan untuk diketahui dan dicatat di HO. Terima kasih.\r\n\r\n"
        . "{finance} - Finance\r\nPurchasing Management System",
];

// Gabungan nilai bawaan dengan nilai yang disimpan Admin di app_settings.
// Nilai '0' dari checkbox harus dihormati (bukan dianggap "kosong").
function ho_settings(PDO $pdo)
{
    $s = [];
    foreach (HO_EMAIL_DEFAULTS as $k => $def) {
        $v = get_app_setting($pdo, $k, null);
        $s[$k] = ($v === null || $v === '') ? $def : $v;
    }
    $s['ho_email_enabled'] = (get_app_setting($pdo, 'ho_email_enabled', '1') === '0') ? '0' : '1';
    return $s;
}

// Tautan tiket di aplikasi, ikut dicantumkan supaya HO bisa cek rincian
function ho_app_url(array $purchase)
{
    if (!defined('BASE_URL')) return '';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($host === '') return '';
    return ($https ? 'https' : 'http') . '://' . $host . BASE_URL . '/pembelian/detail.php?id=' . (int)$purchase['id'];
}

// Angka dengan pemisah Indonesia, desimal nol di belakang dibuang (807,00 -> 807)
function ho_angka($v, $dec = 2)
{
    $s = number_format((float)$v, $dec, ',', '.');
    if ($dec > 0) $s = rtrim(rtrim($s, '0'), ',');
    return $s;
}

// ---------- terbilang (untuk "transaksi sekian-sekian") ----------
function terbilang($n)
{
    $digit = ['', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan',
              'sepuluh', 'sebelas'];
    $cari = function ($x) use (&$cari, $digit) {
        $x = (int)$x;
        if ($x < 11)    return $digit[$x];
        if ($x < 20)    return $cari($x - 10) . ' belas';
        if ($x < 100)   return trim($cari(intdiv($x, 10)) . ' puluh ' . $cari($x % 10));
        if ($x < 200)   return 'seratus ' . $cari($x - 100);
        if ($x < 1000)  return trim($cari(intdiv($x, 100)) . ' ratus ' . $cari($x % 100));
        if ($x < 2000)  return 'seribu ' . $cari($x - 1000);
        if ($x < 1000000) return trim($cari(intdiv($x, 1000)) . ' ribu ' . $cari($x % 1000));
        if ($x < 1000000000) return trim($cari(intdiv($x, 1000000)) . ' juta ' . $cari($x % 1000000));
        return trim($cari(intdiv($x, 1000000000)) . ' miliar ' . $cari($x % 1000000000));
    };
    $n = (int)round((float)$n);
    if ($n === 0) return 'nol';
    $kata = $cari(abs($n));
    $kata = preg_replace('/\s+/', ' ', trim($kata));
    return ($n < 0 ? 'minus ' : '') . ucfirst($kata) . ' rupiah';
}

// ---------- isi placeholder template ----------
function ho_vars(array $purchase, array $set)
{
    $net = total_setelah_pajak($purchase);
    return [
        '{ho_nama}'        => $set['ho_email_nama'],
        '{no_ticket}'      => (string)$purchase['no_ticket'],
        '{no_nota}'        => (string)$purchase['no_nota'],
        '{tanggal}'        => format_tanggal($purchase['tanggal']),
        '{daerah}'         => (string)$purchase['daerah'],
        '{pic}'            => (string)($purchase['pic_name'] ?? ''),
        '{vendor}'         => (string)($purchase['vendor_name'] ?? ''),
        '{berat}'          => ho_angka($purchase['berat_basah']),
        '{harga_basah}'    => format_rupiah($purchase['harga_basah']),
        '{harga_notaring}' => format_rupiah($purchase['harga_notaring']),
        '{drc}'            => number_format((float)$purchase['drc'], 2, ',', '.') . ' %',
        '{bruto}'          => format_rupiah($purchase['total_harga']),
        '{pajak}'          => number_format((float)$purchase['persentase_pajak'], 2, ',', '.') . '% (' . ($purchase['punya_npwp'] ? 'NPWP' : 'tanpa NPWP') . ')',
        '{potongan}'       => format_rupiah(total_potongan_pajak($purchase)),
        '{netto}'          => format_rupiah($net),
        '{netto_terbilang}'=> terbilang($net),
        '{status}'         => 'Selesai / Sudah Dibayar (' . date('d.m.Y', strtotime($purchase['processed_at'] ?: 'now')) . ')',
        '{dibayar_pada}'   => $purchase['processed_at'] ? format_tanggal_waktu($purchase['processed_at']) : '-',
        '{finance}'        => (string)($purchase['finance_name'] ?? (current_user()['name'] ?? '')),
        '{petugas}'        => (string)($purchase['petugas_name'] ?? ''),
        '{finance_appr}'   => (string)($purchase['finance_appr_name'] ?? ''),
        '{dirops}'         => (string)($purchase['dirops_by_name'] ?? ''),
        '{catatan_dirops}' => (string)($purchase['catatan_dirops'] ?? '-'),
        '{catatan_finance}'=> (string)($purchase['catatan_finance'] ?? '-'),
        '{app_url}'        => ho_app_url($purchase),
    ];
}

function ho_fill($template, array $vars)
{
    return strtr((string)$template, $vars);
}

// Tiket dianggap siap dilaporkan hanya kalau seluruh alur sudah tuntas
function ho_eligible(array $purchase)
{
    return $purchase['status_approval'] === 'disetujui'
        && $purchase['status_finance_approval'] === 'disetujui'
        && $purchase['status_dirops'] === 'disetujui'
        && $purchase['status_pembayaran'] === 'selesai';
}

function ho_mailto($to, $cc, $subject, $body, $scheme = 'mailto', $limit = 1800)
{
    $build = function ($b) use ($to, $cc, $subject, $scheme) {
        $prefix = ($scheme === 'outlook') ? 'outlook:mailto' : 'mailto';
        $bersih = function ($v) { return preg_replace('/[\r\n,;]+$/u', '', trim((string)$v)); };
        $url = $prefix . ':' . $bersih($to);
        $q = [];
        if ($cc) $q[] = 'cc=' . $bersih($cc);
        $q[] = 'subject=' . rawurlencode($subject);
        $q[] = 'body=' . rawurlencode($b);
        return $url . '?' . implode('&', $q);
    };
    $url = $build($body);
    if (strlen($url) > $limit) {
        // mailto punya batas panjang; potong badan email dari bawah bila kelebihan
        $lines = preg_split("/\r\n|\n/", $body);
        while (strlen($url) > $limit && count($lines) > 4) {
            array_pop($lines);
            $url = $build(implode("\r\n", $lines) . "\r\n...(rincian lengkap: buka tautan tiket di aplikasi)...");
        }
    }
    return $url;
}

// Deep link "tulis email baru" untuk Outlook new / Outlook di browser.
// Ini satu-satunya cara yang bisa disiapkan sebuah halaman web supaya Outlook
// di LAPTOP terbuka dengan subjek & isi terisi, karena:
//   - mailto: hanya mengikuti aplikasi email default Windows (harus diset manual), dan
//   - New Outlook MENGABAIKAN protokol custom (outlook:, ms-outlook:) jadi trik
//     "paksa Outlook desktop" tidak berlaku di New Outlook.
// Tautan https di bawah dikenali New Outlook (dibuka di aplikasinya) dan kalau
// tidak, terbuka di Outlook on the web - dua-duanya sudah terisi, tinggal Kirim.
function ho_web_link($to, $cc, $subject, $body, $host = 'outlook.office.com', $limit = 1900)
{
    $host = in_array($host, ['outlook.office.com', 'outlook.live.com'], true) ? $host : 'outlook.office.com';
    $path = ($host === 'outlook.live.com') ? '/mail/0/deeplink/compose' : '/mail/deeplink/compose';

    $bersih = function ($v) { return preg_replace('/[\r\n,;]+$/u', '', trim((string)$v)); };

    $build = function ($b) use ($to, $cc, $subject, $host, $path, $bersih) {
        $q = ['to=' . rawurlencode($bersih($to))];
        if ($cc !== '') $q[] = 'cc=' . rawurlencode($bersih($cc));
        $q[] = 'subject=' . rawurlencode($subject);
        // badan dibaca sebagai teks biasa; baris kosong di akhir membuat tautan
        // di dalamnya dikenali Outlook sebagai link yang bisa diklik
        $q[] = 'body=' . rawurlencode($b . "\r\n ");
        return 'https://' . $host . $path . '?' . implode('&', $q);
    };

    $url = $build($body);
    if (strlen($url) > $limit) {
        $lines = preg_split("/\r\n|\n/", $body);
        while (strlen($url) > $limit && count($lines) > 4) {
            array_pop($lines);
            $url = $build(implode("\r\n", $lines) . "\r\n...(rincian lengkap: buka tautan tiket di aplikasi)...");
        }
    }
    return $url;
}

// Rute yang dipakai saat tombol diklik dari laptop/komputer
function ho_rute_laptop(array $set)
{
    $r = strtolower(trim((string)($set['ho_email_laptop'] ?? 'auto')));
    return in_array($r, ['auto', 'outlook', 'web', 'mailto', 'pilih'], true) ? $r : 'auto';
}

// Handler URI "New Outlook for Windows" (olk.exe). Tidak sedokumentasi resmi dan
// belum lengkap, tapi inilah satu-satunya cara sebuah halaman web memanggil
// APLIKASI New Outlook dengan pesan terisi; kalau ditolak, browser diam saja
// (tidak ada error), jadi pencekokan harus berurutan + diingat hasilnya.
function ho_msoutlook_link($to, $cc, $subject, $body, $limit = 1800)
{
    $bersih = function ($v) { return preg_replace('/[\r\n,;]+$/u', '', trim((string)$v)); };

    $build = function ($b) use ($to, $cc, $subject, $bersih) {
        $q = ['to=' . rawurlencode($bersih($to))];
        if ($cc !== '') $q[] = 'cc=' . rawurlencode($bersih($cc));
        $q[] = 'subject=' . rawurlencode($subject);
        $q[] = 'body=' . rawurlencode($b);
        return 'ms-outlook://compose?' . implode('&', $q);
    };

    $url = $build($body);
    if (strlen($url) > $limit) {
        $lines = preg_split("/\r\n|\n/", $body);
        while (strlen($url) > $limit && count($lines) > 4) {
            array_pop($lines);
            $url = $build(implode("\r\n", $lines) . "\r\n...(rincian lengkap: buka tautan tiket di aplikasi)...");
        }
    }
    return $url;
}

// Kembalikan semua yang dibutuhkan tombol + alasan kalau tombolnya belum boleh muncul
function ho_laporan(PDO $pdo, array $purchase)
{
    $set = ho_settings($pdo);
    $out = [
        'siap'   => false,
        'alasan' => '',
        'kepada' => $set['ho_email_to'],
        'cc'     => $set['ho_email_cc'],
        'nama'   => $set['ho_email_nama'],
        'subjek' => '',
        'isi'    => '',
        'url'    => '',
        'skema'  => 'mailto',
        'web'    => '',
        'msoutlook' => '',
        'rute_laptop' => 'mailto',
    ];

    if ($set['ho_email_enabled'] !== '1') {
        $out['alasan'] = 'Fitur email laporan ke HO sedang dimatikan di menu Pengaturan Email Laporan.';
        return $out;
    }
    $to = strtolower(trim((string)$set['ho_email_to']));
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        $out['alasan'] = 'Alamat email tujuan belum diisi dengan benar (menu Pengaturan Email Laporan).';
        return $out;
    }
    if (!ho_eligible($purchase)) {
        $out['alasan'] = 'Tombol email muncul setelah tiket berstatus "Selesai / Done" (semua approval tuntas).';
        return $out;
    }

    // Halaman berbeda memakai alias kolom yang berbeda (detail.php memakai
    // approved_by_name, finance/list.php tidak mengambil nama sama sekali),
    // jadi nama petugas/finance/dirops dicari lewat id-nya bila belum ada,
    // supaya isi email selalu lengkap tidak peduli dari mana tombolnya diklik.
    $cariNama = function ($idCol, $nameCol) use ($pdo, &$purchase) {
        if (!empty($purchase[$nameCol])) return;
        $purchase[$nameCol] = '';
        if (empty($purchase[$idCol])) return;
        $st = $pdo->prepare("SELECT name FROM users WHERE id = ?");
        $st->execute([$purchase[$idCol]]);
        $purchase[$nameCol] = (string)($st->fetchColumn() ?: '');
    };
    $cariNama('approved_by', 'petugas_name');
    $cariNama('finance_approval_by', 'finance_appr_name');
    $cariNama('dirops_by', 'dirops_by_name');
    $cariNama('processed_by', 'finance_name');
    $cariNama('pic_id', 'pic_name');
    $cariNama('vendor_id', 'vendor_name');

    $vars = ho_vars($purchase, $set);
    $subjek = ho_fill($set['ho_email_subjek'], $vars);
    $isi    = ho_fill($set['ho_email_badan'], $vars);
    // buang baris "Catatan : -" yang kosong supaya email rapi
    $isi    = preg_replace("/\r\nCatatan\s*:\s*-\s*/", "\r\n", $isi);

    $cc = trim((string)$set['ho_email_cc']);
    if ($cc !== '' && !filter_var($cc, FILTER_VALIDATE_EMAIL)) $cc = '';

    $out['siap']   = true;
    $out['subjek'] = $subjek;
    $out['isi']    = $isi;
    $skema = ($set['ho_email_scheme'] ?? 'mailto') === 'outlook' ? 'outlook' : 'mailto';
    $out['url']    = ho_mailto($to, $cc, $subjek, $isi, $skema);
    $out['skema']  = $skema;
    $out['web']    = ho_web_link($to, $cc, $subjek, $isi, $set['ho_email_web_host'] ?? 'outlook.office.com');
    $out['msoutlook'] = ho_msoutlook_link($to, $cc, $subjek, $isi);
    $out['rute_laptop'] = ho_rute_laptop($set);
    return $out;
}

// Sudah pernah diklik sebelumnya? (dibaca dari timeline)
function ho_sudah_dilaporkan(PDO $pdo, $purchaseId)
{
    $stmt = $pdo->prepare("SELECT l.*, u.name AS user_name FROM purchase_logs l
                           JOIN users u ON u.id = l.user_id
                           WHERE l.purchase_id = ? AND l.action LIKE 'Email Laporan ke HO%'
                           ORDER BY l.created_at DESC LIMIT 1");
    $stmt->execute([(int)$purchaseId]);
    return $stmt->fetch() ?: null;
}

// =========================================================
// 3 jalur pengiriman - supaya tombol tetap jalan apa pun kondisinya
//   a. mailto:  -> membuka aplikasi email bawaan (Outlook) [bawaan]
//   b. server   -> PHP mail() di hosting, Outlook tidak perlu terbuka (opsional)
//   c. .eml     -> unduh berkas email, klik 2x -> terbuka di Outlook siap kirim
// =========================================================

// Isi .eml: header RFC822 + badan UTF-8, cukup untuk Outlook/Thunderbird
function ho_eml_content($to, $cc, $subject, $body)
{
    $garis = [
        'To: ' . $to,
        ($cc ? 'Cc: ' . $cc : null),
        'Subject: =?UTF-8?B?' . base64_encode((string)$subject) . '=?=',
        'Date: ' . date('r'),
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
        'X-Purchasing-Note: dibuat otomatis oleh Purchasing Management System',
    ];
    $hdr = implode("\r\n", array_filter($garis, function ($v) { return $v !== null; }));
    return $hdr . "\r\n\r\n" . str_replace(["\r\n", "\n"], ["\n", "\r\n"], (string)$body) . "\r\n";
}

// Kirim lewat mail() hosting. Gagal? alasannya dikembalikan, tidak diam-diam.
function ho_kirim_server(PDO $pdo, array $purchase)
{
    $set = ho_settings($pdo);
    if (($set['ho_email_kirim_server'] ?? '0') !== '1') {
        return ['ok' => false, 'pesan' => 'Mode "kirim dari server" belum diaktifkan Admin.'];
    }
    $ho = ho_laporan($pdo, $purchase);
    if (!$ho['siap']) {
        return ['ok' => false, 'pesan' => ($ho['alasan'] ?: 'Tiket belum siap dilaporkan.')];
    }
    if (!function_exists('mail')) {
        return ['ok' => false, 'pesan' => 'PHP di server ini tidak punya fungsi mail(). Pakai mailto atau berkas .eml.'];
    }

    $me = current_user();
    $host = preg_replace('/[^A-Za-z0-9.\-]/', '', explode(':', (string)($_SERVER['HTTP_HOST'] ?? 'localhost'))[0]);
    $dari = trim((string)($set['ho_email_dari'] ?? ''));
    if ($dari === '' || !filter_var($dari, FILTER_VALIDATE_EMAIL)) {
        $dari = 'purchasing@' . ($host !== '' ? $host : 'localhost');
    }

    $hdr = [
        'From: Purchasing System <' . $dari . '>',
        'Reply-To: ' . $dari,
        'MIME-Version: 1.0',
        'Content-Type: text/plain; charset=UTF-8',
        'Content-Transfer-Encoding: 8bit',
    ];
    if (!empty($ho['cc'])) $hdr[] = 'Cc: ' . $ho['cc'];

    $ok = @mail($ho['kepada'], $ho['subjek'], $ho['isi'], implode("\r\n", $hdr));
    if (!$ok) {
        $last = error_get_last();
        return ['ok' => false, 'pesan' => 'mail() menolak mengirim'
            . (isset($last['message']) ? ': ' . $last['message'] : '.')
            . ' Cek SPF/DKIM domain di hosting, atau pakai mailto / berkas .eml.'];
    }
    log_activity($pdo, (int)$purchase['id'], 'Email Laporan ke HO (' . $ho['kepada'] . ')',
        'Dikirim dari server ke ' . $ho['kepada'] . ' - nilai dibayarkan ' . format_rupiah(total_setelah_pajak($purchase)));
    return ['ok' => true, 'pesan' => 'Terkirim ke ' . $ho['kepada'], 'kepada' => $ho['kepada'],
            'dicatat' => date('d.m.Y H:i') . ' oleh ' . ($me['name'] ?? '')];
}

// Kumpulan tombol. $panelId = id blok pertolongan kalau Outlook tidak terbuka.
function ho_tombol_html(PDO $pdo, array $purchase, $kelas = 'btn-primary', $label = null, $panelId = null)
{
    static $jsSudah = false;
    $ho = ho_laporan($pdo, $purchase);
    if (!$ho['siap']) return null;

    $id    = (int)$purchase['id'];
    $eml   = BASE_URL . '/finance/lapor-ho-eml.php?id=' . $id;
    $server = (ho_settings($pdo)['ho_email_kirim_server'] ?? '0') === '1';
    $panel = $panelId ? ' data-panel="' . e($panelId) . '"' : '';

    // SEMUA jalur memakai <a href="mailto:...">: kalau JavaScript mati atau
    // file .js tidak ke-load, klik tetap membuka aplikasi email seperti biasa.
    if ($server) {
        $out = '<a href="' . e($ho['url']) . '" class="btn btn-sm ' . e($kelas) . '"' . $panel
             . ' data-kirim="' . e(BASE_URL . '/finance/lapor-ho-kirim.php') . '" data-id="' . $id . '"'
             . ' onclick="return hoKirim(this)"'
             . ' title="Email dikirim langsung dari server, Outlook tidak perlu terbuka">'
             . ($label ?: '<i class="bi bi-send"></i> Lapor ke ' . e($ho['nama']) . ' (Kirim)') . '</a>';
    } else {
        $rute = $ho['rute_laptop'];
        $out = '<a href="' . e($ho['url']) . '" class="btn btn-sm ' . e($kelas) . '"' . $panel
             . ' data-mailto="' . e($ho['url']) . '" data-id="' . $id . '"'
             . ($ho['web'] !== '' ? ' data-web="' . e($ho['web']) . '"' : '')
             . ($ho['msoutlook'] !== '' ? ' data-msoutlook="' . e($ho['msoutlook']) . '"' : '')
             . ' data-rute="' . e($rute) . '"'
             . ' data-ping="' . e(BASE_URL . '/finance/lapor-ho-log.php') . '"'
             . ' onclick="return hoLapor(this)"'
             . ' title="' . ($rute === 'mailto'
                    ? 'Membuka aplikasi email bawaan (Outlook) dengan pesan siap kirim ke '
                    : 'Di laptop: membuka APLIKASI Outlook new, cadangannya mailto: lalu Outlook di browser - ke ') . e($ho['kepada']) . '">'
             . ($label ?: '<i class="bi bi-envelope-paper"></i> Lapor ke ' . e($ho['nama']) . ' (Email)') . '</a>';
    }

    $out .= ' <a href="' . $eml . '" class="btn btn-sm btn-outline-secondary"'
          . ' title="Cadangan: unduh berkas email, klik 2x -> terbuka di Outlook dan tinggal dikirim">'
          . '<i class="bi bi-file-earmark-arrow-down"></i> <span class="d-none d-lg-inline">.eml</span></a>';

    // aset JS cukup dimuat sekali per halaman
    if (!$jsSudah) {
        $jsSudah = true;
        $file = __DIR__ . '/../assets/js/lapor-ho.js';
        $out .= chr(10) . '<script src="' . BASE_URL . '/assets/js/lapor-ho.js?v='
              . (file_exists($file) ? filemtime($file) : time()) . '"></script>';
    }
    return $out;
}
