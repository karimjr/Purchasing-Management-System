<?php
// =========================================================
// Bootstrap: dipanggil di baris pertama setiap halaman
// =========================================================

// Simpan session di folder sendiri di dalam aplikasi.
// Ini menghindari masalah umum di shared hosting, di mana PHP
// tidak diizinkan (open_basedir) menulis ke folder /tmp sistem,
// sehingga session tidak pernah tersimpan dan user selalu
// terlempar balik ke halaman login walau password benar.
if (session_status() === PHP_SESSION_NONE) {
    $sessionPath = __DIR__ . '/../.sessions';
    if (!is_dir($sessionPath)) {
        @mkdir($sessionPath, 0755, true);
    }
    if (is_dir($sessionPath) && is_writable($sessionPath)) {
        session_save_path($sessionPath);
    }
    session_start();
}

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
